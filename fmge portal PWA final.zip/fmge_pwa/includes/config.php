<?php
// ================================================
// FMGE PORTAL — SECURE CONFIG v2.0
// ALL SQL uses prepared statements — no injection possible
// CSRF tokens on every form/API
// Rate limiting on login
// ================================================

define('DB_HOST', 'sql302.infinityfree.com');
define('DB_USER', 'if0_41399493');
define('DB_PASS', 'YOUR_PASSWORD_HERE');
define('DB_NAME', 'if0_41399493_doctor');
define('SITE_URL', 'http://doctor.page.gd');
define('CSRF_TOKEN_NAME', '_fmge_csrf');
define('SESSION_IDLE', 1800);

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_samesite', 'Strict');
    ini_set('session.use_strict_mode', 1);
    session_start();
}

// Idle timeout
if (isset($_SESSION['_last']) && (time() - $_SESSION['_last']) > SESSION_IDLE) {
    session_unset(); session_destroy(); session_start();
}
$_SESSION['_last'] = time();

// CSRF
function csrf_token(): string {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    return $_SESSION[CSRF_TOKEN_NAME];
}
function csrf_verify(string $t): bool {
    return !empty($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $t);
}
function csrf_field(): string { return '<input type="hidden" name="'.CSRF_TOKEN_NAME.'" value="'.csrf_token().'"/>'; }
function csrf_verify_ajax(): void {
    $d = json_decode(file_get_contents('php://input'), true);
    $t = $d[CSRF_TOKEN_NAME] ?? ($_POST[CSRF_TOKEN_NAME] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!csrf_verify($t)) { http_response_code(403); die(json_encode(['success'=>false,'error'=>'Forbidden'])); }
}

// Rate limiting
function rate_limit(string $key, int $max=5, int $window=300): bool {
    $f = sys_get_temp_dir().'/rl_'.md5($key).'.dat';
    $now = time();
    $hits = file_exists($f) ? array_filter(explode(',', file_get_contents($f)), fn($t)=>$t&&($now-(int)$t)<$window) : [];
    if (count($hits) >= $max) return false;
    $hits[] = $now;
    file_put_contents($f, implode(',', $hits), LOCK_EX);
    return true;
}

// Auto-login via cookie (secure)
if (!isset($_SESSION['user_id']) && !empty($_COOKIE['fmge_token'])) {
    $tok = $_COOKIE['fmge_token'];
    if (preg_match('/^[a-f0-9]{64}$/', $tok)) {
        $db = getDB();
        $st = $db->prepare("SELECT * FROM users WHERE remember_token=? AND is_banned=0 AND is_active=1 LIMIT 1");
        $st->bind_param('s', $tok); $st->execute();
        $u = $st->get_result()->fetch_assoc();
        if ($u) { $_SESSION['user_id']=$u['id']; $_SESSION['username']=$u['username']; $_SESSION['full_name']=$u['full_name']; $_SESSION['role']=$u['role']; session_regenerate_id(true); }
    }
}

function getDB(): mysqli {
    static $c = null;
    if (!$c) {
        $c = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
        if ($c->connect_error) die('<div style="padding:30px;background:#05080f;color:#ef4444;font-family:monospace">DB Error — check config.php</div>');
        $c->set_charset('utf8mb4');
    }
    return $c;
}
function clean(mixed $s): string { return htmlspecialchars(strip_tags(trim((string)($s??''))),ENT_QUOTES|ENT_HTML5,'UTF-8'); }
function cleanInt(mixed $v): int { return (int)filter_var($v,FILTER_SANITIZE_NUMBER_INT); }

function requireLogin(): void { if (!isset($_SESSION['user_id'])) { header('Location: '.SITE_URL.'/index.php'); exit; } }
function requireAdmin(): void { requireLogin(); if ($_SESSION['role']!=='admin') { header('Location: '.SITE_URL.'/dashboard.php'); exit; } }
function getCurrentUser(): ?array {
    if (!isset($_SESSION['user_id'])) return null;
    $id=(int)$_SESSION['user_id'];
    $s=getDB()->prepare("SELECT u.*,COALESCE(us.theme,'void') as theme FROM users u LEFT JOIN user_settings us ON us.user_id=u.id WHERE u.id=? LIMIT 1");
    $s->bind_param('i',$id); $s->execute();
    return $s->get_result()->fetch_assoc()?:null;
}

function xpForLevel(int $l): int { return $l*500; }
function getMilitaryRank(int $l): array {
    if($l<=5) return ['Private','🪖','#6b7280','E']; if($l<=10) return ['Corporal','⭐','#64748b','D'];
    if($l<=15) return ['Sergeant','🎖️','#3b82f6','D+']; if($l<=20) return ['Staff Sergeant','🎗️','#2563eb','C'];
    if($l<=25) return ['Lieutenant','🥉','#10b981','C+']; if($l<=30) return ['First Lieutenant','🥉','#059669','B'];
    if($l<=40) return ['Captain','🥈','#f59e0b','B+']; if($l<=50) return ['Major','🥈','#d97706','A'];
    if($l<=60) return ['Colonel','🥇','#ef4444','A+']; if($l<=70) return ['Brigadier','🥇','#dc2626','S'];
    if($l<=80) return ['General','🌟','#8b5cf6','S+']; if($l<=90) return ['Field Marshal','👑','#7c3aed','SS'];
    if($l<=99) return ['Supreme Commander','💎','#00d4ff','SS+']; return ['FMGE Legend','🏆','#f59e0b','SSS'];
}
function getRank(int $l): array { $r=getMilitaryRank($l); return [$r[0],$r[2],$r[0]]; }

function addXP(int $uid,int $xp,int $coins=0): void {
    $db=getDB();
    $s=$db->prepare("SELECT xp,level,coins FROM users WHERE id=?"); $s->bind_param('i',$uid); $s->execute();
    $u=$s->get_result()->fetch_assoc(); if(!$u) return;
    $nx=$u['xp']+$xp; $nc=$u['coins']+$coins; $nl=$u['level'];
    while($nx>=xpForLevel($nl)){$nx-=xpForLevel($nl);$nl++;}
    $rn=getMilitaryRank($nl)[0];
    $s2=$db->prepare("UPDATE users SET xp=?,level=?,coins=?,rank_title=? WHERE id=?"); $s2->bind_param('iiisi',$nx,$nl,$nc,$rn,$uid); $s2->execute();
    if($nl>$u['level']) addNotification($uid,"⬆️ Promoted to ".getMilitaryRank($nl)[0]."! Level $nl",'levelup');
}
function updateStreak(int $uid): void {
    $db=getDB(); $td=date('Y-m-d'); $yd=date('Y-m-d',strtotime('-1 day'));
    $s=$db->prepare("SELECT streak_days,last_study_date,dark_side_days FROM users WHERE id=?"); $s->bind_param('i',$uid); $s->execute();
    $u=$s->get_result()->fetch_assoc(); if(!$u||$u['last_study_date']===$td) return;
    if($u['last_study_date']===$yd){$s2=$db->prepare("UPDATE users SET streak_days=streak_days+1,last_study_date=?,dark_side_days=0 WHERE id=?");$s2->bind_param('si',$td,$uid);$s2->execute();}
    else{$m=$u['last_study_date']?max(0,ceil((strtotime($td)-strtotime($u['last_study_date']))/86400)-1):0;$dk=min($m,7);$ns=1;$s2=$db->prepare("UPDATE users SET streak_days=?,last_study_date=?,dark_side_days=? WHERE id=?");$s2->bind_param('isii',$ns,$td,$dk,$uid);$s2->execute();}
    addXP($uid,10,5);
}
function addNotification(int $uid,string $msg,string $type='info'): void {
    $s=getDB()->prepare("INSERT INTO notifications (user_id,message,type) VALUES (?,?,?)"); $s->bind_param('iss',$uid,$msg,$type); $s->execute();
}
function checkBadges(int $uid): void {
    $db=getDB();
    $s=$db->prepare("SELECT * FROM users WHERE id=?");$s->bind_param('i',$uid);$s->execute();
    $user=$s->get_result()->fetch_assoc(); if(!$user) return;
    $badges=$db->query("SELECT * FROM badges"); if(!$badges) return;
    while($b=$badges->fetch_assoc()){
        $earned=false; $bid=(int)$b['id'];
        switch($b['badge_type']){
            case 'login': $earned=true; break;
            case 'study_sessions':$q=$db->prepare("SELECT COUNT(*) c FROM study_sessions WHERE user_id=?");$q->bind_param('i',$uid);$q->execute();$earned=$q->get_result()->fetch_assoc()['c']>=$b['requirement_value'];break;
            case 'total_mcqs':$earned=$user['total_mcqs']>=$b['requirement_value'];break;
            case 'streak':$earned=$user['streak_days']>=$b['requirement_value'];break;
            case 'study_hours':$earned=$user['total_study_minutes']>=$b['requirement_value'];break;
            case 'exams':$q=$db->prepare("SELECT COUNT(*) c FROM exam_records WHERE user_id=?");$q->bind_param('i',$uid);$q->execute();$earned=$q->get_result()->fetch_assoc()['c']>=$b['requirement_value'];break;
            case 'posts':$q=$db->prepare("SELECT COUNT(*) c FROM community_posts WHERE user_id=?");$q->bind_param('i',$uid);$q->execute();$earned=$q->get_result()->fetch_assoc()['c']>=$b['requirement_value'];break;
            case 'partners':$q=$db->prepare("SELECT COUNT(*) c FROM study_partners WHERE (user_id=? OR partner_id=?) AND status='accepted'");$q->bind_param('ii',$uid,$uid);$q->execute();$earned=$q->get_result()->fetch_assoc()['c']>=$b['requirement_value'];break;
            case 'clan':$q=$db->prepare("SELECT COUNT(*) c FROM clan_members WHERE user_id=?");$q->bind_param('i',$uid);$q->execute();$earned=$q->get_result()->fetch_assoc()['c']>=$b['requirement_value'];break;
        }
        if($earned){$ck=$db->prepare("SELECT id FROM user_badges WHERE user_id=? AND badge_id=?");$ck->bind_param('ii',$uid,$bid);$ck->execute();
            if(!$ck->get_result()->num_rows){$in=$db->prepare("INSERT IGNORE INTO user_badges (user_id,badge_id) VALUES (?,?)");$in->bind_param('ii',$uid,$bid);$in->execute();addXP($uid,(int)$b['xp_reward'],(int)$b['coin_reward']);addNotification($uid,"🎖️ Badge Earned: {$b['badge_name']}! +{$b['xp_reward']} XP",'badge');}}
    }
    checkStoryProgress($uid); updateWorldMap($uid);
}
function getVillainHP(int $uid): int {$db=getDB();$s=$db->prepare("SELECT level,dark_side_days FROM users WHERE id=?");$s->bind_param('i',$uid);$s->execute();$u=$s->get_result()->fetch_assoc();if(!$u)return 1000;return 1000+($u['level']*200)+(($u['dark_side_days']??0)*100);}
function getVillainDealt(int $uid): int {$db=getDB();$s1=$db->prepare("SELECT COALESCE(SUM(duration_minutes),0) t FROM study_sessions WHERE user_id=?");$s1->bind_param('i',$uid);$s1->execute();$sm=(int)$s1->get_result()->fetch_assoc()['t'];$s2=$db->prepare("SELECT COALESCE(SUM(correct),0) t FROM mcq_records WHERE user_id=?");$s2->bind_param('i',$uid);$s2->execute();$mc=(int)$s2->get_result()->fetch_assoc()['t'];return $sm*2+$mc*5;}
function arePartners(int $u1,int $u2): bool {$s=getDB()->prepare("SELECT id FROM study_partners WHERE ((user_id=? AND partner_id=?) OR (user_id=? AND partner_id=?)) AND status='accepted'");$s->bind_param('iiii',$u1,$u2,$u2,$u1);$s->execute();return $s->get_result()->num_rows>0;}
function checkStoryProgress(int $uid): void {$db=getDB();$s=$db->prepare("SELECT level,total_study_minutes,total_mcqs,streak_days FROM users WHERE id=?");$s->bind_param('i',$uid);$s->execute();$user=$s->get_result()->fetch_assoc();if(!$user)return;$ps=$db->prepare("SELECT COUNT(*) c FROM study_partners WHERE (user_id=? OR partner_id=?) AND status='accepted'");$ps->bind_param('ii',$uid,$uid);$ps->execute();$pc=(int)$ps->get_result()->fetch_assoc()['c'];$es=$db->prepare("SELECT COUNT(*) c FROM exam_records WHERE user_id=?");$es->bind_param('i',$uid);$es->execute();$ec=(int)$es->get_result()->fetch_assoc()['c'];$ch=$db->query("SELECT * FROM story_chapters ORDER BY chapter_num ASC");if(!$ch)return;while($r=$ch->fetch_assoc()){$u=false;switch($r['unlock_requirement']){case 'level':$u=$user['level']>=$r['unlock_value'];break;case 'study_hours':$u=$user['total_study_minutes']>=$r['unlock_value']*60;break;case 'total_mcqs':$u=$user['total_mcqs']>=$r['unlock_value'];break;case 'streak':$u=$user['streak_days']>=$r['unlock_value'];break;case 'partners':$u=$pc>=$r['unlock_value'];break;case 'exams':$u=$ec>=$r['unlock_value'];break;}if($u){$cid=(int)$r['id'];$ck=$db->prepare("SELECT id FROM user_story WHERE user_id=? AND chapter_id=?");$ck->bind_param('ii',$uid,$cid);$ck->execute();if(!$ck->get_result()->num_rows){$in=$db->prepare("INSERT IGNORE INTO user_story (user_id,chapter_id) VALUES (?,?)");$in->bind_param('ii',$uid,$cid);$in->execute();addNotification($uid,"📖 Story Unlocked: {$r['title']}!",'story');}}}}
function updateWorldMap(int $uid): void {$db=getDB();$s=$db->prepare("SELECT subject_name,completed_topics,total_topics FROM subject_progress WHERE user_id=?");$s->bind_param('i',$uid);$s->execute();$res=$s->get_result();while($sub=$res->fetch_assoc()){$p=$sub['total_topics']>0?round($sub['completed_topics']/$sub['total_topics']*100):0;$u=$p>0?1:0;$in=$db->prepare("INSERT INTO world_map_progress (user_id,island_name,is_unlocked,progress_pct) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE is_unlocked=?,progress_pct=?");$in->bind_param('isiiii',$uid,$sub['subject_name'],$u,$p,$u,$p);$in->execute();}}

function getThemeData(): array {return ['void'=>['Void Noir','#8b5cf6','Deep space — violet nebula','dark'],'abyss'=>['Abyssal Red','#ef4444','Crimson pulse — danger energy','dark'],'phantom'=>['Phantom Teal','#14b8a6','Deep ocean — scanning lines','dark'],'sakura'=>['Sakura Bloom','#ec4899','Soft pink — floating petals','light'],'citrus'=>['Citrus Burst','#f59e0b','High energy amber — morning','light'],'arctic'=>['Arctic Mint','#10b981','Fresh healing green — medical','light'],'iris'=>['Royal Iris','#7c3aed','Regal lavender — scholarly','light'],'ocean'=>['Ocean Breeze','#2563eb','Cool sapphire — calm focus','light'],'ember'=>['Ember Glow','#f97316','Warm terracotta — passionate','light'],'pearl'=>['Pearl Clinical','#0ea5e9','Clean hospital — professional','light']];}
function getThemeVars(string $theme): string {$t=['void'=>'--bg:#03030a;--bg2:#06040f;--card:#09071a;--border:#120d28;--border2:#1a1535;--text:#e8e0ff;--muted:#3a3550;--muted2:#28203a;--primary:#8b5cf6;--secondary:#ec4899;--accent:#f59e0b;--success:#1a9e6e;--danger:#c0384a;--glow:rgba(139,92,246,.12);','abyss'=>'--bg:#070205;--bg2:#0e060a;--card:#140a10;--border:#1a0810;--border2:#260d18;--text:#ffe0e0;--muted:#3a2020;--muted2:#2a1515;--primary:#ef4444;--secondary:#f97316;--accent:#fbbf24;--success:#1a9e6e;--danger:#c0384a;--glow:rgba(239,68,68,.12);','phantom'=>'--bg:#020a0d;--bg2:#041015;--card:#06161c;--border:#0a2030;--border2:#102840;--text:#a0f0f4;--muted:#1a3a3c;--muted2:#122830;--primary:#14b8a6;--secondary:#06b6d4;--accent:#fbbf24;--success:#1a9e6e;--danger:#c0384a;--glow:rgba(20,184,166,.12);','sakura'=>'--bg:#fff5f7;--bg2:#ffeef5;--card:#ffffff;--border:#fcd5e5;--border2:#fbbdd4;--text:#831843;--muted:#9d5070;--muted2:#c07090;--primary:#ec4899;--secondary:#f43f5e;--accent:#f59e0b;--success:#16a34a;--danger:#dc2626;--glow:rgba(236,72,153,.1);','citrus'=>'--bg:#fffbeb;--bg2:#fff7ed;--card:#ffffff;--border:#fde68a;--border2:#fcd34d;--text:#78350f;--muted:#92400e;--muted2:#b45309;--primary:#f59e0b;--secondary:#ef4444;--accent:#84cc16;--success:#16a34a;--danger:#dc2626;--glow:rgba(245,158,11,.1);','arctic'=>'--bg:#f0fdfa;--bg2:#ecfdf5;--card:#ffffff;--border:#a7f3d0;--border2:#6ee7b7;--text:#064e3b;--muted:#065f46;--muted2:#047857;--primary:#10b981;--secondary:#06b6d4;--accent:#f59e0b;--success:#16a34a;--danger:#dc2626;--glow:rgba(16,185,129,.1);','iris'=>'--bg:#faf5ff;--bg2:#f5f3ff;--card:#ffffff;--border:#ddd6fe;--border2:#c4b5fd;--text:#3b0764;--muted:#5b21b6;--muted2:#7c3aed;--primary:#7c3aed;--secondary:#ec4899;--accent:#f59e0b;--success:#16a34a;--danger:#dc2626;--glow:rgba(124,58,237,.1);','ocean'=>'--bg:#eff6ff;--bg2:#e0f2fe;--card:#ffffff;--border:#bfdbfe;--border2:#7dd3fc;--text:#1e3a5f;--muted:#1d4ed8;--muted2:#2563eb;--primary:#2563eb;--secondary:#0ea5e9;--accent:#f59e0b;--success:#16a34a;--danger:#dc2626;--glow:rgba(37,99,235,.1);','ember'=>'--bg:#fff7f0;--bg2:#fff1eb;--card:#ffffff;--border:#fed7aa;--border2:#fca5a5;--text:#7c2d12;--muted:#9a3412;--muted2:#c2410c;--primary:#f97316;--secondary:#ef4444;--accent:#84cc16;--success:#16a34a;--danger:#dc2626;--glow:rgba(249,115,22,.1);','pearl'=>'--bg:#f8fafc;--bg2:#f1f5f9;--card:#ffffff;--border:#e2e8f0;--border2:#cbd5e1;--text:#0f172a;--muted:#475569;--muted2:#64748b;--primary:#0ea5e9;--secondary:#7c3aed;--accent:#f59e0b;--success:#16a34a;--danger:#dc2626;--glow:rgba(14,165,233,.08);'];return $t[$theme]??$t['void'];}
