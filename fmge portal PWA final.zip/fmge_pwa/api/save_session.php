<?php
require_once '../includes/config.php';
requireLogin();
header('Content-Type: application/json');

$d = json_decode(file_get_contents('php://input'), true) ?? [];
if(!csrf_verify($d[CSRF_TOKEN_NAME]??'')) { http_response_code(403); die(json_encode(['success'=>false])); }

$uid = (int)$_SESSION['user_id'];
$subject = clean($d['subject'] ?? '');
$duration = min(480, max(1, cleanInt($d['duration_minutes'] ?? 0)));
$today = date('Y-m-d');
if(!$subject||!$duration){ die(json_encode(['success'=>false,'error'=>'Invalid data'])); }

$db = getDB();
$s1 = $db->prepare("INSERT INTO study_sessions (user_id,subject,duration_minutes,session_date) VALUES (?,?,?,?)");
$s1->bind_param('isis',$uid,$subject,$duration,$today);
if($s1->execute()){
    $s2 = $db->prepare("UPDATE users SET total_study_minutes=total_study_minutes+? WHERE id=?");
    $s2->bind_param('ii',$duration,$uid); $s2->execute();
    addXP($uid, intval($duration/10), intval($duration/5));
    updateStreak($uid);
    echo json_encode(['success'=>true,'xp_earned'=>intval($duration/10)]);
} else { echo json_encode(['success'=>false]); }
