<?php
require_once '../includes/config.php';
requireLogin();
$db=getDB();$uid=(int)$_SESSION['user_id'];

if($_SERVER['REQUEST_METHOD']==='POST'){
    $a=$_POST['action']??'';
    if($a==='add'){
        $t=clean($_POST['title']??'');$d=clean($_POST['date']??'');$desc=clean($_POST['desc']??'');$c=clean($_POST['color']??'#38b6cc');
        if($t&&$d){$stmt=$db->prepare("INSERT INTO roadmap(user_id,milestone_title,target_date,description,color) VALUES(?,?,?,?,?)");$stmt->bind_param('issss',$uid,$t,$d,$desc,$c);$stmt->execute();addXP($uid,20,10);}
    }elseif($a==='complete'){
        $id=(int)($_POST['id']??0);$db->query("UPDATE roadmap SET is_completed=1 WHERE id=$id AND user_id=$uid");addXP($uid,100,50);
    }elseif($a==='delete'){
        $id=(int)($_POST['id']??0);$db->query("DELETE FROM roadmap WHERE id=$id AND user_id=$uid");
    }
    header('Location: roadmap.php');exit;
}

$milestones=$db->query("SELECT * FROM roadmap WHERE user_id=$uid ORDER BY target_date ASC");
$mList=[];if($milestones)while($r=$milestones->fetch_assoc())$mList[]=$r;
$total=count($mList);$completed=count(array_filter($mList,fn($m)=>$m['is_completed']));
$pct=$total>0?round($completed/$total*100):0;
$daysLeft=$_SESSION['exam_date']??null;

$pageTitle='Roadmap';$activePage='roadmap';
include '../includes/header.php';
?>
<div class="page-content">

<!-- Header -->
<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:24px;" class="anim-fade-up">
  <div>
    <div style="font-family:'Orbitron',monospace;font-size:15px;color:var(--text);letter-spacing:2px;">🗺️ MY ROADMAP</div>
    <div style="font-size:11px;color:var(--muted);margin-top:2px;">Your journey to FMGE victory</div>
  </div>
  <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
    <div style="background:rgba(201,146,42,.08);border:1px solid rgba(201,146,42,.2);border-radius:12px;padding:8px 14px;text-align:center;">
      <div style="font-family:'JetBrains Mono',monospace;font-size:20px;font-weight:900;color:var(--accent);"><?= $pct ?>%</div>
      <div style="font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;"><?= $completed ?>/<?= $total ?> Done</div>
    </div>
    <button onclick="document.getElementById('addModal').classList.add('open')" class="btn btn-primary">＋ Add Goal</button>
  </div>
</div>

<!-- Progress bar -->
<?php if($total>0): ?>
<div style="margin-bottom:24px;" class="anim-fade-up" data-delay="1">
  <div class="prog-track" style="height:8px;border-radius:4px;">
    <div class="prog-fill" data-w="<?= $pct ?>%" style="width:0;background:linear-gradient(90deg,var(--primary),var(--secondary));box-shadow:0 0 10px var(--glow);border-radius:4px;"></div>
  </div>
</div>
<?php endif; ?>

<!-- Destination -->
<div style="text-align:center;margin-bottom:20px;" class="anim-fade-up" data-delay="1">
  <div style="width:64px;height:64px;border-radius:50%;background:linear-gradient(135deg,var(--accent),#f59e0b);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 10px;box-shadow:0 0 40px rgba(201,146,42,.3);animation:float 3s ease-in-out infinite;">🏆</div>
  <div style="font-family:'Orbitron',monospace;font-size:13px;color:var(--accent);letter-spacing:2px;">FMGE CLEARED</div>
  <div style="font-size:10px;color:var(--muted);margin-top:2px;">Your ultimate destination</div>
</div>

<!-- Milestones Timeline -->
<div style="position:relative;padding-left:28px;max-width:680px;margin:0 auto;">
  <div style="position:absolute;left:9px;top:0;bottom:0;width:2px;background:linear-gradient(180deg,var(--accent),var(--primary),transparent);border-radius:1px;"></div>

  <?php
  $activeIdx = -1;
  foreach($mList as $i=>$m){ if(!$m['is_completed']){ $activeIdx=$i; break; } }
  foreach($mList as $i=>$m):
    $isDone=$m['is_completed'];
    $isActive=$i===$activeIdx;
    $daysLeft=max(0,ceil((strtotime($m['target_date'])-time())/86400));
    $daysClass=$daysLeft>60?'#38b6cc':($daysLeft>14?'#c9922a':'#c0384a');
  ?>
  <div style="position:relative;margin-bottom:20px;opacity:<?= $isDone?'.7':($isActive?'1':'.45') ?>;" class="anim-fade-up" data-delay="<?= min($i+2,5) ?>">
    <!-- Node -->
    <div style="position:absolute;left:-23px;top:14px;width:<?= $isActive?'18px':'12px' ?>;height:<?= $isActive?'18px':'12px' ?>;border-radius:50%;<?= $isDone?'background:var(--primary);border:2px solid var(--primary);box-shadow:0 0 10px var(--glow);':($isActive?'background:linear-gradient(135deg,var(--primary),var(--secondary));border:none;box-shadow:0 0 18px var(--glow);animation:glowPulse 1.5s infinite;':'background:var(--bg);border:2px solid var(--muted2);') ?>margin-left:<?= $isActive?'-3px':0 ?>;"></div>

    <!-- Card -->
    <div style="padding:<?= $isActive?'22px 22px':'12px 18px' ?>;border-radius:16px;border:1px solid <?= $isActive?'rgba(56,182,204,.25)':'rgba(255,255,255,.05)' ?>;background:<?= $isActive?'rgba(56,182,204,.04)':'rgba(255,255,255,.01)' ?>;transition:all .4s;cursor:<?= !$isDone&&!$isActive?'pointer':'default' ?>;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;margin-bottom:<?= $isActive?'8px':'0' ?>;">
        <div>
          <span style="font-size:9px;font-weight:700;padding:2px 8px;border-radius:10px;background:<?= $isDone?'rgba(26,158,110,.12)':($isActive?'rgba(56,182,204,.1)':'rgba(255,255,255,.04)') ?>;color:<?= $isDone?'var(--success)':($isActive?'var(--primary)':'var(--muted)') ?>;border:1px solid <?= $isDone?'rgba(26,158,110,.2)':($isActive?'rgba(56,182,204,.2)':'rgba(255,255,255,.06)') ?>;letter-spacing:1px;text-transform:uppercase;"><?= $isDone?'✅ COMPLETED':($isActive?'▶ IN PROGRESS':'⏳ UPCOMING') ?></span>
          <div style="font-size:<?= $isActive?'clamp(16px,2.5vw,22px)':'13px' ?>;font-weight:700;color:<?= $isActive?'var(--text)':'var(--muted)' ?>;margin-top:6px;<?= $isDone?'text-decoration:line-through;':'' ?>;<?= $isActive?'font-family:\'Orbitron\',monospace;':'' ?>"><?= clean($m['milestone_title']) ?></div>
        </div>
        <div style="font-size:10px;color:var(--muted);font-family:'JetBrains Mono',monospace;flex-shrink:0;"><?= date('d M Y',strtotime($m['target_date'])) ?></div>
      </div>

      <?php if($isActive): ?>
      <?php if($m['description']): ?><div style="font-size:12px;color:var(--muted);line-height:1.6;margin-bottom:10px;"><?= clean($m['description']) ?></div><?php endif; ?>
      <div style="display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:700;padding:4px 12px;border-radius:20px;background:rgba(56,182,204,.08);color:<?= $daysClass ?>;border:1px solid <?= $daysClass ?>33;margin-bottom:12px;">
        <?= $daysLeft===0?'⚠️ Overdue':"📅 $daysLeft days left" ?>
      </div>
      <div style="display:flex;gap:8px;">
        <form method="POST"><input type="hidden" name="action" value="complete"/><input type="hidden" name="id" value="<?= $m['id'] ?>"/><button type="submit" class="btn btn-primary btn-sm">✅ Mark Complete +100 XP</button></form>
        <form method="POST"><input type="hidden" name="action" value="delete"/><input type="hidden" name="id" value="<?= $m['id'] ?>"/><button type="submit" class="btn btn-danger btn-sm">🗑</button></form>
      </div>
      <?php elseif($isDone): ?>
      <div style="font-size:10px;color:var(--success);margin-top:4px;">✅ Completed</div>
      <?php else: ?>
      <div style="font-size:11px;color:var(--muted2);margin-top:4px;">Complete previous milestone to unlock</div>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>

  <?php if(empty($mList)): ?>
  <div style="text-align:center;padding:48px;color:var(--muted);">
    <div style="font-size:40px;margin-bottom:12px;">🗺️</div>
    <div style="font-size:14px;font-weight:600;">No goals yet</div>
    <div style="font-size:12px;margin-top:4px;">Add your first milestone above!</div>
  </div>
  <?php endif; ?>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
  <div class="modal">
    <div class="modal-ttl">➕ ADD MILESTONE</div>
    <form method="POST">
      <input type="hidden" name="action" value="add"/>
      <div class="form-group"><label>Goal Title *</label><input type="text" name="title" class="form-control" placeholder="e.g. Complete Anatomy Revision" required/></div>
      <div class="form-row">
        <div class="form-group"><label>Target Date *</label><input type="date" name="date" class="form-control" required/></div>
        <div class="form-group"><label>Color</label><input type="color" name="color" class="form-control" value="#38b6cc" style="height:42px;cursor:pointer;"/></div>
      </div>
      <div class="form-group"><label>Description</label><textarea name="desc" class="form-control" placeholder="What exactly will you achieve?"></textarea></div>
      <div class="modal-actions">
        <button type="button" class="modal-cancel" onclick="document.getElementById('addModal').classList.remove('open')">Cancel</button>
        <button type="submit" class="modal-save">Save Goal ＋</button>
      </div>
    </form>
  </div>
</div>

</div>
<?php include '../includes/footer.php'; ?>
