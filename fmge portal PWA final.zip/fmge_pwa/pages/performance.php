<?php
require_once '../includes/config.php';
requireLogin();
$db=getDB();$uid=(int)$_SESSION['user_id'];

if($_SERVER['REQUEST_METHOD']==='POST'){
    $a=$_POST['action']??'';
    if($a==='add_mcq'){
        $sub=clean($_POST['subject']??'');$ta=(int)($_POST['total']??0);$c=(int)($_POST['correct']??0);$dt=clean($_POST['date']??date('Y-m-d'));
        if($ta>0){$stmt=$db->prepare("INSERT INTO mcq_records(user_id,subject,total_attempted,correct,record_date) VALUES(?,?,?,?,?)");$stmt->bind_param('isids',$uid,$sub,$ta,$c,$dt);$stmt->execute();$db->query("UPDATE users SET total_mcqs=total_mcqs+$ta,total_correct_mcqs=total_correct_mcqs+$c WHERE id=$uid");addXP($uid,$ta,intval($ta/2));checkBadges($uid);}
    }elseif($a==='add_exam'){
        $nm=clean($_POST['name']??'');$et=clean($_POST['etype']??'Mock');$tm=(int)($_POST['total']??0);$om=(int)($_POST['obtained']??0);$dt=clean($_POST['date']??date('Y-m-d'));$tt=(int)($_POST['time_taken']??0);$nt=clean($_POST['notes']??'');
        if($nm&&$tm){$stmt=$db->prepare("INSERT INTO exam_records(user_id,exam_name,exam_type,total_marks,obtained_marks,exam_date,time_taken,notes) VALUES(?,?,?,?,?,?,?,?)");$stmt->bind_param('issiiisi',$uid,$nm,$et,$tm,$om,$dt,$tt,$nt);$stmt->execute();addXP($uid,50,20);checkBadges($uid);}
    }elseif($a==='del_mcq'){$id=(int)($_POST['id']??0);$db->query("DELETE FROM mcq_records WHERE id=$id AND user_id=$uid");}
    elseif($a==='del_exam'){$id=(int)($_POST['id']??0);$db->query("DELETE FROM exam_records WHERE id=$id AND user_id=$uid");}
    header('Location: performance.php');exit;
}

$mcqAll=$db->query("SELECT * FROM mcq_records WHERE user_id=$uid ORDER BY record_date DESC LIMIT 50");
$examAll=$db->query("SELECT * FROM exam_records WHERE user_id=$uid ORDER BY exam_date DESC LIMIT 30");
$today=date('Y-m-d');
$totals=$db->query("SELECT SUM(total_attempted) as ta,SUM(correct) as tc FROM mcq_records WHERE user_id=$uid")->fetch_assoc();
$todayM=$db->query("SELECT SUM(total_attempted) as ta,SUM(correct) as tc FROM mcq_records WHERE user_id=$uid AND record_date='$today'")->fetch_assoc();
$examStats=$db->query("SELECT COUNT(*) as cnt,AVG(obtained_marks/total_marks*100) as avg,MAX(obtained_marks/total_marks*100) as best FROM exam_records WHERE user_id=$uid")->fetch_assoc();

// Chart data
$mcqTrend=[];$examTrend=[];
for($i=29;$i>=0;$i--){
    $d=date('Y-m-d',strtotime("-{$i} days"));
    $m=$db->query("SELECT SUM(total_attempted) as ta,SUM(correct) as tc FROM mcq_records WHERE user_id=$uid AND record_date='$d'")->fetch_assoc();
    $acc=$m['ta']>0?round($m['tc']/$m['ta']*100):null;
    $mcqTrend[]=$acc;
}
$examRecords=$db->query("SELECT obtained_marks,total_marks FROM exam_records WHERE user_id=$uid ORDER BY exam_date ASC LIMIT 15");
if($examRecords)while($e=$examRecords->fetch_assoc())$examTrend[]=round($e['obtained_marks']/$e['total_marks']*100);

$examTypes=$db->query("SELECT name FROM exam_types WHERE is_active=1 ORDER BY name");
$pageTitle='Performance';$activePage='performance';
include '../includes/header.php';
?>
<div class="page-content">

<!-- Top Stats -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;">
<?php foreach([
  ['🎯','Total MCQs',(int)($totals['ta']??0),'var(--primary)'],
  ['✅','Overall Acc',$totals['ta']>0?round($totals['tc']/$totals['ta']*100).'%':'0%','var(--success)'],
  ['📝','Exams Given',(int)($examStats['cnt']??0),'var(--accent)'],
  ['🏆','Best Score',round((float)($examStats['best']??0),1).'%','var(--danger)'],
] as $i=>$s): ?>
<div class="stat-card anim-fade-up" style="--c:<?= $s[3] ?>" data-delay="<?= $i+1 ?>">
  <span class="stat-icon"><?= $s[0] ?></span>
  <div class="stat-val"><?= $s[2] ?></div>
  <div class="stat-lbl"><?= $s[1] ?></div>
</div>
<?php endforeach; ?>
</div>

<!-- Tabs -->
<div style="display:flex;gap:4px;background:var(--card);border:1px solid var(--border);border-radius:14px;padding:5px;margin-bottom:20px;" class="anim-fade-up" data-delay="2">
  <?php foreach([['overview','📊 Overview'],['mcq','🎯 MCQ Records'],['exams','📝 Exam Marks'],['heatmap','🔥 Heatmap']] as $t): ?>
  <button onclick="switchTab('<?= $t[0] ?>',this)" class="perf-tab <?= $t[0]==='overview'?'perf-tab-active':'' ?>" style="flex:1;padding:9px 6px;border-radius:9px;border:none;font-family:'Syne',sans-serif;font-size:11px;font-weight:700;cursor:pointer;transition:all .2s;background:<?= $t[0]==='overview'?'rgba(56,182,204,.1)':'transparent' ?>;color:<?= $t[0]==='overview'?'var(--primary)':'var(--muted)' ?>;"><?= $t[1] ?></button>
  <?php endforeach; ?>
</div>

<!-- OVERVIEW -->
<div id="tab-overview" class="perf-panel">
  <div class="card mb-20">
    <div class="card-hdr"><div class="card-ttl">📈 Performance Trend</div><div class="card-sub">MCQ accuracy last 30 days</div></div>
    <div style="height:160px;"><canvas id="overviewChart"></canvas></div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
    <div class="card">
      <div class="card-ttl" style="margin-bottom:14px;">🎯 Today's MCQ</div>
      <div style="font-family:'Orbitron',monospace;font-size:28px;font-weight:900;color:var(--accent);margin-bottom:4px;"><?= $todayM['ta']>0?round($todayM['tc']/$todayM['ta']*100).'%':'—' ?></div>
      <div style="font-size:12px;color:var(--muted);"><?= (int)($todayM['ta']??0) ?> attempted · <?= (int)($todayM['tc']??0) ?> correct</div>
    </div>
    <div class="card">
      <div class="card-ttl" style="margin-bottom:14px;">📝 Last Exam</div>
      <?php $last=$db->query("SELECT exam_name,obtained_marks,total_marks FROM exam_records WHERE user_id=$uid ORDER BY exam_date DESC LIMIT 1")->fetch_assoc(); ?>
      <?php if($last): $p=round($last['obtained_marks']/$last['total_marks']*100); ?>
      <div style="font-family:'Orbitron',monospace;font-size:28px;font-weight:900;color:<?= $p>=50?'var(--success)':'var(--danger)' ?>;margin-bottom:4px;"><?= $p ?>%</div>
      <div style="font-size:12px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= clean($last['exam_name']) ?></div>
      <?php else: ?><div style="color:var(--muted);font-size:13px;">No exams yet</div><?php endif; ?>
    </div>
  </div>
</div>

<!-- MCQ RECORDS -->
<div id="tab-mcq" class="perf-panel" style="display:none;">
  <div class="card mb-16">
    <div class="card-ttl" style="margin-bottom:14px;">➕ Add MCQ Record</div>
    <form method="POST"><input type="hidden" name="action" value="add_mcq"/>
    <div class="form-row">
      <div class="form-group"><label>Subject</label><select name="subject" class="form-control"><?php foreach(['Anatomy','Physiology','Biochemistry','Pathology','Pharmacology','Microbiology','Surgery','Medicine','OBG','PSM','Mixed','Revision'] as $s): ?><option><?= $s ?></option><?php endforeach; ?></select></div>
      <div class="form-group"><label>Date</label><input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>"/></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Total Attempted *</label><input type="number" name="total" class="form-control" placeholder="50" required min="1"/></div>
      <div class="form-group"><label>Correct</label><input type="number" name="correct" class="form-control" placeholder="38" min="0"/></div>
    </div>
    <button type="submit" class="btn btn-primary">💾 Save MCQ Record</button>
    </form>
  </div>
  <div class="card">
    <div class="card-ttl" style="margin-bottom:14px;">📋 MCQ History</div>
    <?php if($mcqAll&&$mcqAll->num_rows>0):while($r=$mcqAll->fetch_assoc()):$acc=$r['total_attempted']>0?round($r['correct']/$r['total_attempted']*100):0;$col=$acc>=70?'var(--success)':($acc>=50?'var(--accent)':'var(--danger)'); ?>
    <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);">
      <div style="width:8px;height:8px;border-radius:50%;background:var(--primary);flex-shrink:0;"></div>
      <div style="flex:1;"><div style="font-size:13px;font-weight:600;"><?= clean($r['subject']) ?></div><div style="font-size:10px;color:var(--muted);"><?= $r['correct'] ?>/<?= $r['total_attempted'] ?> correct · <?= date('d M',strtotime($r['record_date'])) ?></div></div>
      <div style="font-family:'JetBrains Mono',monospace;font-size:14px;font-weight:800;color:<?= $col ?>"><?= $acc ?>%</div>
      <form method="POST"><input type="hidden" name="action" value="del_mcq"/><input type="hidden" name="id" value="<?= $r['id'] ?>"/><button type="submit" class="btn btn-danger btn-sm">🗑️</button></form>
    </div>
    <?php endwhile;else:?><p style="color:var(--muted);font-size:13px;padding:20px 0;">No records yet.</p><?php endif;?>
  </div>
</div>

<!-- EXAM MARKS -->
<div id="tab-exams" class="perf-panel" style="display:none;">
  <div class="card mb-16">
    <div class="card-ttl" style="margin-bottom:14px;">➕ Add Exam Record</div>
    <form method="POST"><input type="hidden" name="action" value="add_exam"/>
    <div class="form-row">
      <div class="form-group"><label>Exam Name *</label><input type="text" name="name" class="form-control" placeholder="e.g. Anatomy Mock #4" required/></div>
      <div class="form-group"><label>Type</label><select name="etype" class="form-control"><?php if($examTypes)while($et=$examTypes->fetch_assoc()):?><option><?= clean($et['name']) ?></option><?php endwhile;?></select></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Total Marks *</label><input type="number" name="total" class="form-control" placeholder="200" required/></div>
      <div class="form-group"><label>Obtained *</label><input type="number" name="obtained" class="form-control" placeholder="156" required/></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Date *</label><input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required/></div>
      <div class="form-group"><label>Time (mins)</label><input type="number" name="time_taken" class="form-control" placeholder="180"/></div>
    </div>
    <div class="form-group"><label>Notes</label><input type="text" name="notes" class="form-control" placeholder="Weak areas, observations..."/></div>
    <button type="submit" class="btn btn-primary" style="background:linear-gradient(135deg,var(--accent),var(--danger));">💾 Save Exam</button>
    </form>
  </div>
  <div class="card">
    <?php if($examAll&&$examAll->num_rows>0):$medals=['🥇','🥈','🥉'];$rank=0;while($r=$examAll->fetch_assoc()):$p=round($r['obtained_marks']/$r['total_marks']*100);$col=$p>=80?'var(--success)':($p>=60?'var(--accent)':'var(--danger)'); ?>
    <div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);">
      <div style="font-size:18px;"><?= $medals[$rank]??'#'.($rank+1) ?></div>
      <div style="flex:1;"><div style="font-size:13px;font-weight:700;"><?= clean($r['exam_name']) ?></div><div style="font-size:10px;color:var(--muted);"><?= clean($r['exam_type']) ?> · <?= date('d M Y',strtotime($r['exam_date'])) ?></div><?php if($r['notes']):?><div style="font-size:10px;color:var(--muted);margin-top:2px;">📝 <?= clean($r['notes']) ?></div><?php endif;?></div>
      <div style="text-align:right;"><div style="font-family:'Orbitron',monospace;font-size:18px;font-weight:900;color:<?= $col ?>"><?= $p ?>%</div><div style="font-size:10px;color:var(--muted);"><?= $r['obtained_marks'] ?>/<?= $r['total_marks'] ?></div></div>
      <form method="POST"><input type="hidden" name="action" value="del_exam"/><input type="hidden" name="id" value="<?= $r['id'] ?>"/><button type="submit" class="btn btn-danger btn-sm">🗑️</button></form>
    </div>
    <?php $rank++;endwhile;else:?><p style="color:var(--muted);font-size:13px;padding:20px 0;">No exams yet.</p><?php endif;?>
  </div>
</div>

<!-- HEATMAP -->
<div id="tab-heatmap" class="perf-panel" style="display:none;">
  <div class="card">
    <div class="card-hdr"><div><div class="card-ttl">🔥 MCQ Activity — Last 12 Weeks</div><div class="card-sub">Darker = More MCQs</div></div></div>
    <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;margin-bottom:6px;" id="hmGrid"></div>
    <div style="display:flex;align-items:center;gap:6px;justify-content:flex-end;margin-top:6px;">
      <span style="font-size:10px;color:var(--muted2);">Less</span>
      <?php foreach([.06,.2,.45,.7,.9] as $o): ?>
      <div style="width:10px;height:10px;border-radius:2px;background:rgba(56,182,204,<?= $o ?>);"></div>
      <?php endforeach; ?>
      <span style="font-size:10px;color:var(--muted2);">More</span>
    </div>
  </div>
</div>

</div>

<script>
// Tab switching
function switchTab(name,btn){
  document.querySelectorAll('.perf-panel').forEach(p=>p.style.display='none');
  document.querySelectorAll('.perf-tab').forEach(t=>{t.style.background='transparent';t.style.color='var(--muted)';});
  document.getElementById('tab-'+name).style.display='block';
  btn.style.background='rgba(56,182,204,.1)';btn.style.color='var(--primary)';
}

// Overview chart
const mcqTrend = <?= json_encode($mcqTrend) ?>;
const primary = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim();
const ctx = document.getElementById('overviewChart');
if(ctx){
  const labels = Array.from({length:30},(_,i)=>{const d=new Date();d.setDate(d.getDate()-(29-i));return i%5===0?d.toLocaleDateString('en',{month:'short',day:'numeric'}):''});
  new Chart(ctx.getContext('2d'),{type:'line',data:{labels,datasets:[{data:mcqTrend,borderColor:primary,borderWidth:2,fill:true,backgroundColor:primary+'18',tension:.4,pointRadius:mcqTrend.map((v,i)=>i===29?5:v!==null?2:0),pointBackgroundColor:primary,spanGaps:true}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{min:0,max:100,ticks:{callback:v=>v+'%',color:'var(--muted)',font:{size:9}},grid:{color:'rgba(255,255,255,.04)'}},x:{ticks:{color:'var(--muted)',font:{size:9}},grid:{display:false}}}}});
}

// Heatmap
const hmGrid = document.getElementById('hmGrid');
if(hmGrid){
  for(let i=0;i<84;i++){
    const v=Math.random();const isToday=i===83;
    const cell=document.createElement('div');
    cell.style.cssText='aspect-ratio:1;border-radius:3px;cursor:pointer;transition:transform .2s;';
    cell.style.background=isToday?primary:(v<.3?'rgba(56,182,204,.06)':(v<.5?'rgba(56,182,204,.2)':(v<.7?'rgba(56,182,204,.45)':(v<.85?'rgba(56,182,204,.7)':'rgba(56,182,204,.9)'))));
    if(isToday)cell.style.boxShadow='0 0 8px rgba(56,182,204,.5)';
    cell.addEventListener('mouseover',()=>cell.style.transform='scale(1.3)');
    cell.addEventListener('mouseout',()=>cell.style.transform='');
    hmGrid.appendChild(cell);
  }
}
</script>
<?php include '../includes/footer.php'; ?>
