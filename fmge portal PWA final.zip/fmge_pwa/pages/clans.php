<?php
require_once '../includes/config.php';
requireLogin();
$db = getDB();
$uid = (int)$_SESSION['user_id'];
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $name = clean($_POST['clan_name'] ?? '');
        $desc = clean($_POST['clan_desc'] ?? '');
        if ($name) {
            // Check if already in a clan
            $inClan = $db->query("SELECT id FROM clan_members WHERE user_id=$uid")->num_rows;
            if (!$inClan) {
                $stmt = $db->prepare("INSERT INTO clans (name,description,leader_id) VALUES (?,?,?)");
                $stmt->bind_param('ssi', $name, $desc, $uid);
                $stmt->execute();
                $cid = $db->insert_id;
                $db->query("INSERT INTO clan_members (clan_id,user_id) VALUES ($cid,$uid)");
                addXP($uid, 100, 50); checkBadges($uid);
                $msg = "Clan '$name' created!";
            } else { $msg = "You are already in a clan!"; }
        }
    } elseif ($action === 'join') {
        $cid = (int)($_POST['clan_id'] ?? 0);
        $inClan = $db->query("SELECT id FROM clan_members WHERE user_id=$uid")->num_rows;
        if (!$inClan && $cid) {
            $db->query("INSERT INTO clan_members (clan_id,user_id) VALUES ($cid,$uid)");
            addXP($uid, 50, 25); checkBadges($uid);
            $msg = "Joined clan!";
        }
    } elseif ($action === 'leave') {
        $db->query("DELETE FROM clan_members WHERE user_id=$uid");
        $msg = "Left clan.";
    }
    header('Location: clans.php'); exit;
}

$myClan = $db->query("SELECT c.*,cm.joined_at FROM clan_members cm JOIN clans c ON c.id=cm.clan_id WHERE cm.user_id=$uid")->fetch_assoc();
$allClans = $db->query("SELECT c.*, COUNT(cm.id) as member_count, SUM(u.total_study_minutes) as total_mins FROM clans c LEFT JOIN clan_members cm ON cm.clan_id=c.id LEFT JOIN users u ON u.id=cm.user_id GROUP BY c.id ORDER BY total_mins DESC LIMIT 20");
$clanList = []; if ($allClans) while ($r=$allClans->fetch_assoc()) $clanList[] = $r;

$pageTitle = 'Clans';
$activePage = 'clans';
include '../includes/header.php';
?>
<div class="page-content">

<?php if ($msg): ?><div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:10px;padding:12px 16px;margin-bottom:20px;font-size:13px;font-weight:600;color:var(--success);">✅ <?= $msg ?></div><?php endif; ?>

<?php if ($myClan): ?>
<!-- My Clan -->
<div style="background:linear-gradient(135deg,rgba(124,58,237,.1),rgba(0,212,255,.05));border:1px solid rgba(124,58,237,.3);border-radius:18px;padding:24px;margin-bottom:24px;">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;margin-bottom:16px;">
    <div>
      <div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">My Clan</div>
      <h2 style="font-family:'Orbitron',monospace;font-size:20px;color:var(--secondary);">⚔️ <?= clean($myClan['name']) ?></h2>
      <?php if ($myClan['description']): ?><p style="font-size:13px;color:var(--muted);margin-top:4px;"><?= clean($myClan['description']) ?></p><?php endif; ?>
    </div>
    <form method="POST"><input type="hidden" name="action" value="leave"/><button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Leave clan?')">Leave Clan</button></form>
  </div>
  <?php
  $members = $db->query("SELECT u.full_name,u.avatar,u.level,u.rank_title,u.total_study_minutes,u.streak_days FROM clan_members cm JOIN users u ON u.id=cm.user_id WHERE cm.clan_id={$myClan['id']} ORDER BY u.total_study_minutes DESC");
  if ($members): ?>
  <div style="display:grid;gap:8px;">
    <?php while ($m=$members->fetch_assoc()):
      $ri = getRank($m['level']);
    ?>
    <div style="display:flex;align-items:center;gap:10px;padding:10px;background:rgba(0,0,0,.2);border-radius:10px;">
      <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:13px;color:#fff;font-weight:700;overflow:hidden;flex-shrink:0;">
        <?php if (!empty($m['avatar'])): ?><img src="<?= SITE_URL ?>/uploads/avatars/<?= clean($m['avatar']) ?>" style="width:100%;height:100%;object-fit:cover;"/><?php else: ?><?= strtoupper(substr($m['full_name'],0,1)) ?><?php endif; ?>
      </div>
      <div style="flex:1;"><div style="font-size:13px;font-weight:600;"><?= clean($m['full_name']) ?></div><div style="font-size:10px;color:var(--muted);">Lv.<?= $m['level'] ?> <?= $ri[0] ?>-Rank • 🔥<?= $m['streak_days'] ?>d</div></div>
      <div style="font-family:'Orbitron',monospace;font-size:12px;font-weight:700;color:var(--primary);"><?= floor($m['total_study_minutes']/60) ?>h</div>
    </div>
    <?php endwhile; ?>
  </div>
  <?php endif; ?>
</div>
<?php else: ?>

<!-- Create Clan -->
<div class="card" style="margin-bottom:20px;">
  <div class="card-title" style="margin-bottom:14px;">⚔️ Create a Clan</div>
  <form method="POST"><input type="hidden" name="action" value="create"/>
  <div class="form-group"><label>Clan Name *</label><input type="text" name="clan_name" class="form-control" placeholder="e.g. FMGE Warriors" required/></div>
  <div class="form-group"><label>Description</label><input type="text" name="clan_desc" class="form-control" placeholder="What is your clan about?"/></div>
  <button type="submit" class="btn btn-primary">⚔️ Create Clan</button>
  </form>
</div>

<!-- All Clans -->
<div class="card">
  <div class="card-title" style="margin-bottom:14px;">🏆 All Clans</div>
  <?php if (!empty($clanList)): foreach ($clanList as $c): ?>
  <div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);">
    <div style="font-size:28px;">⚔️</div>
    <div style="flex:1;">
      <div style="font-size:14px;font-weight:700;"><?= clean($c['name']) ?></div>
      <div style="font-size:11px;color:var(--muted);"><?= $c['member_count'] ?> members • <?= floor(($c['total_mins']??0)/60) ?>h total study</div>
    </div>
    <form method="POST"><input type="hidden" name="action" value="join"/><input type="hidden" name="clan_id" value="<?= $c['id'] ?>"/><button type="submit" class="btn btn-sm btn-primary">Join</button></form>
  </div>
  <?php endforeach; else: ?>
  <p style="color:var(--muted);font-size:13px;">No clans yet. Create the first one!</p>
  <?php endif; ?>
</div>
<?php endif; ?>

</div>
<?php include '../includes/footer.php'; ?>
