// ═══════════════════════════════════════════════
// FMGE PORTAL — Service Worker v2.0
// Caching + Offline + Background Sync
// ═══════════════════════════════════════════════

const CACHE_NAME    = 'fmge-v2';
const STATIC_CACHE  = 'fmge-static-v2';
const DYNAMIC_CACHE = 'fmge-dynamic-v2';

// Files to cache immediately on install
const STATIC_FILES = [
  '/',
  '/index.php',
  '/dashboard.php',
  '/manifest.json',
  '/assets/style.css',
  '/assets/icons/icon-192.png',
  '/assets/icons/icon-512.png',
  'https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;700&family=JetBrains+Mono:wght@400;600&display=swap',
];

const OFFLINE_PAGE = '/offline.html';

// ── INSTALL ──
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(STATIC_CACHE).then(cache => {
      return cache.addAll(STATIC_FILES.filter(url => !url.startsWith('http') || url.includes('fonts.googleapis')));
    }).then(() => self.skipWaiting())
  );
});

// ── ACTIVATE ──
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys
        .filter(k => k !== STATIC_CACHE && k !== DYNAMIC_CACHE)
        .map(k => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// ── FETCH ──
self.addEventListener('fetch', e => {
  const req = e.request;
  const url = new URL(req.url);

  // Skip non-GET, chrome-extension, API calls
  if (req.method !== 'GET') return;
  if (url.protocol === 'chrome-extension:') return;

  // API calls — network first, no cache
  if (url.pathname.startsWith('/api/')) {
    e.respondWith(
      fetch(req).catch(() => new Response(JSON.stringify({success:false,error:'Offline'}),
        {headers:{'Content-Type':'application/json'}}))
    );
    return;
  }

  // PHP pages — network first, fallback to cache
  if (url.pathname.endsWith('.php') || url.pathname === '/') {
    e.respondWith(
      fetch(req)
        .then(res => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(DYNAMIC_CACHE).then(c => c.put(req, clone));
          }
          return res;
        })
        .catch(async () => {
          const cached = await caches.match(req);
          return cached || caches.match(OFFLINE_PAGE) || new Response(
            '<html><body style="background:#03030a;color:#8b5cf6;font-family:sans-serif;text-align:center;padding:60px"><h1>⚕️ FMGE Portal</h1><p>You are offline. Please connect to internet.</p></body></html>',
            {headers:{'Content-Type':'text/html'}}
          );
        })
    );
    return;
  }

  // Static assets — cache first
  e.respondWith(
    caches.match(req).then(cached => {
      if (cached) return cached;
      return fetch(req).then(res => {
        if (res.ok) {
          const clone = res.clone();
          caches.open(STATIC_CACHE).then(c => c.put(req, clone));
        }
        return res;
      }).catch(() => cached);
    })
  );
});

// ── PUSH NOTIFICATIONS ──
self.addEventListener('push', e => {
  let data = { title: 'FMGE Portal', body: 'Time to study! 📚', icon: '/assets/icons/icon-192.png' };
  try { data = { ...data, ...e.data.json() }; } catch {}
  e.waitUntil(
    self.registration.showNotification(data.title, {
      body:    data.body,
      icon:    data.icon || '/assets/icons/icon-192.png',
      badge:   '/assets/icons/icon-96.png',
      vibrate: [200, 100, 200],
      data:    { url: data.url || '/dashboard.php' },
      actions: [
        { action: 'open',    title: '▶ Open Portal' },
        { action: 'dismiss', title: '✕ Dismiss' }
      ]
    })
  );
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  if (e.action === 'dismiss') return;
  e.waitUntil(clients.openWindow(e.notification.data?.url || '/dashboard.php'));
});

// ── BACKGROUND SYNC ──
self.addEventListener('sync', e => {
  if (e.tag === 'sync-sessions') {
    e.waitUntil(syncPendingSessions());
  }
});

async function syncPendingSessions() {
  // Sync any offline-saved sessions when back online
  const db = await openIDB();
  const pending = await getAllPending(db);
  for (const session of pending) {
    try {
      await fetch('/api/save_session.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(session)
      });
      await deletePending(db, session.id);
    } catch {}
  }
}

function openIDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open('fmge-offline', 1);
    r.onupgradeneeded = e => e.target.result.createObjectStore('pending', {keyPath:'id',autoIncrement:true});
    r.onsuccess = e => res(e.target.result);
    r.onerror = rej;
  });
}
function getAllPending(db) {
  return new Promise((res,rej) => {
    const tx = db.transaction('pending','readonly');
    const req = tx.objectStore('pending').getAll();
    req.onsuccess = () => res(req.result);
    req.onerror = rej;
  });
}
function deletePending(db, id) {
  return new Promise((res,rej) => {
    const tx = db.transaction('pending','readwrite');
    tx.objectStore('pending').delete(id);
    tx.oncomplete = res;
    tx.onerror = rej;
  });
}
