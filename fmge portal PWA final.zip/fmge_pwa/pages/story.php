<?php
require_once '../includes/config.php';
requireLogin();
$db = getDB();
$uid = (int)$_SESSION['user_id'];

checkStoryProgress($uid);

$allChapters = $db->query("SELECT sc.*, us.unlocked_at FROM story_chapters sc LEFT JOIN user_story us ON us.chapter_id=sc.id AND us.user_id=$uid ORDER BY sc.chapter_num ASC");
$chapters = []; if ($allChapters) while ($r=$allChapters->fetch_assoc()) $chapters[] = $r;
$unlocked = count(array_filter($chapters, fn($c) => $c['unlocked_at']));
$total = count($chapters);

$pageTitle = 'Story Mode';
$activePage = 'story';
include '../includes/header.php';
?>
<div class="page-content">

<!-- Hero -->
<div style="background:linear-gradient(135deg,rgba(124,58,237,.15),rgba(0,212,255,.08));border:1px solid rgba(124,58,237,.3);border-radius:20px;padding:28px 32px;margin-bottom:28px;text-align:center;">
  <div style="font-size:48px;margin-bottom:12px;animation:float 3s ease-in-out infinite;">📖</div>
  <h1 style="font-family:'Orbitron',monospace;font-size:22px;color:var(--secondary);margin-bottom:8px;">YOUR DOCTOR STORY</h1>
  <p style="color:var(--muted);font-size:13px;margin-bottom:16px;">Your journey from medical graduate to FMGE champion</p>
  <div style="max-width:300px;margin:0 auto;">
    <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--muted);margin-bottom:4px;"><span>Progress</span><span><?= $unlocked ?>/<?= $total ?> Chapters</span></div>
    <div class="prog-track"><div class="prog-fill" style="width:<?= $total>0?round($unlocked/$total*100):0 ?>%;background:linear-gradient(90deg,var(--secondary),var(--primary));"></div></div>
  </div>
</div>

<!-- Chapters Timeline -->
<div style="position:relative;padding-left:32px;">
  <div style="position:absolute;left:12px;top:0;bottom:0;width:2px;background:linear-gradient(180deg,var(--secondary),var(--primary),transparent);border-radius:1px;"></div>

  <?php foreach ($chapters as $i => $ch):
    $isUnlocked = !empty($ch['unlocked_at']);
    $isNext = !$isUnlocked && ($i === 0 || !empty($chapters[$i-1]['unlocked_at']));
  ?>
  <div style="position:relative;margin-bottom:20px;opacity:<?= $isUnlocked?'1':($isNext?'.7':'.3') ?>;transition:all .3s;" <?= $isUnlocked?'onmouseover="this.style.transform=\'translateX(4px)\'" onmouseout="this.style.transform=\'\'"':''; ?>>
    <!-- Dot -->
    <div style="position:absolute;left:-26px;top:12px;width:14px;height:14px;border-radius:50%;border:2px solid <?= $isUnlocked?'var(--secondary)':'var(--border)' ?>;background:<?= $isUnlocked?'var(--secondary)':'var(--bg)' ?>;box-shadow:<?= $isUnlocked?'0 0 12px rgba(124,58,237,.5)':'none' ?>;"></div>

    <div style="padding:18px 20px;border-radius:14px;border:1px solid <?= $isUnlocked?'rgba(124,58,237,.3)':'var(--border)' ?>;background:<?= $isUnlocked?'rgba(124,58,237,.05)':'var(--card)' ?>;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;flex-wrap:wrap;gap:8px;">
        <div>
          <div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Chapter <?= $ch['chapter_num'] ?></div>
          <h3 style="font-family:'Orbitron',monospace;font-size:15px;color:<?= $isUnlocked?'var(--secondary)':'var(--muted)' ?>;"><?= clean($ch['title']) ?></h3>
        </div>
        <?php if ($isUnlocked): ?>
        <span style="font-size:10px;background:rgba(124,58,237,.15);color:var(--secondary);border:1px solid rgba(124,58,237,.3);border-radius:6px;padding:2px 8px;font-weight:700;">✅ UNLOCKED</span>
        <?php elseif ($isNext): ?>
        <span style="font-size:10px;background:rgba(245,158,11,.1);color:var(--accent);border:1px solid rgba(245,158,11,.2);border-radius:6px;padding:2px 8px;font-weight:700;">🔓 NEXT</span>
        <?php else: ?>
        <span style="font-size:10px;background:var(--bg2);color:var(--muted);border:1px solid var(--border);border-radius:6px;padding:2px 8px;">🔒 LOCKED</span>
        <?php endif; ?>
      </div>

      <?php if ($isUnlocked): ?>
      <p style="font-size:13px;color:var(--text);line-height:1.7;font-style:italic;">"<?= clean($ch['story_text']) ?>"</p>
      <?php if ($ch['unlocked_at']): ?>
      <div style="font-size:10px;color:var(--muted);margin-top:8px;">Unlocked: <?= date('d M Y', strtotime($ch['unlocked_at'])) ?></div>
      <?php endif; ?>
      <?php elseif ($isNext): ?>
      <div style="font-size:12px;color:var(--muted);">
        Unlock requirement: 
        <?php
        $reqs = ['level'=>'Reach Level '.$ch['unlock_value'],'study_hours'=>'Study '.$ch['unlock_value'].' hours','total_mcqs'=>'Attempt '.$ch['unlock_value'].' MCQs','streak'=>$ch['unlock_value'].' day streak','partners'=>'Get '.$ch['unlock_value'].' study partner','exams'=>'Complete '.$ch['unlock_value'].' exams'];
        echo $reqs[$ch['unlock_requirement']] ?? 'Keep progressing';
        ?>
      </div>
      <?php else: ?>
      <div style="font-size:12px;color:var(--muted);">Keep progressing to unlock this chapter...</div>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>

</div>
<?php include '../includes/footer.php'; ?>
