<?php
require_once '../includes/config.php';
requireLogin();
$db=getDB();$uid=(int)$_SESSION['user_id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
    $a=$_POST['action']??'';
    if($a==='post'){$t=clean($_POST['post_text']??'');$pt=clean($_POST['post_type']??'update');if($t){$stmt=$db->prepare("INSERT INTO community_posts (user_id,post_text,post_type) VALUES (?,?,?)");$stmt->bind_param('iss',$uid,$t,$pt);$stmt->execute();addXP($uid,10,5);checkBadges($uid);}}
    elseif($a==='like'){$pid=(int)($_POST['post_id']??0);$ex=$db->query("SELECT id FROM community_likes WHERE user_id=$uid AND post_id=$pid")->num_rows;if($ex){$db->query("DELETE FROM community_likes WHERE user_id=$uid AND post_id=$pid");$db->query("UPDATE community_posts SET likes_count=GREATEST(0,likes_count-1) WHERE id=$pid");}else{$db->query("INSERT IGNORE INTO community_likes (user_id,post_id) VALUES ($uid,$pid)");$db->query("UPDATE community_posts SET likes_count=likes_count+1 WHERE id=$pid");}$cnt=$db->query("SELECT likes_count FROM community_posts WHERE id=$pid")->fetch_assoc()['likes_count'];echo json_encode(['likes'=>$cnt]);exit;}
    elseif($a==='delete'){$pid=(int)($_POST['post_id']??0);$db->query("DELETE FROM community_posts WHERE id=$pid AND user_id=$uid");}
    if($a!=='like'){header('Location: community.php');exit;}
}
$posts=$db->query("SELECT cp.*,u.full_name,u.username,u.avatar,u.level,u.rank_title,u.streak_days FROM community_posts cp JOIN users u ON u.id=cp.user_id WHERE u.is_banned=0 ORDER BY cp.created_at DESC LIMIT 50");
$pageTitle='Community';$activePage='community';
include '../includes/header.php';
?>
<div class="page-content"><div style="max-width:660px;margin:0 auto;">
<div class="card" style="margin-bottom:20px;">
<form method="POST"><input type="hidden" name="action" value="post"/>
<div style="display:flex;gap:12px;margin-bottom:12px;">
<div style="width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:15px;color:#fff;font-weight:700;flex-shrink:0;"><?=strtoupper(substr($_SESSION['full_name'],0,1))?></div>
<textarea name="post_text" class="form-control" placeholder="Share your progress, ask a question, or motivate others! 🚀" rows="3" required></textarea>
</div>
<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
<select name="post_type" class="form-control" style="width:auto;padding:8px 12px;">
<option value="update">📝 Update</option><option value="achievement">🏆 Achievement</option><option value="question">❓ Question</option><option value="tip">💡 Study Tip</option>
</select>
<button type="submit" class="btn btn-primary">🚀 Post</button>
</div>
</form>
</div>
<?php if($posts&&$posts->num_rows>0):while($p=$posts->fetch_assoc()):
$isLiked=$db->query("SELECT id FROM community_likes WHERE user_id=$uid AND post_id={$p['id']}")->num_rows>0;
$typeIcons=['update'=>'📝','achievement'=>'🏆','question'=>'❓','tip'=>'💡'];
$rankInfo=getRank($p['level']??1);
?>
<div class="card" style="margin-bottom:12px;">
<div style="display:flex;gap:12px;">
<a href="<?=SITE_URL?>/pages/profile.php?id=<?=$p['user_id']?>" style="text-decoration:none;flex-shrink:0;">
<div style="width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:16px;color:#fff;font-weight:700;overflow:hidden;border:2px solid <?=$rankInfo[1]?>44;">
<?php if(!empty($p['avatar'])):?><img src="<?=SITE_URL?>/uploads/avatars/<?=clean($p['avatar'])?>" style="width:100%;height:100%;object-fit:cover;"/><?php else:?><?=strtoupper(substr($p['full_name'],0,1))?><?php endif;?>
</div>
</a>
<div style="flex:1;">
<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;">
<a href="<?=SITE_URL?>/pages/profile.php?id=<?=$p['user_id']?>" style="font-weight:700;font-size:13px;color:var(--text);text-decoration:none;"><?=clean($p['full_name'])?></a>
<span style="font-size:9px;font-family:'Orbitron',monospace;color:<?=$rankInfo[1]?>;border:1px solid <?=$rankInfo[1]?>44;padding:1px 6px;border-radius:4px;"><?=$rankInfo[0]?></span>
<?php if($p['streak_days']>0):?><span style="font-size:10px;background:rgba(244,63,94,.1);color:var(--danger);padding:1px 6px;border-radius:6px;font-weight:700;">🔥<?=$p['streak_days']?>d</span><?php endif;?>
<span style="font-size:10px;color:var(--muted);margin-left:auto;"><?=date('d M, h:i A',strtotime($p['created_at']))?></span>
</div>
<div style="font-size:10px;margin-bottom:8px;"><span style="background:var(--bg2);border:1px solid var(--border);border-radius:6px;padding:2px 7px;"><?=$typeIcons[$p['post_type']]??'📝'?> <?=ucfirst($p['post_type'])?></span></div>
<div style="font-size:13px;color:var(--text);line-height:1.6;margin-bottom:10px;"><?=nl2br(clean($p['post_text']))?></div>
<div style="display:flex;gap:12px;align-items:center;">
<button onclick="likePost(<?=$p['id']?>)" id="like-btn-<?=$p['id']?>" style="background:none;border:none;cursor:pointer;font-size:13px;font-weight:700;color:<?=$isLiked?'var(--danger)':'var(--muted)'?>;display:flex;align-items:center;gap:4px;transition:color .2s;font-family:'Inter',sans-serif;"><?=$isLiked?'❤️':'🤍'?> <span id="lc-<?=$p['id']?>"><?=$p['likes_count']?></span></button>
<?php if($p['user_id']===$uid):?><form method="POST" style="display:inline;"><input type="hidden" name="action" value="delete"/><input type="hidden" name="post_id" value="<?=$p['id']?>"/><button type="submit" style="background:none;border:none;cursor:pointer;font-size:12px;color:var(--muted);font-family:'Inter',sans-serif;">🗑️ Delete</button></form><?php endif;?>
</div>
</div>
</div>
</div>
<?php endwhile;else:?>
<div style="text-align:center;padding:48px;color:var(--muted);"><div style="font-size:40px;margin-bottom:12px;">👥</div><div style="font-size:14px;font-weight:600;">No posts yet! Be the first 🚀</div></div>
<?php endif;?>
</div></div>
<script>function likePost(id){const fd=new FormData();fd.append('action','like');fd.append('post_id',id);fetch('community.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{const btn=document.getElementById('like-btn-'+id);const cnt=document.getElementById('lc-'+id);cnt.textContent=d.likes;const liked=btn.innerHTML.includes('❤️');btn.innerHTML=(liked?'🤍':'❤️')+' <span id="lc-'+id+'">'+d.likes+'</span>';btn.style.color=liked?'var(--muted)':'var(--danger)';});}</script>
<?php include '../includes/footer.php';?>
