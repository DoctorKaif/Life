<?php
require_once '../includes/config.php';
requireLogin();
$db=getDB();$uid=(int)$_SESSION['user_id'];
$viewId=isset($_GET['id'])?(int)$_GET['id']:$uid;
$isOwn=($viewId===$uid);
$pu=$db->query("SELECT * FROM users WHERE id=$viewId AND is_active=1")->fetch_assoc();
if(!$pu){header('Location: ../dashboard.php');exit;}
$msg='';
if($isOwn&&$_SERVER['REQUEST_METHOD']==='POST'){
    $a=$_POST['action']??'';
    if($a==='update'){
        $fn=clean($_POST['full_name']??'');$em=clean($_POST['email']??'');$bio=clean($_POST['bio']??'');$te=clean($_POST['target_exam']??'FMGE');$ed=clean($_POST['exam_date']??'');
        $stmt=$db->prepare("UPDATE users SET full_name=?,email=?,bio=?,target_exam=?,exam_date=? WHERE id=?");
        $stmt->bind_param('sssssi',$fn,$em,$bio,$te,$ed,$uid);$stmt->execute();
        $_SESSION['full_name']=$fn;$msg='Profile updated!';$pu=$db->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
    } elseif($a==='upload_avatar'&&isset($_FILES['avatar'])){
        $ext=strtolower(pathinfo($_FILES['avatar']['name'],PATHINFO_EXTENSION));
        if(in_array($ext,['jpg','jpeg','png','gif'])&&$_FILES['avatar']['size']<2097152){
            $fn2='avatar_'.$uid.'_'.time().'.'.$ext;
            if(move_uploaded_file($_FILES['avatar']['tmp_name'],'../uploads/avatars/'.$fn2)){
                $db->query("UPDATE users SET avatar='$fn2' WHERE id=$uid");$msg='Avatar updated!';$pu['avatar']=$fn2;
            }
        }
    } elseif($a==='upload_banner'&&isset($_FILES['banner'])){
        $ext=strtolower(pathinfo($_FILES['banner']['name'],PATHINFO_EXTENSION));
        if(in_array($ext,['jpg','jpeg','png','gif'])&&$_FILES['banner']['size']<5242880){
            $fn2='banner_'.$uid.'_'.time().'.'.$ext;
            if(move_uploaded_file($_FILES['banner']['tmp_name'],'../uploads/banners/'.$fn2)){
                $db->query("UPDATE users SET banner='$fn2' WHERE id=$uid");$msg='Banner updated!';$pu['banner']=$fn2;
            }
        }
    } elseif($a==='change_pass'){
        $old=$_POST['old_pass']??'';$new=$_POST['new_pass']??'';$conf=$_POST['conf_pass']??'';
        if($new!==$conf)$msg='Passwords do not match!';
        elseif(!password_verify($old,$pu['password']))$msg='Old password incorrect!';
        else{$hash=password_hash($new,PASSWORD_DEFAULT);$db->query("UPDATE users SET password='$hash' WHERE id=$uid");$msg='Password changed!';}
    }
}
$rankInfo=getRank($pu['level']??1);
$xpPct=xpForLevel($pu['level']??1)>0?min(100,round(($pu['xp']??0)/xpForLevel($pu['level']??1)*100)):0;
$totalStudy=(int)($db->query("SELECT SUM(duration_minutes) as t FROM study_sessions WHERE user_id=$viewId")->fetch_assoc()['t']??0);
$totalMcq=(int)($db->query("SELECT SUM(total_attempted) as t FROM mcq_records WHERE user_id=$viewId")->fetch_assoc()['t']??0);
$totalExams=(int)($db->query("SELECT COUNT(*) as t FROM exam_records WHERE user_id=$viewId")->fetch_assoc()['t']??0);
$avgScore=round((float)($db->query("SELECT AVG(obtained_marks/total_marks*100) as t FROM exam_records WHERE user_id=$viewId")->fetch_assoc()['t']??0),1);
$badges=$db->query("SELECT b.* FROM user_badges ub JOIN badges b ON b.id=ub.badge_id WHERE ub.user_id=$viewId ORDER BY ub.earned_at DESC");
$bList=[];if($badges)while($r=$badges->fetch_assoc())$bList[]=$r;
$pageTitle=clean($pu['full_name'])."'s Profile";$activePage='profile';
include '../includes/header.php';
?>
<div style="padding:0;">
<!-- BANNER -->
<div style="position:relative;height:170px;overflow:hidden;background:linear-gradient(135deg,<?= $rankInfo[1] ?>22,var(--secondary)22);cursor:<?=$isOwn?'pointer':'default'?>;" <?=$isOwn?'onclick="document.getElementById(\'bannerInput\').click()"':'';?>>
  <?php if(!empty($pu['banner'])):?>
  <img src="<?=SITE_URL?>/uploads/banners/<?=clean($pu['banner'])?>" style="width:100%;height:100%;object-fit:cover;"/>
  <?php else:?>
  <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:70px;opacity:.15;">⚕️</div>
  <?php if($isOwn):?><div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;"><div style="background:rgba(0,0,0,.6);color:var(--primary);font-size:12px;padding:8px 18px;border-radius:20px;border:1px solid var(--primary);">📷 Click to upload banner</div></div><?php endif;?>
  <?php endif;?>
  <?php if($isOwn):?>
  <form method="POST" enctype="multipart/form-data" style="display:none;"><input type="hidden" name="action" value="upload_banner"/><input type="file" id="bannerInput" name="banner" accept="image/*" onchange="this.form.submit()"/></form>
  <?php endif;?>
</div>

<div style="padding:0 24px 24px;">
  <!-- AVATAR -->
  <div style="position:relative;margin-top:-46px;margin-bottom:14px;display:inline-block;">
    <div style="width:90px;height:90px;border-radius:50%;border:3px solid var(--bg);overflow:hidden;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:32px;color:#fff;font-weight:700;cursor:<?=$isOwn?'pointer':'default'?>;box-shadow:0 0 20px var(--glow);" <?=$isOwn?'onclick="document.getElementById(\'avatarInput\').click()"':'';?>>
      <?php if(!empty($pu['avatar'])):?><img src="<?=SITE_URL?>/uploads/avatars/<?=clean($pu['avatar'])?>" style="width:100%;height:100%;object-fit:cover;"/><?php else:?><?=strtoupper(substr($pu['full_name'],0,1))?><?php endif;?>
    </div>
    <?php if($isOwn):?>
    <div style="position:absolute;bottom:2px;right:2px;width:22px;height:22px;background:var(--primary);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;border:2px solid var(--bg);cursor:pointer;" onclick="document.getElementById('avatarInput').click()">📷</div>
    <form method="POST" enctype="multipart/form-data" style="display:none;"><input type="hidden" name="action" value="upload_avatar"/><input type="file" id="avatarInput" name="avatar" accept="image/*" onchange="this.form.submit()"/></form>
    <?php endif;?>
  </div>

  <?php if($msg):?><div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:10px;padding:10px 16px;margin-bottom:14px;font-size:13px;font-weight:600;color:var(--success);">✅ <?=$msg?></div><?php endif;?>

  <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;margin-bottom:20px;">
    <div>
      <h1 style="font-family:'Orbitron',monospace;font-size:20px;color:var(--text);margin-bottom:4px;"><?=clean($pu['full_name'])?></h1>
      <p style="color:var(--muted);font-size:12px;">@<?=clean($pu['username'])?></p>
      <?php if($pu['bio']):?><p style="font-size:13px;color:var(--text);margin-top:8px;max-width:500px;line-height:1.6;"><?=clean($pu['bio'])?></p><?php endif;?>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px;">
        <span style="font-size:10px;padding:3px 10px;background:<?=$rankInfo[1]?>18;color:<?=$rankInfo[1]?>;border:1px solid <?=$rankInfo[1]?>44;border-radius:8px;font-weight:700;font-family:'Orbitron',monospace;"><?=$rankInfo[0]?>-RANK • <?=$rankInfo[2]?></span>
        <span style="font-size:10px;padding:3px 10px;background:rgba(0,212,255,.1);color:var(--primary);border:1px solid rgba(0,212,255,.2);border-radius:8px;">🩺 <?=clean($pu['target_exam'])?></span>
        <?php if(($pu['streak_days']??0)>0):?><span style="font-size:10px;padding:3px 10px;background:rgba(244,63,94,.1);color:var(--danger);border:1px solid rgba(244,63,94,.2);border-radius:8px;">🔥 <?=$pu['streak_days']?> day streak</span><?php endif;?>
        <span style="font-size:10px;padding:3px 10px;background:rgba(245,158,11,.1);color:var(--accent);border:1px solid rgba(245,158,11,.2);border-radius:8px;">🪙 <?=number_format($pu['coins']??0)?></span>
      </div>
      <!-- XP Bar -->
      <div style="margin-top:12px;max-width:320px;">
        <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--muted);margin-bottom:4px;"><span>Level <?=$pu['level']?></span><span><?=$xpPct?>% to Level <?=($pu['level']??1)+1?></span></div>
        <div class="prog-track" style="height:5px;"><div class="prog-fill" style="width:<?=$xpPct?>%;background:linear-gradient(90deg,var(--primary),var(--secondary));box-shadow:0 0 8px var(--glow);"></div></div>
        <div style="font-size:10px;color:var(--muted);margin-top:3px;"><?=number_format($pu['xp']??0)?> XP</div>
      </div>
    </div>
    <?php if($isOwn):?>
    <button onclick="document.getElementById('editPanel').style.display=document.getElementById('editPanel').style.display==='none'?'block':'none'" class="btn btn-primary">✏️ Edit Profile</button>
    <?php endif;?>
  </div>

  <!-- STATS -->
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px;margin-bottom:20px;">
    <?php foreach([['⏱️','Study Time',floor($totalStudy/60).'h','#00d4ff'],['🎯','MCQs',number_format($totalMcq),'#f59e0b'],['📝','Exams',$totalExams,'#7c3aed'],['📊','Avg Score',$avgScore.'%','#10b981']] as $s):?>
    <div class="card" style="text-align:center;padding:12px;"><div style="font-size:18px;margin-bottom:5px;"><?=$s[0]?></div><div style="font-family:'Orbitron',monospace;font-size:16px;font-weight:800;color:<?=$s[3]?>"><?=$s[2]?></div><div style="font-size:9px;color:var(--muted);text-transform:uppercase;"><?=$s[1]?></div></div>
    <?php endforeach;?>
  </div>

  <!-- BADGES -->
  <?php if(!empty($bList)):?>
  <div class="card" style="margin-bottom:20px;">
    <div class="card-title" style="margin-bottom:14px;">🎖️ Badges & Achievements</div>
    <div style="display:flex;flex-wrap:wrap;gap:10px;">
      <?php foreach($bList as $b):?>
      <div style="text-align:center;padding:12px;background:var(--bg2);border-radius:12px;border:1px solid var(--border);min-width:80px;transition:all .2s;" onmouseover="this.style.borderColor='var(--primary)';this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='var(--border)';this.style.transform=''">
        <div style="font-size:24px;margin-bottom:4px;">🏅</div>
        <div style="font-size:10px;font-weight:700;color:var(--text);line-height:1.3;"><?=clean($b['badge_name'])?></div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
  <?php endif;?>

  <!-- EDIT PANEL -->
  <?php if($isOwn):?>
  <div id="editPanel" style="display:none;">
    <div class="card">
      <div class="card-title" style="margin-bottom:16px;">✏️ Edit Profile</div>
      <form method="POST">
        <input type="hidden" name="action" value="update"/>
        <div class="form-row"><div class="form-group"><label>Full Name</label><input type="text" name="full_name" class="form-control" value="<?=clean($pu['full_name'])?>" required/></div><div class="form-group"><label>Email</label><input type="email" name="email" class="form-control" value="<?=clean($pu['email']??'')?>"/></div></div>
        <div class="form-group"><label>Bio</label><textarea name="bio" class="form-control"><?=clean($pu['bio']??'')?></textarea></div>
        <div class="form-row"><div class="form-group"><label>Target Exam</label><input type="text" name="target_exam" class="form-control" value="<?=clean($pu['target_exam']??'FMGE')?>"/></div><div class="form-group"><label>Exam Date</label><input type="date" name="exam_date" class="form-control" value="<?=$pu['exam_date']??''?>"/></div></div>
        <button type="submit" class="btn btn-primary">💾 Save Profile</button>
      </form>
      <hr style="border:none;border-top:1px solid var(--border);margin:20px 0;"/>
      <div class="card-title" style="margin-bottom:14px;">🔐 Change Password</div>
      <form method="POST">
        <input type="hidden" name="action" value="change_pass"/>
        <div class="form-row"><div class="form-group"><label>Old Password</label><input type="password" name="old_pass" class="form-control" required/></div><div class="form-group"><label>New Password</label><input type="password" name="new_pass" class="form-control" required/></div></div>
        <div class="form-group"><label>Confirm Password</label><input type="password" name="conf_pass" class="form-control" required/></div>
        <button type="submit" class="btn btn-primary">🔑 Change Password</button>
      </form>
    </div>
  </div>
  <?php endif;?>
</div>
</div>
<?php include '../includes/footer.php';?>
