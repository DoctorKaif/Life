<?php
require_once '../includes/config.php';
requireLogin();
$db=getDB();$uid=(int)$_SESSION['user_id'];
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $theme=clean($_POST['theme']??'void');
    $themes=array_keys(getThemeData());
    if(in_array($theme,$themes)){
        $db->query("INSERT INTO user_settings(user_id,theme) VALUES($uid,'$theme') ON DUPLICATE KEY UPDATE theme='$theme'");
        $db->query("UPDATE users SET theme='$theme' WHERE id=$uid");
        $msg='Theme saved!';header('Location: settings.php');exit;
    }
}
$cur=$db->query("SELECT theme FROM user_settings WHERE user_id=$uid")->fetch_assoc()['theme']??'void';
$pageTitle='Settings';$activePage='settings';
include '../includes/header.php';
?>
<div class="page-content" style="max-width:600px;">
<?php if($msg): ?><div style="background:rgba(26,158,110,.1);border:1px solid rgba(26,158,110,.2);border-radius:10px;padding:12px 16px;margin-bottom:20px;font-size:13px;font-weight:600;color:var(--success);">✅ <?= $msg ?></div><?php endif; ?>
<div class="card anim-fade-up">
  <div class="card-ttl" style="margin-bottom:20px;">⚙️ Settings</div>
  <form method="POST">
    <div class="form-group" style="margin-bottom:24px;">
      <label style="font-size:13px;font-weight:700;margin-bottom:14px;display:block;">🎨 Choose Theme</label>
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;">
        <?php foreach(getThemeData() as $key=>[$name,$color,$desc,$type]): ?>
        <label style="cursor:pointer;">
          <input type="radio" name="theme" value="<?= $key ?>" <?= $cur===$key?'checked':'' ?> style="display:none;"/>
          <div onclick="selectTheme('<?= $key ?>','<?= $color ?>')" style="border-radius:14px;padding:14px;border:2px solid <?= $cur===$key?$color:'var(--border)' ?>;background:<?= $color ?>0d;transition:all .2s;cursor:pointer;" id="td-<?= $key ?>">
            <div style="display:flex;align-items:center;gap:10px;">
              <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,<?= $color ?>,<?= $color ?>66);box-shadow:0 0 10px <?= $color ?>44;flex-shrink:0;"></div>
              <div>
                <div style="font-size:12px;font-weight:800;color:<?= $color ?>"><?= $name ?></div>
                <div style="font-size:10px;color:var(--muted);"><?= $desc ?> · <?= ucfirst($type) ?></div>
              </div>
            </div>
          </div>
        </label>
        <?php endforeach; ?>
      </div>
    </div>
    <button type="submit" class="btn btn-primary w-full">💾 Save Theme</button>
  </form>
</div>
</div>
<script>
function selectTheme(k,c){
  document.querySelectorAll('[id^="td-"]').forEach(el=>el.style.borderColor='var(--border)');
  document.getElementById('td-'+k).style.borderColor=c;
  document.querySelector('input[value="'+k+'"]').checked=true;
}
</script>
<?php include '../includes/footer.php'; ?>
