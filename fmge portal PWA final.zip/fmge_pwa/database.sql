-- ================================================
-- FMGE STUDY PORTAL v3.0 - COMPLETE DATABASE
-- Run this in phpMyAdmin SQL tab
-- ================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS diary_entries;
DROP TABLE IF EXISTS partner_messages;
DROP TABLE IF EXISTS study_partners;
DROP TABLE IF EXISTS daily_ratings;
DROP TABLE IF EXISTS mcq_records;
DROP TABLE IF EXISTS study_sessions;
DROP TABLE IF EXISTS roadmap;
DROP TABLE IF EXISTS exam_records;
DROP TABLE IF EXISTS subject_progress;
DROP TABLE IF EXISTS timetable;
DROP TABLE IF EXISTS community_likes;
DROP TABLE IF EXISTS community_posts;
DROP TABLE IF EXISTS user_badges;
DROP TABLE IF EXISTS badges;
DROP TABLE IF EXISTS user_quests;
DROP TABLE IF EXISTS quests;
DROP TABLE IF EXISTS user_settings;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS quotes;
DROP TABLE IF EXISTS exam_types;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- EXAM TYPES (customizable by admin)
CREATE TABLE exam_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    is_active TINYINT(1) DEFAULT 1
);

-- USERS
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    remember_token VARCHAR(64) DEFAULT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    avatar VARCHAR(255) DEFAULT '',
    banner VARCHAR(255) DEFAULT '',
    bio TEXT,
    role ENUM('admin','student') DEFAULT 'student',
    target_exam VARCHAR(100) DEFAULT 'FMGE',
    exam_date DATE,
    -- Gamification
    xp INT DEFAULT 0,
    level INT DEFAULT 1,
    coins INT DEFAULT 0,
    rank_title VARCHAR(20) DEFAULT 'E',
    streak_days INT DEFAULT 0,
    last_study_date DATE,
    total_study_minutes INT DEFAULT 0,
    total_mcqs INT DEFAULT 0,
    total_correct_mcqs INT DEFAULT 0,
    -- Status
    is_active TINYINT(1) DEFAULT 1,
    is_banned TINYINT(1) DEFAULT 0,
    is_online TINYINT(1) DEFAULT 0,
    last_seen DATETIME,
    -- Settings
    theme VARCHAR(20) DEFAULT 'cyber',
    privacy_level ENUM('public','friends','private') DEFAULT 'public',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- TIMETABLE
CREATE TABLE timetable (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    slot_start TIME NOT NULL,
    slot_end TIME NOT NULL,
    subject VARCHAR(100) NOT NULL,
    activity VARCHAR(200),
    color VARCHAR(20) DEFAULT '#00d4ff',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- SUBJECT PROGRESS
CREATE TABLE subject_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    subject_name VARCHAR(100) NOT NULL,
    total_topics INT DEFAULT 100,
    completed_topics INT DEFAULT 0,
    target_date DATE,
    color VARCHAR(20) DEFAULT '#00d4ff',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- EXAM RECORDS
CREATE TABLE exam_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    exam_name VARCHAR(150) NOT NULL,
    exam_type VARCHAR(100) DEFAULT 'Mock',
    total_marks INT NOT NULL,
    obtained_marks INT NOT NULL,
    exam_date DATE NOT NULL,
    time_taken INT DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ROADMAP (monthly only)
CREATE TABLE roadmap (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    milestone_title VARCHAR(200) NOT NULL,
    target_date DATE NOT NULL,
    description TEXT,
    is_completed TINYINT(1) DEFAULT 0,
    color VARCHAR(20) DEFAULT '#00d4ff',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- STUDY SESSIONS
CREATE TABLE study_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    subject VARCHAR(100),
    start_time DATETIME NOT NULL,
    end_time DATETIME,
    duration_minutes INT DEFAULT 0,
    session_date DATE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- MCQ RECORDS
CREATE TABLE mcq_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    subject VARCHAR(100),
    total_attempted INT DEFAULT 0,
    correct INT DEFAULT 0,
    record_date DATE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- DAILY RATINGS
CREATE TABLE daily_ratings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    rating INT DEFAULT 0,
    note TEXT,
    rating_date DATE NOT NULL,
    UNIQUE KEY unique_rating (user_id, rating_date),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- QUOTES
CREATE TABLE quotes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_text TEXT NOT NULL,
    author VARCHAR(100) DEFAULT 'Anonymous',
    category VARCHAR(50) DEFAULT 'medical',
    is_active TINYINT(1) DEFAULT 1
);

-- BADGES
CREATE TABLE badges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    badge_name VARCHAR(100) NOT NULL,
    badge_desc VARCHAR(255),
    badge_emoji VARCHAR(10) DEFAULT '',
    badge_color VARCHAR(20) DEFAULT '#f59e0b',
    badge_type VARCHAR(50),
    requirement_value INT DEFAULT 1,
    xp_reward INT DEFAULT 50,
    coin_reward INT DEFAULT 25
);

-- USER BADGES
CREATE TABLE user_badges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    badge_id INT NOT NULL,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_badge (user_id, badge_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (badge_id) REFERENCES badges(id) ON DELETE CASCADE
);

-- QUESTS
CREATE TABLE quests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quest_name VARCHAR(100) NOT NULL,
    quest_desc VARCHAR(255),
    quest_type ENUM('daily','weekly','monthly') DEFAULT 'daily',
    requirement_type VARCHAR(50),
    requirement_value INT DEFAULT 1,
    xp_reward INT DEFAULT 100,
    coin_reward INT DEFAULT 50,
    is_active TINYINT(1) DEFAULT 1
);

-- USER QUESTS
CREATE TABLE user_quests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    quest_id INT NOT NULL,
    current_value INT DEFAULT 0,
    is_completed TINYINT(1) DEFAULT 0,
    completed_at DATETIME,
    quest_date DATE NOT NULL,
    UNIQUE KEY unique_quest (user_id, quest_id, quest_date),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (quest_id) REFERENCES quests(id) ON DELETE CASCADE
);

-- COMMUNITY POSTS
CREATE TABLE community_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    post_text TEXT NOT NULL,
    post_type ENUM('update','question','achievement','tip') DEFAULT 'update',
    likes_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- COMMUNITY LIKES
CREATE TABLE community_likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    post_id INT NOT NULL,
    UNIQUE KEY unique_like (user_id, post_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES community_posts(id) ON DELETE CASCADE
);

-- NOTIFICATIONS
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) DEFAULT 'info',
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- USER SETTINGS
CREATE TABLE user_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE NOT NULL,
    theme VARCHAR(20) DEFAULT 'cyber',
    show_in_leaderboard TINYINT(1) DEFAULT 1,
    diary_pin VARCHAR(10) DEFAULT '',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- DIARY
CREATE TABLE diary_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(200),
    content TEXT,
    mood VARCHAR(20) DEFAULT 'neutral',
    entry_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ================================================
-- DEFAULT DATA
-- ================================================

-- Admin (password: password)
INSERT INTO users (username, password, full_name, email, role, xp, level, coins, rank_title) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'admin@fmgeportal.com', 'admin', 500, 5, 200, 'C');

INSERT INTO user_settings (user_id) VALUES (1);

-- Exam types
INSERT INTO exam_types (name) VALUES ('FMGE'),('USMLE'),('PLAB'),('AMC'),('ERPM'),('PMDC'),('Mock Test'),('Subject Test');

-- Badges
INSERT INTO badges (badge_name, badge_desc, badge_emoji, badge_color, badge_type, requirement_value, xp_reward, coin_reward) VALUES
('First Login', 'Logged in for the first time', 'star', '#f59e0b', 'login', 1, 50, 10),
('Study Starter', 'Completed first study session', 'book', '#3b82f6', 'study_sessions', 1, 100, 20),
('MCQ Warrior', 'Attempted 100 MCQs', 'target', '#ef4444', 'total_mcqs', 100, 200, 50),
('MCQ Champion', 'Attempted 1000 MCQs', 'trophy', '#f59e0b', 'total_mcqs', 1000, 500, 150),
('3 Day Streak', 'Studied 3 days in a row', 'fire', '#f97316', 'streak', 3, 150, 30),
('7 Day Streak', 'Studied 7 days in a row', 'fire2', '#ef4444', 'streak', 7, 300, 75),
('30 Day Streak', 'Studied 30 days in a row', 'diamond', '#8b5cf6', 'streak', 30, 1000, 300),
('10 Hour Club', 'Studied for 10 total hours', 'clock', '#10b981', 'study_hours', 600, 250, 60),
('100 Hour Legend', 'Studied for 100 total hours', 'crown', '#f59e0b', 'study_hours', 6000, 1000, 250),
('First Exam', 'Added first exam record', 'pencil', '#06b6d4', 'exams', 1, 100, 25),
('FMGE Ready', 'Completed 5 mock tests', 'doctor', '#2563eb', 'exams', 5, 400, 100),
('Community Star', 'Made 10 community posts', 'star2', '#eab308', 'posts', 10, 200, 50),
('Perfect Day', 'Gave 5-star day rating', 'rainbow', '#ec4899', 'rating', 5, 150, 40),
('Top Scorer', 'Scored 90%+ in an exam', 'gold', '#f59e0b', 'score', 90, 500, 100);

-- Daily Quests
INSERT INTO quests (quest_name, quest_desc, quest_type, requirement_type, requirement_value, xp_reward, coin_reward) VALUES
('Daily Study', 'Study for at least 2 hours today', 'daily', 'study_minutes', 120, 100, 50),
('MCQ Practice', 'Attempt 50 MCQs today', 'daily', 'mcq_count', 50, 75, 35),
('Login Bonus', 'Log in today', 'daily', 'login', 1, 25, 10),
('Weekly Grind', 'Study 15 hours this week', 'weekly', 'study_minutes', 900, 400, 150),
('MCQ Marathon', 'Attempt 300 MCQs this week', 'weekly', 'mcq_count', 300, 300, 100);

-- Quotes
INSERT INTO quotes (quote_text, author, category) VALUES
('One day people will ask you — how did you become a doctor?', 'Future You', 'medical'),
('FMGE is not just an exam, it is the door to your destiny.', 'Inspiration', 'fmge'),
('Those who study today will pass tomorrow.', 'Wisdom', 'medical'),
('Difficulties do not stand on you — you stand over them.', 'Motivation', 'general'),
('Steal sleep to study — your dreams were already stolen.', 'FMGE Aspirant', 'fmge'),
('Not 150 marks — prepare to save 150 lives.', 'Doctor Oath', 'medical'),
('Every morning is a new chance to get closer to your dream.', 'Anonymous', 'general'),
('Being a doctor is not just a career — it is a responsibility.', 'Medical Ethics', 'medical'),
('Wrong MCQ is okay — wrong answer on exam day is not.', 'Study Tip', 'fmge'),
('Revision is the weapon that wins FMGE.', 'Topper', 'fmge'),
('Every topic you study today can save a life tomorrow.', 'Dr. Wisdom', 'medical'),
('Fatigue comes when motivation is lost. Remember your WHY.', 'Coach', 'general');
