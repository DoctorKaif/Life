<?php
require_once '../includes/config.php';
requireLogin();
$db=getDB();$uid=(int)$_SESSION['user_id'];

// Clean expired messages
$db->query("DELETE FROM partner_messages WHERE created_at < DATE_SUB(NOW(), INTERVAL auto_delete_hours HOUR)");

if($_SERVER['REQUEST_METHOD']==='POST'){
    $a=$_POST['action']??'';
    if($a==='send_request'){$pid=(int)($_POST['pid']??0);if($pid&&$pid!==$uid){$ex=$db->query("SELECT id FROM study_partners WHERE (user_id=$uid AND partner_id=$pid) OR (user_id=$pid AND partner_id=$uid)")->num_rows;if(!$ex){$db->query("INSERT INTO study_partners(user_id,partner_id) VALUES($uid,$pid)");addNotification($pid,clean($_SESSION['full_name'])." sent you a Partner request!",'partner');}}}
    elseif($a==='accept'){$id=(int)($_POST['rid']??0);$db->query("UPDATE study_partners SET status='accepted',accepted_at=NOW() WHERE id=$id AND partner_id=$uid");$req=$db->query("SELECT user_id FROM study_partners WHERE id=$id")->fetch_assoc();if($req){addNotification($req['user_id'],clean($_SESSION['full_name'])." accepted your Partner request!",'partner');addXP($uid,50,20);checkBadges($uid);}}
    elseif($a==='reject'){$id=(int)($_POST['rid']??0);$db->query("UPDATE study_partners SET status='rejected' WHERE id=$id AND partner_id=$uid");}
    elseif($a==='remove'){$pid=(int)($_POST['pid']??0);$db->query("DELETE FROM study_partners WHERE (user_id=$uid AND partner_id=$pid) OR (user_id=$pid AND partner_id=$uid)");}
    elseif($a==='send_msg'){$pid=(int)($_POST['to']??0);$msg=clean($_POST['msg']??'');$del=(int)($_POST['del']??24);if($pid&&$msg&&arePartners($uid,$pid)){$stmt=$db->prepare("INSERT INTO partner_messages(sender_id,receiver_id,message,auto_delete_hours) VALUES(?,?,?,?)");$stmt->bind_param('iisi',$uid,$pid,$msg,$del);$stmt->execute();}header('Location: partners.php');exit;}
    elseif($a==='ping'){$pid=(int)($_POST['pid']??0);if($pid&&arePartners($uid,$pid))addNotification($pid,"📍 ".clean($_SESSION['full_name'])." is pinging you — Let's study together! 🚀",'ping');}
    elseif($a==='cheer'){$pid=(int)($_POST['pid']??0);$em=clean($_POST['em']??'👏');if($pid&&arePartners($uid,$pid))addNotification($pid,"$em ".clean($_SESSION['full_name'])." cheered for you! Keep going! 💪",'cheer');}
    header('Location: partners.php');exit;
}

$today=date('Y-m-d');
$partners=$db->query("SELECT u.id,u.full_name,u.username,u.avatar,u.level,u.streak_days,u.total_study_minutes,u.last_study_date,sp.id as sp_id FROM study_partners sp JOIN users u ON u.id=IF(sp.user_id=$uid,sp.partner_id,sp.user_id) WHERE (sp.user_id=$uid OR sp.partner_id=$uid) AND sp.status='accepted' AND u.is_banned=0 ORDER BY u.full_name");
$partnerList=[];if($partners)while($r=$partners->fetch_assoc())$partnerList[]=$r;
$requests=$db->query("SELECT sp.id,u.id as uid,u.full_name,u.avatar,u.level FROM study_partners sp JOIN users u ON u.id=sp.user_id WHERE sp.partner_id=$uid AND sp.status='pending' AND u.is_banned=0");
$reqList=[];if($requests)while($r=$requests->fetch_assoc())$reqList[]=$r;
$allStudents=$db->query("SELECT id,full_name,avatar,level,total_study_minutes,streak_days FROM users WHERE id!=$uid AND is_active=1 AND is_banned=0 ORDER BY full_name");
$studentList=[];if($allStudents)while($r=$allStudents->fetch_assoc())$studentList[]=$r;

$pageTitle='Study Partners';$activePage='partners';
include '../includes/header.php';
?>
<div class="page-content">

<!-- Pending requests -->
<?php if(!empty($reqList)): ?>
<div class="card mb-20 anim-fade-up" style="border-color:rgba(56,182,204,.2);">
  <div class="card-ttl" style="margin-bottom:14px;">📬 Partner Requests (<?= count($reqList) ?>)</div>
  <?php foreach($reqList as $r): ?>
  <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);">
    <div style="width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:14px;color:#fff;font-weight:700;overflow:hidden;flex-shrink:0;"><?= strtoupper(substr($r['full_name'],0,1)) ?></div>
    <div style="flex:1;"><div style="font-size:14px;font-weight:700;"><?= clean($r['full_name']) ?></div><div style="font-size:10px;color:var(--muted);">Lv.<?= $r['level'] ?></div></div>
    <form method="POST" style="display:inline;"><input type="hidden" name="action" value="accept"/><input type="hidden" name="rid" value="<?= $r['id'] ?>"/><button type="submit" class="btn btn-success btn-sm">✅ Accept</button></form>
    <form method="POST" style="display:inline;"><input type="hidden" name="action" value="reject"/><input type="hidden" name="rid" value="<?= $r['id'] ?>"/><button type="submit" class="btn btn-danger btn-sm">✗</button></form>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 300px;gap:20px;">

  <!-- My Partners -->
  <div>
    <div class="card anim-fade-up">
      <div class="card-hdr"><div><div class="card-ttl">🤝 My Study Partners (<?= count($partnerList) ?>)</div></div></div>
      <?php if(!empty($partnerList)):foreach($partnerList as $p):
        $pToday=(int)($db->query("SELECT SUM(duration_minutes) as t FROM study_sessions WHERE user_id={$p['id']} AND session_date='$today'")->fetch_assoc()['t']??0);
        $isOnline=$p['last_study_date']===$today;
        $msgs=$db->query("SELECT pm.*,u.full_name FROM partner_messages pm JOIN users u ON u.id=pm.sender_id WHERE ((pm.sender_id=$uid AND pm.receiver_id={$p['id']}) OR (pm.sender_id={$p['id']} AND pm.receiver_id=$uid)) ORDER BY pm.created_at ASC LIMIT 20");
        $msgList=[];if($msgs)while($m=$msgs->fetch_assoc())$msgList[]=$m;
        $db->query("UPDATE partner_messages SET is_read=1 WHERE receiver_id=$uid AND sender_id={$p['id']}");
        $ri=getMilitaryRank($p['level']??1);
      ?>
      <div style="background:var(--bg2);border-radius:14px;padding:16px;margin-bottom:14px;border:1px solid <?= $isOnline?'rgba(26,158,110,.2)':'var(--border)' ?>;">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
          <div style="position:relative;">
            <div style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:18px;color:#fff;font-weight:700;overflow:hidden;">
              <?php if(!empty($p['avatar'])): ?><img src="<?= SITE_URL ?>/uploads/avatars/<?= clean($p['avatar']) ?>" style="width:100%;height:100%;object-fit:cover;"/><?php else: ?><?= strtoupper(substr($p['full_name'],0,1)) ?><?php endif; ?>
            </div>
            <?php if($isOnline): ?><div style="position:absolute;bottom:0;right:0;width:12px;height:12px;border-radius:50%;background:var(--success);border:2px solid var(--bg2);animation:dotPulse 2s infinite;"></div><?php endif; ?>
          </div>
          <div style="flex:1;">
            <div style="font-size:14px;font-weight:700;"><?= clean($p['full_name']) ?></div>
            <div style="font-size:10px;color:var(--muted);">Lv.<?= $p['level'] ?> <span style="color:<?= $ri[2] ?>;font-weight:700;"><?= $ri[0] ?></span> · 🔥<?= $p['streak_days'] ?>d</div>
          </div>
          <?php if($isOnline): ?><div style="font-size:10px;background:rgba(26,158,110,.12);color:var(--success);border:1px solid rgba(26,158,110,.2);border-radius:8px;padding:3px 8px;font-weight:700;">🟢 STUDYING</div><?php endif; ?>
        </div>
        <!-- Stats -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px;">
          <div style="text-align:center;padding:8px;background:var(--card);border-radius:8px;"><div style="font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:800;color:var(--primary);"><?= floor($pToday/60) ?>h <?= $pToday%60 ?>m</div><div style="font-size:9px;color:var(--muted);">TODAY</div></div>
          <div style="text-align:center;padding:8px;background:var(--card);border-radius:8px;"><div style="font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:800;color:var(--success);"><?= floor($p['total_study_minutes']/60) ?>h</div><div style="font-size:9px;color:var(--muted);">TOTAL</div></div>
          <div style="text-align:center;padding:8px;background:var(--card);border-radius:8px;"><div style="font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:800;color:var(--danger);">🔥<?= $p['streak_days'] ?>d</div><div style="font-size:9px;color:var(--muted);">STREAK</div></div>
        </div>
        <!-- Quick actions -->
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px;">
          <form method="POST" style="display:inline;"><input type="hidden" name="action" value="ping"/><input type="hidden" name="pid" value="<?= $p['id'] ?>"/><button type="submit" class="btn btn-primary btn-sm">📍 Ping</button></form>
          <?php foreach(['👏','🔥','💪','⚡'] as $em): ?>
          <form method="POST" style="display:inline;"><input type="hidden" name="action" value="cheer"/><input type="hidden" name="pid" value="<?= $p['id'] ?>"/><input type="hidden" name="em" value="<?= $em ?>"/><button type="submit" style="padding:5px 10px;border:1px solid var(--border);background:var(--card);border-radius:8px;cursor:pointer;font-size:14px;transition:all .2s;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='var(--border)'"><?= $em ?></button></form>
          <?php endforeach; ?>
          <form method="POST" style="display:inline;"><input type="hidden" name="action" value="remove"/><input type="hidden" name="pid" value="<?= $p['id'] ?>"/><button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Remove partner?')">✗</button></form>
        </div>
        <!-- Chat -->
        <div style="background:var(--card);border-radius:10px;padding:12px;border:1px solid var(--border);">
          <div style="font-size:10px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px;">🔒 Private Chat (Auto-Delete)</div>
          <div style="max-height:140px;overflow-y:auto;margin-bottom:8px;display:flex;flex-direction:column;gap:6px;" id="chat-<?= $p['id'] ?>">
            <?php foreach($msgList as $m): $isMine=$m['sender_id']===$uid; ?>
            <div style="display:flex;justify-content:<?= $isMine?'flex-end':'flex-start' ?>;">
              <div style="max-width:75%;padding:8px 12px;border-radius:<?= $isMine?'12px 12px 2px 12px':'12px 12px 12px 2px' ?>;background:<?= $isMine?'linear-gradient(135deg,var(--primary),var(--secondary))':'rgba(255,255,255,.05)' ?>;color:<?= $isMine?'#fff':'var(--text)' ?>;font-size:12px;line-height:1.4;">
                <div style="font-size:9px;font-weight:700;margin-bottom:2px;opacity:.7;"><?= $isMine?'You':clean(explode(' ',$m['full_name'])[0]) ?></div>
                <?= clean($m['message']) ?>
                <div style="font-size:9px;opacity:.5;margin-top:2px;">Auto-deletes in <?= $m['auto_delete_hours'] ?>h</div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
          <form method="POST" style="display:flex;gap:6px;">
            <input type="hidden" name="action" value="send_msg"/>
            <input type="hidden" name="to" value="<?= $p['id'] ?>"/>
            <input type="text" name="msg" class="form-control" placeholder="Message..." required style="flex:1;padding:7px 10px;font-size:12px;"/>
            <select name="del" style="padding:7px;border:1px solid var(--border2);border-radius:8px;background:var(--bg2);color:var(--text);font-size:11px;cursor:pointer;"><option value="1">1h</option><option value="24" selected>24h</option><option value="168">7d</option></select>
            <button type="submit" class="btn btn-primary btn-sm">→</button>
          </form>
        </div>
      </div>
      <?php endforeach;else: ?>
      <div style="text-align:center;padding:32px;color:var(--muted);">
        <div style="font-size:40px;margin-bottom:10px;">🤝</div>
        <div style="font-size:14px;font-weight:600;">No partners yet</div>
        <div style="font-size:12px;margin-top:4px;">Add partners from the list →</div>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Find Partners -->
  <div>
    <div class="card anim-fade-up" data-delay="1">
      <div class="card-ttl" style="margin-bottom:14px;">🔍 Find Study Partners</div>
      <?php foreach($studentList as $s):
        $isPending=$db->query("SELECT id FROM study_partners WHERE ((user_id=$uid AND partner_id={$s['id']}) OR (user_id={$s['id']} AND partner_id=$uid)) AND status='pending'")->num_rows>0;
        $isPartner=arePartners($uid,$s['id']);
      ?>
      <div style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--border);">
        <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:13px;color:#fff;font-weight:700;overflow:hidden;flex-shrink:0;">
          <?php if(!empty($s['avatar'])): ?><img src="<?= SITE_URL ?>/uploads/avatars/<?= clean($s['avatar']) ?>" style="width:100%;height:100%;object-fit:cover;"/><?php else: ?><?= strtoupper(substr($s['full_name'],0,1)) ?><?php endif; ?>
        </div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= clean($s['full_name']) ?></div>
          <div style="font-size:10px;color:var(--muted);">Lv.<?= $s['level'] ?> · 🔥<?= $s['streak_days'] ?>d · <?= floor($s['total_study_minutes']/60) ?>h</div>
        </div>
        <?php if($isPartner): ?>
        <span style="font-size:11px;color:var(--success);font-weight:700;">✅</span>
        <?php elseif($isPending): ?>
        <span style="font-size:11px;color:var(--accent);font-weight:700;">⏳</span>
        <?php else: ?>
        <form method="POST"><input type="hidden" name="action" value="send_request"/><input type="hidden" name="pid" value="<?= $s['id'] ?>"/><button type="submit" class="btn btn-primary btn-xs">+ Add</button></form>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

</div>
</div>
<?php include '../includes/footer.php'; ?>
