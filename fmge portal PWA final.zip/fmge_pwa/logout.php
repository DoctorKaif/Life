<?php
require_once 'includes/config.php';
if(isset($_SESSION['user_id'])){
    $db=getDB();$uid=(int)$_SESSION['user_id'];
    $db->query("UPDATE users SET remember_token=NULL WHERE id=$uid");
}
setcookie('fmge_token','',time()-3600,'/');
session_destroy();
header('Location: index.php');exit;
