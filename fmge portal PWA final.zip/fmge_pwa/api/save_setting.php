<?php
require_once '../includes/config.php';
requireLogin();
header('Content-Type: application/json');

// CSRF verify
$d = json_decode(file_get_contents('php://input'), true) ?? [];
if(!csrf_verify($d[CSRF_TOKEN_NAME]??($_POST[CSRF_TOKEN_NAME]??''))) {
    http_response_code(403); die(json_encode(['success'=>false,'error'=>'Forbidden']));
}

$key = clean($d['key'] ?? '');
$value = clean($d['value'] ?? '');
$uid = (int)$_SESSION['user_id'];

$allowed_keys = ['theme','notifications_enabled','sound_enabled'];
if(!in_array($key,$allowed_keys,true)) { die(json_encode(['success'=>false,'error'=>'Invalid key'])); }

$db = getDB();
$stmt = $db->prepare("INSERT INTO user_settings (user_id,`{$key}`) VALUES (?,?) ON DUPLICATE KEY UPDATE `{$key}`=?");
$stmt->bind_param('iss',$uid,$value,$value);
echo json_encode(['success'=>$stmt->execute()]);
