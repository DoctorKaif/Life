<?php
require_once '../includes/config.php';
requireLogin();
$db=getDB();$uid=(int)$_SESSION['user_id'];

$byStudy=$db->query("SELECT id,full_name,username,avatar,streak_days,total_study_minutes,total_mcqs,level,rank_title FROM users WHERE is_active=1 AND is_banned=0 ORDER BY total_study_minutes DESC LIMIT 20");
$byStreak=$db->query("SELECT id,full_name,username,avatar,streak_days,total_study_minutes,level,rank_title FROM users WHERE is_active=1 AND is_banned=0 ORDER BY streak_days DESC LIMIT 20");
$byMcq=$db->query("SELECT id,full_name,username,avatar,total_mcqs,streak_days,level,rank_title FROM users WHERE is_active=1 AND is_banned=0 ORDER BY total_mcqs DESC LIMIT 20");

$sL=[];if($byStudy)while($r=$byStudy->fetch_assoc())$sL[]=$r;
$stL=[];if($byStreak)while($r=$byStreak->fetch_assoc())$stL[]=$r;
$mL=[];if($byMcq)while($r=$byMcq->fetch_assoc())$mL[]=$r;

$pageTitle='Leaderboard';$activePage='leaderboard';
include '../includes/header.php';
?>
<div class="page-content">
<div style="text-align:center;margin-bottom:28px;">
  <div style="font-size:52px;margin-bottom:10px;animation:float 3s ease-in-out infinite;">🏆</div>
  <h2 style="font-family:'Orbitron',monospace;font-size:22px;color:var(--primary);margin-bottom:6px;">LEADERBOARD</h2>
  <p style="color:var(--muted);font-size:13px;">Who is the top commander?</p>
</div>

<div style="display:flex;gap:6px;background:var(--bg2);border-radius:12px;padding:4px;margin-bottom:24px;border:1px solid var(--border);">
  <?php foreach([['study','⏱️ Study Hours'],['streak','🔥 Streak'],['mcq','🎯 MCQs']] as $t):?>
  <button onclick="showLB('<?=$t[0]?>')" id="lbtab-<?=$t[0]?>" style="flex:1;padding:9px;border:none;border-radius:9px;font-family:'Inter',sans-serif;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;background:transparent;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;"><?=$t[1]?></button>
  <?php endforeach;?>
</div>

<?php foreach([['study',$sL,'total_study_minutes',fn($v)=>floor($v/60).'h'],['streak',$stL,'streak_days',fn($v)=>$v.' days'],['mcq',$mL,'total_mcqs',fn($v)=>number_format($v)]] as [$tabId,$data,$field,$fmt]):?>
<div id="lbpanel-<?=$tabId?>" style="display:none;">
  <?php $rank=1; foreach($data as $s):
    $isMe=$s['id']===$uid;
    $medals=['🥇','🥈','🥉'];
    $medal=$rank<=3?$medals[$rank-1]:'#'.$rank;
    $rankInfo=getRank($s['level']??1);
  ?>
  <div style="display:flex;align-items:center;gap:12px;padding:14px 18px;background:<?=$isMe?'rgba(0,212,255,.08)':'var(--card)'?>;border-radius:12px;margin-bottom:8px;border:1px solid <?=$isMe?'rgba(0,212,255,.3)':'var(--border)'?>;transition:all .2s;animation:fadeUp .3s ease;" onmouseover="this.style.transform='translateX(4px)'" onmouseout="this.style.transform=''">
    <div style="font-size:20px;width:30px;text-align:center;font-weight:800;"><?=$medal?></div>
    <a href="<?=SITE_URL?>/pages/profile.php?id=<?=$s['id']?>" style="text-decoration:none;flex-shrink:0;">
      <div style="width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:16px;color:#fff;font-weight:700;overflow:hidden;border:2px solid <?=$rank<=3?'gold':'var(--border)'?>;">
        <?php if(!empty($s['avatar'])):?><img src="<?=SITE_URL?>/uploads/avatars/<?=clean($s['avatar'])?>" style="width:100%;height:100%;object-fit:cover;"/><?php else:?><?=strtoupper(substr($s['full_name'],0,1))?><?php endif;?>
      </div>
    </a>
    <div style="flex:1;">
      <div style="font-size:14px;font-weight:<?=$isMe?'700':'500'?>;color:var(--text);"><?=clean($s['full_name'])?><?=$isMe?' 👈':''?></div>
      <div style="font-size:10px;color:var(--muted);">Lv.<?=$s['level']?> <?=$rankInfo[0]?>-Rank <?php if(isset($s['streak_days'])&&$s['streak_days']>0):?> • 🔥<?=$s['streak_days']?>d<?php endif;?></div>
    </div>
    <div style="font-family:'Orbitron',monospace;font-size:16px;font-weight:800;color:var(--primary);"><?=$fmt($s[$field])?></div>
  </div>
  <?php $rank++;endforeach;?>
</div>
<?php endforeach;?>
</div>
<script>
function showLB(t){
  ['study','streak','mcq'].forEach(id=>{
    document.getElementById('lbpanel-'+id).style.display=id===t?'block':'none';
    const btn=document.getElementById('lbtab-'+id);
    btn.style.background=id===t?'var(--card)':'transparent';
    btn.style.color=id===t?'var(--primary)':'var(--muted)';
    btn.style.boxShadow=id===t?'0 2px 8px rgba(0,0,0,.2)':'none';
  });
}
showLB('study');
</script>
<?php include '../includes/footer.php';?>
