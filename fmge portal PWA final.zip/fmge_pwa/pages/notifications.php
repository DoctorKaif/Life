<?php
require_once '../includes/config.php';
requireLogin();
$db=getDB();$uid=(int)$_SESSION['user_id'];
$db->query("UPDATE notifications SET is_read=1 WHERE user_id=$uid");
$notifs=$db->query("SELECT * FROM notifications WHERE user_id=$uid ORDER BY created_at DESC LIMIT 50");
$pageTitle='Notifications';$activePage='notifications';
include '../includes/header.php';
?>
<div class="page-content" style="max-width:640px;">
<div class="card">
  <div class="card-title" style="margin-bottom:18px;">🔔 Notifications</div>
  <?php if($notifs&&$notifs->num_rows>0):while($n=$notifs->fetch_assoc()):
    $icons=['info'=>'ℹ️','success'=>'✅','warning'=>'⚠️','badge'=>'🎖️','levelup'=>'⬆️'];
    $icon=$icons[$n['type']]??'🔔';
  ?>
  <div style="display:flex;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);">
    <div style="font-size:20px;"><?=$icon?></div>
    <div style="flex:1;"><div style="font-size:13px;color:var(--text);"><?=clean($n['message'])?></div><div style="font-size:10px;color:var(--muted);margin-top:4px;"><?=date('d M Y, h:i A',strtotime($n['created_at']))?></div></div>
  </div>
  <?php endwhile;else:?><p style="color:var(--muted);font-size:13px;padding:20px 0;text-align:center;">No notifications yet.</p><?php endif;?>
</div>
</div>
<?php include '../includes/footer.php';?>
