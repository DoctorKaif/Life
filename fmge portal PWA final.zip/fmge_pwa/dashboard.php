<?php
require_once 'includes/config.php';
requireLogin();
$user = getCurrentUser();
$db   = getDB();
$uid  = (int)$_SESSION['user_id'];
$today = date('Y-m-d');

// Stats
$studyToday  = (int)($db->query("SELECT SUM(duration_minutes) as t FROM study_sessions WHERE user_id=$uid AND session_date='$today'")->fetch_assoc()['t'] ?? 0);
$avgProgress = round((float)($db->query("SELECT AVG((completed_topics/total_topics)*100) as p FROM subject_progress WHERE user_id=$uid")->fetch_assoc()['p'] ?? 0));
$mcqToday    = $db->query("SELECT SUM(total_attempted) as ta, SUM(correct) as tc FROM mcq_records WHERE user_id=$uid AND record_date='$today'")->fetch_assoc();
$lastExam    = $db->query("SELECT exam_name,obtained_marks,total_marks,exam_date FROM exam_records WHERE user_id=$uid ORDER BY exam_date DESC LIMIT 1")->fetch_assoc();
$todayRating = (int)($db->query("SELECT rating FROM daily_ratings WHERE user_id=$uid AND rating_date='$today'")->fetch_assoc()['rating'] ?? 0);
$daysLeft    = $user['exam_date'] ? max(0, ceil((strtotime($user['exam_date'])-time())/86400)) : 0;
$rank        = getMilitaryRank($user['level'] ?? 1);
$xpNeeded    = xpForLevel($user['level'] ?? 1);
$xpPct       = $xpNeeded > 0 ? min(100, round(($user['xp'] ?? 0)/$xpNeeded*100)) : 0;

// Quote of the day
$qTotal  = (int)($db->query("SELECT COUNT(*) as c FROM quotes WHERE is_active=1")->fetch_assoc()['c'] ?? 1);
$qOff    = $qTotal > 0 ? (date('z') % $qTotal) : 0;
$quote   = $db->query("SELECT * FROM quotes WHERE is_active=1 LIMIT 1 OFFSET $qOff")->fetch_assoc();

// 7-day study data (Mon-Sun)
$heatmap = [];
$monday  = date('Y-m-d', strtotime('last monday', strtotime('+1 day')));
for ($i = 0; $i < 7; $i++) {
    $d = date('Y-m-d', strtotime($monday . " +$i days"));
    $mins = (int)($db->query("SELECT SUM(duration_minutes) as t FROM study_sessions WHERE user_id=$uid AND session_date='$d'")->fetch_assoc()['t'] ?? 0);
    $heatmap[] = ['date'=>$d,'mins'=>$mins,'label'=>date('D',$i === 0 ? strtotime($monday) : strtotime($monday . " +$i days")),'isToday'=>$d===$today];
}

// Daily quests
$quests = $db->query("SELECT q.*,COALESCE(uq.current_value,0) as cv,COALESCE(uq.is_completed,0) as done FROM quests q LEFT JOIN user_quests uq ON uq.quest_id=q.id AND uq.user_id=$uid AND uq.quest_date='$today' WHERE q.quest_type='daily' AND q.is_active=1 LIMIT 3");
$questList = []; if($quests) while($r=$quests->fetch_assoc()) $questList[]=$r;

// Timetable slots (today)
$now   = date('H:i:s');
$slots = $db->query("SELECT * FROM timetable WHERE user_id=$uid ORDER BY slot_start ASC LIMIT 8");
$slotList = []; if($slots) while($r=$slots->fetch_assoc()) $slotList[]=$r;

// Leaderboard
$lb = $db->query("SELECT id,full_name,avatar,level,rank_title,total_study_minutes,streak_days FROM users WHERE is_active=1 AND is_banned=0 ORDER BY total_study_minutes DESC LIMIT 5");
$lbList = []; if($lb) while($r=$lb->fetch_assoc()) $lbList[]=$r;

// Badges
$myBadges = $db->query("SELECT b.badge_name,b.badge_color FROM user_badges ub JOIN badges b ON b.id=ub.badge_id WHERE ub.user_id=$uid ORDER BY ub.earned_at DESC LIMIT 6");
$badgeList = []; if($myBadges) while($r=$myBadges->fetch_assoc()) $badgeList[]=$r;

// Study data for chart
$chartData = [];
for ($i = 13; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $mins = (int)($db->query("SELECT SUM(duration_minutes) as t FROM study_sessions WHERE user_id=$uid AND session_date='$d'")->fetch_assoc()['t'] ?? 0);
    $chartData[] = round($mins / 60, 1);
}

checkBadges($uid);
$pageTitle  = 'Dashboard';
$activePage = 'dashboard';
include 'includes/header.php';
?>
<div class="page-content">

<!-- ── HERO ── -->
<div style="position:relative;border-radius:24px;overflow:hidden;margin-bottom:24px;min-height:180px;background:var(--card);border:1px solid var(--border);" class="anim-fade-up">
  <!-- Ambient glow -->
  <div style="position:absolute;top:-60px;right:-40px;width:300px;height:300px;border-radius:50%;background:radial-gradient(circle,var(--glow),transparent);pointer-events:none;"></div>
  <div style="position:absolute;bottom:-40px;left:20%;width:200px;height:200px;border-radius:50%;background:radial-gradient(circle,rgba(91,63,160,.06),transparent);pointer-events:none;"></div>
  <!-- Top line shimmer -->
  <div style="position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,var(--primary),transparent);opacity:.4;"></div>

  <div style="position:relative;z-index:2;padding:28px 32px;">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:16px;">
      <div style="flex:1;min-width:240px;">
        <div style="font-size:10px;color:var(--muted);letter-spacing:3px;text-transform:uppercase;margin-bottom:6px;">Welcome back, Commander</div>
        <h1 style="font-family:'Orbitron',monospace;font-size:clamp(18px,3vw,26px);color:var(--text);margin-bottom:8px;line-height:1.2;">
          <?= clean(explode(' ',$user['full_name'])[0]) ?> <span style="color:var(--primary);"><?= $rank[0] ?>-Rank</span>
        </h1>
        <p style="font-size:12px;color:var(--muted);font-style:italic;line-height:1.7;max-width:420px;border-left:2px solid var(--border2);padding-left:12px;margin-bottom:16px;">
          "<?= clean($quote['quote_text'] ?? 'Keep pushing forward!') ?>"<br>
          <span style="font-size:10px;color:var(--muted2);">— <?= clean($quote['author'] ?? '') ?></span>
        </p>
        <!-- XP bar -->
        <div style="max-width:300px;">
          <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--muted);margin-bottom:4px;font-family:'JetBrains Mono',monospace;">
            <span>⚡ LVL <?= $user['level'] ?> · <?= number_format($user['xp'] ?? 0) ?> XP</span>
            <span><?= $xpPct ?>%</span>
          </div>
          <div class="prog-track"><div class="prog-fill" data-w="<?= $xpPct ?>%" style="width:0;background:linear-gradient(90deg,var(--primary),var(--secondary));"></div></div>
        </div>
      </div>
      <!-- Right stats -->
      <div style="display:flex;flex-direction:column;gap:8px;align-items:flex-end;flex-shrink:0;">
        <?php if($daysLeft > 0): ?>
        <div style="background:rgba(201,146,42,.08);border:1px solid rgba(201,146,42,.2);border-radius:14px;padding:12px 20px;text-align:center;">
          <div style="font-family:'Orbitron',monospace;font-size:30px;font-weight:900;color:var(--accent);" data-count="<?= $daysLeft ?>"><?= $daysLeft ?></div>
          <div style="font-size:9px;color:var(--muted);letter-spacing:1px;text-transform:uppercase;">Days to Exam</div>
        </div>
        <?php endif; ?>
        <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;">
          <span style="font-size:11px;padding:4px 10px;background:rgba(239,68,68,.1);color:#ef4444;border:1px solid rgba(239,68,68,.2);border-radius:20px;font-weight:700;">🔥 <?= $user['streak_days'] ?? 0 ?> day streak</span>
          <span style="font-size:11px;padding:4px 10px;background:rgba(201,146,42,.1);color:var(--accent);border:1px solid rgba(201,146,42,.2);border-radius:20px;font-weight:700;">🪙 <?= number_format($user['coins'] ?? 0) ?></span>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ── 2 KEY STATS ── -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px;">
  <?php foreach([
    ['⏱️','Today Study', floor($studyToday/60).'h '.($studyToday%60).'m', '#38b6cc', 'pages/timer.php'],
    ['📚','Avg Progress', $avgProgress.'%', '#1a9e6e', 'pages/roadmap.php'],
  ] as $i=>[$icon,$lbl,$val,$col,$link]): ?>
  <a href="<?= SITE_URL ?>/<?= $link ?>" style="text-decoration:none;" class="anim-fade-up" data-delay="<?= $i+1 ?>">
    <div class="stat-card" style="--c:<?= $col ?>;">
      <span class="stat-icon"><?= $icon ?></span>
      <div class="stat-val"><?= $val ?></div>
      <div class="stat-lbl"><?= $lbl ?></div>
    </div>
  </a>
  <?php endforeach; ?>
</div>

<!-- ── STUDY GRAPH ── -->
<div class="card mb-20 anim-fade-up" data-delay="2">
  <div class="card-hdr">
    <div>
      <div class="card-ttl">📈 Study History</div>
      <div class="card-sub">Last 14 days (hours)</div>
    </div>
    <button class="card-action" onclick="location.href='<?= SITE_URL ?>/pages/timer.php'">View All →</button>
  </div>
  <div style="height:140px;position:relative;">
    <canvas id="studyChart"></canvas>
  </div>
</div>

<!-- ── MIDDLE GRID: Quests + Schedule ── -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">

  <!-- Daily Quests -->
  <div class="card anim-fade-up" data-delay="3">
    <div class="card-hdr">
      <div><div class="card-ttl">⚡ Daily Quests</div><div class="card-sub">Complete for XP & Coins</div></div>
    </div>
    <?php foreach($questList as $q):
      $pct = $q['requirement_value'] > 0 ? min(100, round($q['cv']/$q['requirement_value']*100)) : 0;
    ?>
    <div style="margin-bottom:12px;padding:12px;background:<?= $q['done']?'rgba(26,158,110,.06)':'rgba(255,255,255,.02)' ?>;border-radius:10px;border:1px solid <?= $q['done']?'rgba(26,158,110,.2)':'var(--border2)' ?>;">
      <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
        <span style="font-size:12px;font-weight:600;<?= $q['done']?'text-decoration:line-through;color:var(--muted);':'' ?>"><?= clean($q['quest_name']) ?></span>
        <span style="font-size:11px;color:var(--accent);font-weight:700;">+<?= $q['xp_reward'] ?> XP</span>
      </div>
      <div class="prog-track" style="height:4px;">
        <div class="prog-fill" data-w="<?= $pct ?>%" style="width:0;background:<?= $q['done']?'var(--success)':'linear-gradient(90deg,var(--primary),var(--secondary))' ?>;"></div>
      </div>
      <div style="font-size:10px;color:var(--muted);margin-top:4px;"><?= $q['cv'] ?>/<?= $q['requirement_value'] ?><?= $q['done']?' ✅':'' ?></div>
    </div>
    <?php endforeach; ?>
    <?php if(empty($questList)): ?>
    <p style="color:var(--muted);font-size:12px;">Start studying to activate quests!</p>
    <?php endif; ?>
  </div>

  <!-- Today's Schedule -->
  <div class="card anim-fade-up" data-delay="4">
    <div class="card-hdr">
      <div><div class="card-ttl">📅 Today's Schedule</div><div class="card-sub"><?= date('D, d M') ?></div></div>
      <a href="<?= SITE_URL ?>/pages/timetable.php" class="card-action">Edit</a>
    </div>
    <?php if(!empty($slotList)): foreach($slotList as $s):
      $isNow  = $s['slot_start'] <= $now && $s['slot_end'] >= $now;
      $isPast = $s['slot_end'] < $now;
    ?>
    <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:9px;margin-bottom:4px;background:<?= $isNow?'rgba(56,182,204,.06)':'transparent' ?>;border:1px solid <?= $isNow?'rgba(56,182,204,.2)':'transparent' ?>;opacity:<?= $isPast?.5:1 ?>;cursor:<?= $isNow?'pointer':'default' ?>;" <?= $isNow?"onclick=\"startFloatingTimer('".clean($s['subject'])."')\"":''; ?>>
      <div style="width:7px;height:7px;border-radius:50%;background:<?= clean($s['color']) ?>;flex-shrink:0;<?= $isNow?'animation:dotPulse 1.5s infinite;':'' ?>"></div>
      <div style="font-size:10px;color:var(--muted);width:72px;flex-shrink:0;font-family:'JetBrains Mono',monospace;"><?= date('h:i A',strtotime($s['slot_start'])) ?></div>
      <div style="flex:1;font-size:12px;font-weight:<?= $isNow?'700':'500' ?>;color:<?= $isNow?'var(--primary)':'var(--text)' ?>;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= clean($s['subject']) ?></div>
      <?php if($isNow): ?><span style="font-size:9px;background:var(--primary);color:#000;padding:2px 6px;border-radius:4px;font-weight:800;flex-shrink:0;">▶ NOW</span><?php endif; ?>
    </div>
    <?php endforeach;
    else: ?>
    <div style="text-align:center;padding:20px;color:var(--muted);">
      <div style="font-size:28px;margin-bottom:8px;">📅</div>
      <div style="font-size:12px;">No slots. <a href="<?= SITE_URL ?>/pages/timetable.php" style="color:var(--primary);">Add schedule →</a></div>
    </div>
    <?php endif; ?>
  </div>

</div>

<!-- ── HEATMAP ── -->
<div class="card mb-20 anim-fade-up" data-delay="3">
  <div class="card-hdr">
    <div><div class="card-ttl">🔥 Weekly Study Heatmap</div><div class="card-sub">Mon → Sun · darker = more study</div></div>
  </div>
  <div style="display:flex;gap:8px;align-items:flex-end;height:72px;">
    <?php
    $maxMins = max(array_column($heatmap, 'mins'), 1) ?: 1;
    foreach($heatmap as $h):
      $barH = $h['mins'] > 0 ? max(8, round($h['mins']/$maxMins*64)) : 4;
      $opacity = $h['mins'] > 0 ? min(1, $h['mins']/300 + .25) : .08;
    ?>
    <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;">
      <div style="width:100%;height:<?= $barH ?>px;background:<?= $h['isToday']?'linear-gradient(180deg,var(--primary),var(--secondary))':'rgba(56,182,204,'.number_format($opacity,2).')' ?>;border-radius:4px;transition:height .8s ease;<?= $h['isToday']?'box-shadow:0 0 10px var(--glow);':'' ?>"></div>
      <div style="font-size:9px;color:var(--muted);text-transform:uppercase;font-family:'JetBrains Mono',monospace;<?= $h['isToday']?'color:var(--primary);font-weight:700;':'' ?>"><?= substr($h['label'],0,2) ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- ── LEADERBOARD + BADGES ── -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">

  <!-- Leaderboard -->
  <div class="card anim-fade-up" data-delay="4">
    <div class="card-hdr">
      <div><div class="card-ttl">🏆 Top Commanders</div></div>
      <a href="<?= SITE_URL ?>/pages/leaderboard.php" class="card-action">Full →</a>
    </div>
    <?php $lbRank=1; foreach($lbList as $s):
      $medals=['🥇','🥈','🥉','4️⃣','5️⃣'];
      $isMe=$s['id']===$uid;
      $ri=getMilitaryRank($s['level']??1);
    ?>
    <div style="display:flex;align-items:center;gap:10px;padding:8px;border-radius:9px;margin-bottom:3px;background:<?= $isMe?'rgba(56,182,204,.06)':'transparent' ?>;transition:background .2s;" onmouseover="this.style.background='rgba(255,255,255,.02)'" onmouseout="this.style.background='<?= $isMe?'rgba(56,182,204,.06)':'transparent' ?>'">
      <span style="font-size:15px;width:22px;"><?= $medals[$lbRank-1] ?? '#'.$lbRank ?></span>
      <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;font-weight:700;overflow:hidden;flex-shrink:0;">
        <?php if(!empty($s['avatar'])): ?><img src="<?= SITE_URL ?>/uploads/avatars/<?= clean($s['avatar']) ?>" style="width:100%;height:100%;object-fit:cover;"/><?php else: ?><?= strtoupper(substr($s['full_name'],0,1)) ?><?php endif; ?>
      </div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:12px;font-weight:<?= $isMe?'700':'500' ?>;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= clean(explode(' ',$s['full_name'])[0]) ?><?= $isMe?' (You)':'' ?></div>
        <div style="font-size:9px;color:var(--muted);">🔥<?= $s['streak_days'] ?>d</div>
      </div>
      <div style="font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;color:var(--primary);flex-shrink:0;"><?= floor($s['total_study_minutes']/60) ?>h</div>
    </div>
    <?php $lbRank++; endforeach; ?>
  </div>

  <!-- My Badges -->
  <div class="card anim-fade-up" data-delay="5">
    <div class="card-hdr">
      <div><div class="card-ttl">🎖️ My Badges</div></div>
      <a href="<?= SITE_URL ?>/pages/profile.php" class="card-action">All →</a>
    </div>
    <?php if(!empty($badgeList)): ?>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;">
      <?php foreach($badgeList as $b): ?>
      <div style="text-align:center;padding:10px 6px;background:rgba(255,255,255,.02);border-radius:10px;border:1px solid var(--border);transition:all .2s;" onmouseover="this.style.borderColor='var(--primary)';this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='var(--border)';this.style.transform=''">
        <div style="font-size:20px;margin-bottom:4px;">🏅</div>
        <div style="font-size:9px;font-weight:700;color:var(--text);line-height:1.3;"><?= clean($b['badge_name']) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div style="text-align:center;padding:20px;color:var(--muted);">
      <div style="font-size:28px;margin-bottom:8px;">🏅</div>
      <div style="font-size:12px;">Keep studying — badges incoming!</div>
    </div>
    <?php endif; ?>
  </div>

</div>

<!-- ── QUICK ACTIONS ── -->
<div class="card mb-20 anim-fade-up" data-delay="4">
  <div class="card-ttl" style="margin-bottom:14px;">⚡ Quick Actions</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;">
    <?php foreach([
      ['⏱️','Start Timer','pages/timer.php','var(--primary)'],
      ['🎯','Add MCQs','pages/performance.php','var(--accent)'],
      ['📊','Exam Marks','pages/performance.php','var(--secondary)'],
      ['👥','Community','pages/community.php','var(--success)'],
      ['🗺️','Roadmap','pages/roadmap.php','var(--danger)'],
      ['📔','Diary','pages/diary.php','#06b6d4'],
    ] as $a): ?>
    <a href="<?= SITE_URL ?>/<?= $a[2] ?>" style="display:flex;align-items:center;gap:8px;padding:11px 12px;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:11px;text-decoration:none;transition:all .2s;color:var(--text);" onmouseover="this.style.borderColor='<?= $a[3] ?>';this.style.background='<?= $a[3] ?>10';this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='var(--border)';this.style.background='rgba(255,255,255,.02)';this.style.transform=''">
      <span style="font-size:18px;"><?= $a[0] ?></span>
      <span style="font-size:12px;font-weight:600;"><?= $a[1] ?></span>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<!-- ── DAILY RATING ── -->
<div class="card anim-fade-up" data-delay="5">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <div><div class="card-ttl">⭐ How Was Your Day?</div><div class="card-sub">Rate your productivity</div></div>
    <div style="display:flex;gap:6px;" id="starsWrap">
      <?php for($i=1;$i<=5;$i++): ?>
      <button onclick="saveRating(<?= $i ?>)" style="font-size:26px;background:none;border:none;cursor:pointer;filter:<?= $todayRating>=$i?'none':'grayscale(1)' ?>;opacity:<?= $todayRating>=$i?'1':'.3' ?>;transition:all .2s;padding:3px;" onmouseover="this.style.transform='scale(1.3)'" onmouseout="this.style.transform=''"><?= $todayRating>=$i?'⭐':'☆' ?></button>
      <?php endfor; ?>
    </div>
    <div id="ratingMsg" style="font-size:13px;color:var(--success);font-weight:600;">
      <?php $msgs=['','Keep pushing! 💪','Getting better! 📈','Good day! 👍','Great session! 🌟','Perfect day! 🏆']; echo $todayRating>0?$msgs[$todayRating]:''; ?>
    </div>
  </div>
</div>

</div>

<script>
// Study Chart
const studyData = <?= json_encode($chartData) ?>;
const days14 = [];
for(let i=13;i>=0;i--){
  const d=new Date(); d.setDate(d.getDate()-i);
  days14.push(d.toLocaleDateString('en-US',{weekday:'short',day:'numeric'}));
}
const primary = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim() || '#38b6cc';
const chartEl = document.getElementById('studyChart');
if(chartEl){
  new Chart(chartEl.getContext('2d'),{
    type:'bar',
    data:{
      labels:days14,
      datasets:[{
        data:studyData,
        backgroundColor:studyData.map((_,i)=>i===studyData.length-1?primary:primary+'44'),
        borderRadius:6,
        borderSkipped:false,
      },{
        data:studyData.map((_,i)=>i>0?studyData[i-1]:null),
        type:'line',
        borderColor:primary+'88',
        borderWidth:1.5,
        borderDash:[4,4],
        pointRadius:0,
        fill:false,
        tension:.4,
      }]
    },
    options:{
      responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>c.parsed.y+'h studied'}}},
      scales:{
        y:{min:0,ticks:{callback:v=>v+'h',color:'var(--muted)',font:{size:10}},grid:{color:'rgba(255,255,255,.04)'}},
        x:{ticks:{color:'var(--muted)',font:{size:9},maxRotation:0},grid:{display:false}}
      }
    }
  });
}

// Daily Rating
function saveRating(r){
  fetch('<?= SITE_URL ?>/api/save_rating.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rating:r})})
  .then(res=>res.json()).then(d=>{
    if(d.success){
      document.querySelectorAll('#starsWrap button').forEach((btn,i)=>{
        btn.textContent=i<r?'⭐':'☆';
        btn.style.filter=i<r?'none':'grayscale(1)';
        btn.style.opacity=i<r?'1':'.3';
      });
      const msgs=['','Keep pushing! 💪','Getting better! 📈','Good day! 👍','Great session! 🌟','Perfect day! 🏆'];
      document.getElementById('ratingMsg').textContent=msgs[r];
      showToast('Day rated! +15 XP ⭐');
    }
  });
}
</script>

<?php include 'includes/footer.php'; ?>
