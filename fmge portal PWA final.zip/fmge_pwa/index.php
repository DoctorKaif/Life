<?php
require_once 'includes/config.php';
if(isset($_SESSION['user_id'])){ header('Location: dashboard.php'); exit; }
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    // CSRF check
    if(!csrf_verify($_POST[CSRF_TOKEN_NAME]??'')){ $error='Security error. Refresh and try again.'; goto render; }
    $ip = $_SERVER['REMOTE_ADDR'];
    if(!rate_limit('login_'.$ip, 5, 300)){ $error='Too many attempts. Wait 5 minutes.'; goto render; }
    $username=clean($_POST['username']??'');
    $password=$_POST['password']??'';
    $remember=isset($_POST['remember']);
    if($username&&$password){
        $db=getDB();
        $stmt=$db->prepare("SELECT * FROM users WHERE username=? AND is_banned=0 AND is_active=1 LIMIT 1");
        $stmt->bind_param('s',$username); $stmt->execute();
        $user=$stmt->get_result()->fetch_assoc();
        if($user&&password_verify($password,$user['password'])){
            session_regenerate_id(true);
            $_SESSION['user_id']=$user['id'];$_SESSION['username']=$user['username'];
            $_SESSION['full_name']=$user['full_name'];$_SESSION['role']=$user['role'];
            if($remember){
                $token=bin2hex(random_bytes(32));
                $st2=$db->prepare("UPDATE users SET remember_token=? WHERE id=?");
                $st2->bind_param('si',$token,$user['id']); $st2->execute();
                setcookie('fmge_token',$token,time()+86400*30,'/','',(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']==='on'),true);
            }
            addXP($user['id'],10,10); updateStreak($user['id']); checkBadges($user['id']);
            header('Location: dashboard.php'); exit;
        } else { $error='Invalid username or password.'; }
    } else { $error='Please fill in all fields.'; }
}
render:
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
<meta name="apple-mobile-web-app-title" content="FMGE"/>
<meta name="mobile-web-app-capable" content="yes"/>
<meta name="theme-color" content="#03030a"/>
<meta name="application-name" content="FMGE Portal"/>
<meta name="msapplication-TileColor" content="#03030a"/>
<meta name="msapplication-TileImage" content="/assets/icons/icon-144.png"/>
<!-- Apple Touch Icons -->
<link rel="apple-touch-icon" href="/assets/icons/icon-152.png"/>
<link rel="apple-touch-icon" sizes="192x192" href="/assets/icons/icon-192.png"/>
<link rel="apple-touch-startup-image" href="/assets/icons/icon-512.png"/>
<!-- PWA Manifest -->
<link rel="manifest" href="/manifest.json"/>
<title>Login — FMGE Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet"/>
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
html{height:100%;}
body{min-height:100vh;font-family:'Syne',sans-serif;background:#03030a;display:flex;align-items:center;justify-content:center;overflow:hidden;position:relative;}

/* ── ANIMATED BACKGROUND ── */
.bg-canvas{position:fixed;inset:0;z-index:0;}
.orb{position:absolute;border-radius:50%;filter:blur(120px);will-change:transform;}
.orb-1{width:600px;height:600px;background:radial-gradient(circle,rgba(139,92,246,.18),transparent 70%);top:-150px;right:-100px;animation:orbDrift1 12s ease-in-out infinite;}
.orb-2{width:500px;height:500px;background:radial-gradient(circle,rgba(236,72,153,.1),transparent 70%);bottom:-120px;left:-80px;animation:orbDrift2 15s ease-in-out infinite;}
.orb-3{width:300px;height:300px;background:radial-gradient(circle,rgba(245,158,11,.08),transparent 70%);top:40%;left:38%;animation:orbDrift3 9s ease-in-out infinite;}
@keyframes orbDrift1{0%,100%{transform:translate(0,0)}33%{transform:translate(-30px,20px)}66%{transform:translate(20px,-25px)}}
@keyframes orbDrift2{0%,100%{transform:translate(0,0)}50%{transform:translate(35px,-30px)}}
@keyframes orbDrift3{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(-20px,15px) scale(1.1)}}

/* Particle dots */
.particles{position:fixed;inset:0;z-index:0;pointer-events:none;}
.p{position:absolute;width:2px;height:2px;border-radius:50%;background:rgba(139,92,246,.4);animation:pFloat linear infinite;}
@keyframes pFloat{0%{transform:translateY(100vh) rotate(0);opacity:0}10%{opacity:.6}90%{opacity:.3}100%{transform:translateY(-10vh) rotate(720deg);opacity:0}}

/* Grid overlay */
.grid-overlay{position:fixed;inset:0;z-index:0;background-image:linear-gradient(rgba(139,92,246,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(139,92,246,.03) 1px,transparent 1px);background-size:40px 40px;pointer-events:none;}

/* ── WRAP ── */
.wrap{position:relative;z-index:10;width:100%;max-width:420px;padding:20px;animation:wrapIn .8s cubic-bezier(.34,1.56,.64,1) both;}
@keyframes wrapIn{from{opacity:0;transform:translateY(40px) scale(.92)}to{opacity:1;transform:translateY(0) scale(1)}}

/* ── CARD ── */
.card-shell{position:relative;border-radius:28px;padding:1.5px;background:linear-gradient(135deg,rgba(139,92,246,.7) 0%,rgba(236,72,153,.4) 50%,rgba(139,92,246,.7) 100%);background-size:200% 200%;animation:borderRotate 4s ease infinite;}
@keyframes borderRotate{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}
.card-inner{background:linear-gradient(135deg,#08051a 0%,#06040f 60%,#0a0520 100%);border-radius:26.5px;padding:44px 40px;position:relative;overflow:hidden;}
.card-inner::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,rgba(139,92,246,.6),rgba(236,72,153,.4),transparent);}
.card-inner::after{content:'';position:absolute;top:0;left:0;right:0;height:160px;background:radial-gradient(ellipse at 50% -20%,rgba(139,92,246,.12),transparent 70%);pointer-events:none;}

/* Shimmer sweep */
.shimmer-wrap{position:absolute;inset:0;overflow:hidden;border-radius:26.5px;pointer-events:none;}
.shimmer{position:absolute;top:0;left:-100%;width:60%;height:100%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.03),transparent);animation:shimmerSweep 5s ease-in-out infinite;}
@keyframes shimmerSweep{0%{left:-100%}60%,100%{left:150%}}

/* ── LOGO ── */
.logo{text-align:center;margin-bottom:36px;}
.logo-icon-wrap{position:relative;display:inline-block;margin-bottom:16px;}
.logo-icon{width:80px;height:80px;background:linear-gradient(135deg,#8b5cf6,#ec4899);border-radius:24px;display:inline-flex;align-items:center;justify-content:center;font-size:34px;box-shadow:0 0 0 0 rgba(139,92,246,.4);animation:iconPulse 3s ease-in-out infinite,iconEntry .6s cubic-bezier(.34,1.56,.64,1) .1s both;}
@keyframes iconPulse{0%,100%{box-shadow:0 0 0 0 rgba(139,92,246,.4),0 20px 60px rgba(139,92,246,.3)}50%{box-shadow:0 0 0 12px rgba(139,92,246,.0),0 20px 60px rgba(139,92,246,.5)}}
@keyframes iconEntry{from{opacity:0;transform:scale(.5) rotate(-10deg)}to{opacity:1;transform:scale(1) rotate(0)}}
.logo-ring{position:absolute;inset:-8px;border-radius:32px;border:1.5px solid rgba(139,92,246,.3);animation:ringPulse 3s ease-in-out infinite;}
.logo-ring-2{position:absolute;inset:-16px;border-radius:40px;border:1px solid rgba(139,92,246,.12);animation:ringPulse 3s ease-in-out infinite .5s;}
@keyframes ringPulse{0%,100%{opacity:.5;transform:scale(1)}50%{opacity:1;transform:scale(1.04)}}
.logo h1{font-family:'Orbitron',monospace;font-size:22px;color:#e8e0ff;letter-spacing:3px;margin-bottom:5px;animation:fadeUp .6s ease .25s both;}
.logo p{font-size:10px;color:rgba(139,92,246,.5);letter-spacing:1.5px;text-transform:uppercase;animation:fadeUp .6s ease .35s both;}
.tags{display:flex;gap:6px;justify-content:center;margin-top:12px;flex-wrap:wrap;animation:fadeUp .6s ease .45s both;}
.tag{font-size:10px;padding:3px 11px;background:rgba(139,92,246,.1);color:#8b5cf6;border:1px solid rgba(139,92,246,.2);border-radius:20px;font-weight:600;transition:all .2s;}
.tag:hover{background:rgba(139,92,246,.2);transform:translateY(-1px);}

/* ── FORM ── */
.form-group{margin-bottom:16px;}
.label{font-size:10px;font-weight:700;color:rgba(139,92,246,.6);display:block;margin-bottom:6px;letter-spacing:1.5px;text-transform:uppercase;}
.input-wrap{position:relative;}
.input-icon{position:absolute;left:15px;top:50%;transform:translateY(-50%);font-size:16px;pointer-events:none;z-index:1;}
.input{width:100%;padding:13px 15px 13px 46px;border:1.5px solid rgba(139,92,246,.15);border-radius:14px;font-size:14px;font-family:'Syne',sans-serif;color:#e8e0ff;background:rgba(139,92,246,.04);transition:all .3s cubic-bezier(.4,0,.2,1);outline:none;}
.input:focus{border-color:rgba(139,92,246,.5);box-shadow:0 0 0 4px rgba(139,92,246,.1),inset 0 1px 0 rgba(255,255,255,.04);background:rgba(139,92,246,.08);}
.input::placeholder{color:rgba(255,255,255,.15);}
/* Focus line animation */
.input-line{position:absolute;bottom:0;left:50%;right:50%;height:1.5px;background:linear-gradient(90deg,#8b5cf6,#ec4899);border-radius:0 0 14px 14px;transition:all .3s ease;}
.input:focus~.input-line{left:2%;right:2%;}

/* Eye toggle */
.eye-toggle{position:absolute;right:14px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:rgba(139,92,246,.4);font-size:16px;padding:3px;transition:color .2s;}
.eye-toggle:hover{color:rgba(139,92,246,.8);}

.remember-row{display:flex;align-items:center;gap:8px;margin-bottom:20px;}
.remember-row input{width:15px;height:15px;accent-color:#8b5cf6;cursor:pointer;}
.remember-row label{font-size:12px;color:rgba(255,255,255,.3);cursor:pointer;user-select:none;}

/* ── LOGIN BUTTON ── */
.btn-login{width:100%;padding:15px;background:linear-gradient(135deg,#8b5cf6,#ec4899);color:#fff;border:none;border-radius:14px;font-size:14px;font-weight:700;font-family:'Orbitron',monospace;cursor:pointer;transition:all .3s cubic-bezier(.34,1.56,.64,1);letter-spacing:.5px;position:relative;overflow:hidden;}
.btn-login::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(255,255,255,.15),transparent);opacity:0;transition:opacity .3s;}
.btn-login:hover{transform:translateY(-3px);box-shadow:0 16px 48px rgba(139,92,246,.5);}
.btn-login:hover::before{opacity:1;}
.btn-login:active{transform:scale(.97) translateY(0);}
.btn-login.loading{pointer-events:none;opacity:.7;}
.btn-inner{display:flex;align-items:center;justify-content:center;gap:8px;}
.btn-spinner{width:16px;height:16px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .6s linear infinite;display:none;}
.btn-login.loading .btn-spinner{display:block;}
.btn-login.loading .btn-text{opacity:.7;}
@keyframes spin{to{transform:rotate(360deg)}}

/* ── ERROR ── */
.error{background:rgba(192,56,74,.1);border:1px solid rgba(192,56,74,.3);border-radius:12px;padding:12px 16px;color:#ef4444;font-size:12px;margin-bottom:16px;display:flex;align-items:center;gap:8px;animation:errorShake .4s ease;}
@keyframes errorShake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-6px)}40%,80%{transform:translateX(6px)}}

/* Success feedback */
.success-overlay{position:absolute;inset:0;background:rgba(26,158,110,.08);border-radius:26.5px;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .3s;pointer-events:none;z-index:20;}
.success-overlay.show{opacity:1;}
.checkmark{font-size:60px;animation:checkPop .5s cubic-bezier(.34,1.56,.64,1);}
@keyframes checkPop{from{transform:scale(0);opacity:0}to{transform:scale(1);opacity:1}}

.footer{text-align:center;margin-top:20px;font-size:11px;color:rgba(255,255,255,.12);}

@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
.form-anim-1{animation:fadeUp .5s ease .5s both;}
.form-anim-2{animation:fadeUp .5s ease .58s both;}
.form-anim-3{animation:fadeUp .5s ease .66s both;}
.form-anim-4{animation:fadeUp .5s ease .74s both;}

@media(max-width:460px){.card-inner{padding:32px 24px;}.wrap{padding:14px;}}
</style>
</head>
<body>

<!-- BACKGROUND -->
<div class="bg-canvas">
  <div class="orb orb-1"></div>
  <div class="orb orb-2"></div>
  <div class="orb orb-3"></div>
</div>
<div class="grid-overlay"></div>
<!-- Particles -->
<div class="particles" id="particles"></div>

<div class="wrap">
  <div class="card-shell">
    <div class="card-inner" id="loginCard">
      <div class="shimmer-wrap"><div class="shimmer"></div></div>

      <!-- Success overlay -->
      <div class="success-overlay" id="successOverlay">
        <div class="checkmark">✅</div>
      </div>

      <!-- Logo -->
      <div class="logo">
        <div class="logo-icon-wrap">
          <div class="logo-ring"></div>
          <div class="logo-ring-2"></div>
          <div class="logo-icon">⚕️</div>
        </div>
        <h1>FMGE PORTAL</h1>
        <p>Your Journey to Becoming a Doctor</p>
        <div class="tags">
          <span class="tag">⚔️ RPG</span>
          <span class="tag">📊 Analytics</span>
          <span class="tag">🤝 Social</span>
          <span class="tag">🏆 Ranks</span>
        </div>
      </div>

      <?php if($error): ?>
      <div class="error">⚠️ <?= $error ?></div>
      <?php endif; ?>

      <form method="POST" id="loginForm" autocomplete="on">
        <?= csrf_field() ?>
        <div class="form-group form-anim-1">
          <label class="label">Username</label>
          <div class="input-wrap">
            <span class="input-icon">👤</span>
            <input class="input" type="text" name="username" placeholder="Enter your username" required autofocus autocomplete="username"/>
            <div class="input-line"></div>
          </div>
        </div>
        <div class="form-group form-anim-2">
          <label class="label">Password</label>
          <div class="input-wrap">
            <span class="input-icon">🔒</span>
            <input class="input" type="password" id="pwdInput" name="password" placeholder="Enter your password" required autocomplete="current-password"/>
            <button type="button" class="eye-toggle" id="eyeBtn" aria-label="Show password">👁️</button>
            <div class="input-line"></div>
          </div>
        </div>
        <div class="remember-row form-anim-3">
          <input type="checkbox" name="remember" id="rem"/>
          <label for="rem">Remember me for 30 days</label>
        </div>
        <button type="submit" class="btn-login form-anim-4" id="loginBtn">
          <div class="btn-inner">
            <div class="btn-spinner"></div>
            <span class="btn-text">ENTER THE PORTAL →</span>
          </div>
        </button>
      </form>
      <div class="footer">🔐 Secure Portal · Contact admin for access</div>
    </div>
  </div>
</div>

<script>
// Particles
const pc=document.getElementById('particles');
for(let i=0;i<25;i++){
  const p=document.createElement('div'); p.className='p';
  p.style.cssText=`left:${Math.random()*100}%;animation-duration:${8+Math.random()*12}s;animation-delay:${Math.random()*10}s;width:${1+Math.random()*2}px;height:${1+Math.random()*2}px;opacity:${.2+Math.random()*.4}`;
  pc.appendChild(p);
}

// Service Worker registration
if('serviceWorker' in navigator){
  window.addEventListener('load',()=>{
    navigator.serviceWorker.register('/sw.js',{scope:'/'})
      .then(reg=>{ console.log('SW registered ✅', reg.scope); })
      .catch(err=>{ console.log('SW failed', err); });
  });
}

// PWA Install prompt
let deferredPrompt=null;
window.addEventListener('beforeinstallprompt',e=>{
  e.preventDefault();deferredPrompt=e;
  // Show install banner after 3s
  setTimeout(()=>{
    const banner=document.createElement('div');
    banner.id='installBanner';
    banner.style.cssText='position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,rgba(139,92,246,.95),rgba(236,72,153,.95));color:#fff;padding:12px 20px;border-radius:50px;font-size:12px;font-family:Syne,sans-serif;font-weight:700;cursor:pointer;z-index:9999;display:flex;align-items:center;gap:8px;box-shadow:0 8px 32px rgba(139,92,246,.4);animation:slideUp .4s cubic-bezier(.34,1.56,.64,1);white-space:nowrap;';
    banner.innerHTML='<span>📲</span><span>Install FMGE App</span><span style="opacity:.6;font-size:11px;">→</span>';
    banner.onclick=()=>{ if(deferredPrompt){ deferredPrompt.prompt(); deferredPrompt.userChoice.then(()=>{deferredPrompt=null; banner.remove();}); } };
    const style=document.createElement('style');
    style.textContent='@keyframes slideUp{from{transform:translateX(-50%) translateY(80px);opacity:0}to{transform:translateX(-50%) translateY(0);opacity:1}}';
    document.head.appendChild(style);
    document.body.appendChild(banner);
    setTimeout(()=>{ if(banner.parentNode) banner.remove(); },8000);
  },3000);
});

// Password toggle
document.getElementById('eyeBtn').addEventListener('click',function(){
  const inp=document.getElementById('pwdInput');
  const isP=inp.type==='password';
  inp.type=isP?'text':'password';
  this.textContent=isP?'🙈':'👁️';
});

// Form loading state + success
document.getElementById('loginForm').addEventListener('submit',function(e){
  const btn=document.getElementById('loginBtn');
  btn.classList.add('loading');
  // Show success animation after submit (if no PHP error redirect happens)
  setTimeout(()=>{
    document.getElementById('successOverlay').classList.add('show');
  },300);
});

// Input ripple on focus
document.querySelectorAll('.input').forEach(inp=>{
  inp.addEventListener('focus',function(){
    this.closest('.input-wrap').querySelector('.input-line').style.opacity='1';
  });
  inp.addEventListener('blur',function(){
    this.closest('.input-wrap').querySelector('.input-line').style.opacity='0';
  });
});
</script>
</body>
</html>
