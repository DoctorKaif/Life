</div><!-- /.main -->

<!-- ── APPLE-LEVEL MOTION ENGINE ── -->
<script>
(function(){
'use strict';

// ─ 1. SCROLL REVEAL (IntersectionObserver) ─
const revealEls = document.querySelectorAll('.reveal,.reveal-scale,.reveal-left,.reveal-right');
if(revealEls.length){
  const obs = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){ e.target.classList.add('visible'); obs.unobserve(e.target); }
    });
  },{threshold:.12,rootMargin:'0px 0px -30px 0px'});
  revealEls.forEach(el=>obs.observe(el));
}

// ─ 2. PROGRESS BARS ANIMATE ON VISIBLE ─
const progFills = document.querySelectorAll('.prog-fill[data-w]');
if(progFills.length){
  const po = new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        setTimeout(()=>{ e.target.style.width=e.target.dataset.w; },100);
        po.unobserve(e.target);
      }
    });
  },{threshold:.5});
  progFills.forEach(el=>{ el.style.width='0'; po.observe(el); });
}

// ─ 3. COUNT-UP ANIMATION ─
function animateCount(el, end, duration=1200){
  const start = 0;
  const startTime = performance.now();
  const isInt = Number.isInteger(end);
  function step(now){
    const progress = Math.min((now-startTime)/duration,1);
    const eased = 1-Math.pow(1-progress,3); // ease-out cubic
    const val = eased*end;
    el.textContent = isInt ? Math.floor(val).toLocaleString() : val.toFixed(1);
    if(progress<1) requestAnimationFrame(step);
    else el.textContent = isInt ? end.toLocaleString() : end.toFixed(1);
  }
  requestAnimationFrame(step);
}
const countEls = document.querySelectorAll('[data-count]');
if(countEls.length){
  const co = new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        animateCount(e.target, parseFloat(e.target.dataset.count));
        co.unobserve(e.target);
      }
    });
  },{threshold:.5});
  countEls.forEach(el=>co.observe(el));
}

// ─ 4. CURSOR GLOW (desktop) ─
if(window.matchMedia('(pointer:fine)').matches){
  const glow = document.createElement('div');
  glow.className='cursor-glow'; glow.style.opacity='0';
  document.body.appendChild(glow);
  let mx=0,my=0,cx=0,cy=0,raf=null;
  document.addEventListener('mousemove',e=>{ mx=e.clientX; my=e.clientY; glow.style.opacity='1'; });
  document.addEventListener('mouseleave',()=>glow.style.opacity='0');
  function smoothCursor(){
    cx+=(mx-cx)*.08; cy+=(my-cy)*.08;
    glow.style.left=cx+'px'; glow.style.top=cy+'px';
    raf=requestAnimationFrame(smoothCursor);
  }
  smoothCursor();
}

// ─ 5. RIPPLE on buttons ─
document.addEventListener('click',function(e){
  const btn = e.target.closest('.btn,.btn-primary,.card-action,.btn-login,.modal-save');
  if(!btn) return;
  const r=document.createElement('span'); r.className='ripple';
  const rect=btn.getBoundingClientRect();
  const size=Math.max(rect.width,rect.height);
  r.style.cssText=`width:${size}px;height:${size}px;left:${e.clientX-rect.left-size/2}px;top:${e.clientY-rect.top-size/2}px;`;
  btn.classList.add('ripple-host');
  btn.appendChild(r);
  setTimeout(()=>r.remove(),500);
});

// ─ 6. LIQUID button mouse tracking ─
document.querySelectorAll('.btn-liquid,.btn-primary,.btn-login').forEach(btn=>{
  btn.addEventListener('mousemove',e=>{
    const r=btn.getBoundingClientRect();
    btn.style.setProperty('--mx',((e.clientX-r.left)/r.width*100)+'%');
    btn.style.setProperty('--my',((e.clientY-r.top)/r.height*100)+'%');
  });
});

// ─ 7. CARD SPRING — add to all .card ─
document.querySelectorAll('.card:not(.no-spring)').forEach(c=>{
  if(!c.closest('.modal')) c.classList.add('card-spring');
});

// ─ 8. STAGGER REVEAL for .anim-fade-up ─
document.querySelectorAll('.anim-fade-up').forEach(el=>{
  el.classList.add('reveal');
});

// ─ 9. CLOCK (topbar) ─
const clockEl = document.getElementById('topClock');
if(clockEl){
  function updateClock(){
    const now=new Date();
    const h=String(now.getHours()).padStart(2,'0');
    const m=String(now.getMinutes()).padStart(2,'0');
    const s=String(now.getSeconds()).padStart(2,'0');
    clockEl.textContent=h+':'+m+':'+s;
  }
  updateClock(); setInterval(updateClock,1000);
}

// ─ 10. TOAST function (global) ─
window.showToast = function(msg, type='success', duration=3000){
  let t=document.getElementById('globalToast');
  if(!t){ t=document.createElement('div'); t.id='globalToast'; t.className='toast'; document.body.appendChild(t); }
  t.textContent=msg;
  t.style.borderColor=type==='error'?'var(--danger)':type==='warn'?'var(--accent)':'var(--primary)';
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer=setTimeout(()=>t.classList.remove('show'),duration);
};

// ─ 11. Page transitions ─
document.querySelectorAll('a[href]:not([target]):not([href^="#"]):not([href^="javascript"]):not([href^="mailto"])').forEach(link=>{
  link.addEventListener('click',function(e){
    const href=this.getAttribute('href');
    if(!href||href==='#'||href.startsWith('javascript')) return;
    e.preventDefault();
    document.querySelector('.page-content')?.classList.add('page-transition-out');
    setTimeout(()=>{ window.location.href=href; },200);
  });
});

// ─ 12. FLOATING TIMER global (if startFloatingTimer exists) ─
window.startFloatingTimer = window.startFloatingTimer || function(subject){
  const ft=document.getElementById('floatingTimer');
  if(!ft) return;
  ft.classList.add('active');
  document.getElementById('ftSubject').textContent=subject;
  let secs=0;
  if(ft._interval) clearInterval(ft._interval);
  const flame=document.getElementById('candleFlame');
  const body=document.getElementById('candleBody');
  const display=document.getElementById('ftTime');
  if(flame) flame.style.display='block';
  ft._interval=setInterval(()=>{
    secs++;
    const h=Math.floor(secs/3600),m=Math.floor(secs%3600/60),s=secs%60;
    if(display) display.textContent=(h?String(h).padStart(2,'0')+':':'')+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
    // Candle burns down
    if(body){ const h2=Math.max(4,44-Math.floor(secs/60)); body.style.height=h2+'px'; }
  },1000);
};

// ─ 13. Theme modal (if exists) ─
const themeBtn=document.getElementById('themeBtn');
const themeModal=document.getElementById('themeModal');
if(themeBtn&&themeModal){
  themeBtn.addEventListener('click',()=>themeModal.classList.add('open'));
  themeModal.addEventListener('click',e=>{ if(e.target===themeModal) themeModal.classList.remove('open'); });
  document.querySelectorAll('.theme-opt').forEach(opt=>{
    opt.addEventListener('click',function(){
      const theme=this.dataset.theme;
      fetch('<?= SITE_URL ?>/api/save_setting.php',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({key:'theme',value:theme,'<?= CSRF_TOKEN_NAME ?>':'<?= csrf_token() ?>'})
      }).then(()=>{ themeModal.classList.remove('open'); location.reload(); });
    });
  });
}

// ─ 14. Sidebar toggle ─
const sidebar=document.getElementById('sidebar');
const overlay=document.getElementById('sidebarOverlay');
const hamburger=document.getElementById('hamburger');
const sidebarToggleBtn=document.getElementById('sidebarToggleBtn');
function toggleSidebar(){sidebar?.classList.toggle('open');overlay?.classList.toggle('show');}
hamburger?.addEventListener('click',toggleSidebar);
overlay?.addEventListener('click',toggleSidebar);
sidebarToggleBtn?.addEventListener('click',()=>{
  document.querySelector('.sidebar')?.classList.toggle('collapsed');
  document.querySelector('.main')?.classList.toggle('sidebar-collapsed');
});

// ─ 15. Mobile keyboard fix ─
if(/Android/i.test(navigator.userAgent)){
  window.addEventListener('resize',()=>{
    if(document.activeElement?.tagName==='INPUT'){
      setTimeout(()=>document.activeElement.scrollIntoView({behavior:'smooth',block:'center'}),100);
    }
  });
}

})();
</script>

<div class="toast" id="globalToast"></div>
</body>
</html>
