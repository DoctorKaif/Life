<?php
require_once '../includes/config.php';
requireLogin();
$db=getDB();$uid=(int)$_SESSION['user_id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
    $a=$_POST['action']??'';
    if($a==='add'){$t=clean($_POST['quote_text']??'');$au=clean($_POST['author']??'Anonymous');$cat=clean($_POST['category']??'medical');if($t){$stmt=$db->prepare("INSERT INTO quotes(quote_text,author,category) VALUES(?,?,?)");$stmt->bind_param('sss',$t,$au,$cat);$stmt->execute();}}
    elseif($a==='delete'){$id=(int)($_POST['id']??0);$db->query("DELETE FROM quotes WHERE id=$id");}
    header('Location: motivation.php');exit;
}
$total=$db->query("SELECT COUNT(*) as c FROM quotes WHERE is_active=1")->fetch_assoc()['c']??0;
$offset=$total>0?(($uid+floor(date('H')/6))%$total):0;
$featured=$db->query("SELECT * FROM quotes WHERE is_active=1 LIMIT 1 OFFSET $offset")->fetch_assoc();
$quotes=$db->query("SELECT * FROM quotes WHERE is_active=1 ORDER BY id DESC");
$pageTitle='Motivation';$activePage='motivation';
include '../includes/header.php';
?>
<div class="page-content" style="max-width:700px;margin:0 auto;">
<div style="background:linear-gradient(135deg,var(--primary)15,var(--secondary)15);border:1px solid var(--primary)33;border-radius:20px;padding:40px;text-align:center;margin-bottom:24px;position:relative;overflow:hidden;">
<div style="position:absolute;right:-20px;top:-20px;width:120px;height:120px;border-radius:50%;background:radial-gradient(circle,var(--primary)15,transparent);"></div>
<div style="font-size:48px;margin-bottom:14px;animation:float 3s ease-in-out infinite;">⚕️</div>
<p style="font-family:'Orbitron',monospace;font-size:clamp(14px,2.5vw,18px);color:var(--text);line-height:1.7;margin-bottom:12px;">"<?=clean($featured['quote_text']??'Keep pushing!')?>"</p>
<p style="color:var(--muted);font-size:13px;">— <?=clean($featured['author']??'Anonymous')?></p>
<p style="color:var(--muted);font-size:10px;margin-top:8px;text-transform:uppercase;letter-spacing:1px;">🔄 Updates every 6 hours</p>
</div>
<div style="display:grid;grid-template-columns:1fr 300px;gap:20px;">
<div class="card">
<div class="card-title" style="margin-bottom:14px;">📖 All Quotes (<?=$total?>)</div>
<?php if($quotes&&$quotes->num_rows>0):while($q=$quotes->fetch_assoc()):
$cols=['fmge'=>'var(--accent)','medical'=>'var(--primary)','general'=>'var(--success)'];
$col=$cols[$q['category']]??'var(--primary)';?>
<div style="padding:12px 14px;border-left:3px solid <?=$col?>;border-radius:0 8px 8px 0;margin-bottom:8px;background:<?=$col?>06;display:flex;gap:10px;align-items:flex-start;">
<div style="flex:1;"><p style="font-size:12px;color:var(--text);line-height:1.5;margin-bottom:4px;">"<?=clean($q['quote_text'])?>"</p><div style="display:flex;gap:8px;"><span style="font-size:10px;color:var(--muted);">— <?=clean($q['author'])?></span><span style="font-size:9px;padding:1px 6px;border-radius:6px;background:<?=$col?>15;color:<?=$col?>;font-weight:700;"><?=$q['category']?></span></div></div>
<form method="POST"><input type="hidden" name="action" value="delete"/><input type="hidden" name="id" value="<?=$q['id']?>"/><button type="submit" style="background:none;border:none;cursor:pointer;opacity:.4;font-size:13px;transition:opacity .2s;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=.4">🗑️</button></form>
</div>
<?php endwhile;else:?><p style="color:var(--muted);font-size:13px;">No quotes yet.</p><?php endif;?>
</div>
<div class="card">
<div class="card-title" style="margin-bottom:14px;">➕ Add Quote</div>
<form method="POST"><input type="hidden" name="action" value="add"/>
<div class="form-group"><label>Quote *</label><textarea name="quote_text" class="form-control" rows="4" required placeholder="Your motivational quote..."></textarea></div>
<div class="form-group"><label>Author</label><input type="text" name="author" class="form-control" placeholder="e.g. Dr. Kalam"/></div>
<div class="form-group"><label>Category</label><select name="category" class="form-control"><option value="medical">Medical</option><option value="fmge">FMGE</option><option value="general">General</option></select></div>
<button type="submit" class="btn btn-primary" style="width:100%;">💾 Add Quote</button>
</form>
</div>
</div>
</div>
<?php include '../includes/footer.php';?>
