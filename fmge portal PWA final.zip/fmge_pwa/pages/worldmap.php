<?php
require_once '../includes/config.php';
requireLogin();
$db = getDB();
$uid = (int)$_SESSION['user_id'];

updateWorldMap($uid);

$islands = $db->query("SELECT * FROM world_map_progress WHERE user_id=$uid ORDER BY island_name ASC");
$islandList = []; if ($islands) while ($r=$islands->fetch_assoc()) $islandList[] = $r;

// Subject colors map
$islandColors = [
    'Anatomy'=>'#ef4444','Physiology'=>'#f97316','Biochemistry'=>'#eab308',
    'Pathology'=>'#10b981','Pharmacology'=>'#06b6d4','Microbiology'=>'#3b82f6',
    'Surgery'=>'#8b5cf6','Medicine'=>'#ec4899','OBG'=>'#f43f5e','PSM'=>'#00d4ff',
    'Ophthalmology'=>'#84cc16','ENT'=>'#fb923c','Pediatrics'=>'#a78bfa','Orthopedics'=>'#78716c',
];

$pageTitle = 'World Map';
$activePage = 'worldmap';
include '../includes/header.php';
?>
<div class="page-content">

<div style="text-align:center;margin-bottom:24px;">
  <div style="font-size:48px;margin-bottom:10px;animation:float 3s ease-in-out infinite;">🌍</div>
  <h2 style="font-family:'Orbitron',monospace;font-size:20px;color:var(--primary);margin-bottom:6px;">STUDY WORLD MAP</h2>
  <p style="color:var(--muted);font-size:13px;">Each subject is an island. Study to unlock and conquer!</p>
</div>

<?php if (!empty($islandList)): ?>
<!-- Map Grid -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;margin-bottom:24px;">
  <?php foreach ($islandList as $island):
    $color = $islandColors[$island['island_name']] ?? '#00d4ff';
    $isUnlocked = $island['is_unlocked'];
    $pct = $island['progress_pct'];
  ?>
  <div style="text-align:center;padding:20px 14px;border-radius:16px;border:1px solid <?= $isUnlocked?$color.'44':'var(--border)' ?>;background:<?= $isUnlocked?$color.'08':'var(--card)' ?>;transition:all .3s;opacity:<?= $isUnlocked?'1':'.5' ?>;" <?= $isUnlocked?'onmouseover="this.style.transform=\'translateY(-4px)\';this.style.boxShadow=\'0 8px 24px '.$color.'22\'" onmouseout="this.style.transform=\'\';this.style.boxShadow=\'\'"':''; ?>>
    <div style="font-size:32px;margin-bottom:8px;"><?= $isUnlocked ? '🏝️' : '🔒' ?></div>
    <div style="font-size:13px;font-weight:700;color:<?= $isUnlocked?$color:'var(--muted)' ?>;margin-bottom:6px;"><?= clean($island['island_name']) ?></div>
    <?php if ($isUnlocked): ?>
    <div class="prog-track" style="margin-bottom:4px;"><div class="prog-fill" style="width:<?= $pct ?>%;background:<?= $color ?>;"></div></div>
    <div style="font-size:10px;color:var(--muted);"><?= $pct ?>% explored</div>
    <?php else: ?>
    <div style="font-size:10px;color:var(--muted);">Add subject to unlock</div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>
<?php else: ?>
<div style="text-align:center;padding:48px;color:var(--muted);">
  <div style="font-size:48px;margin-bottom:12px;">🗺️</div>
  <div style="font-size:15px;font-weight:700;margin-bottom:8px;">Your world is empty!</div>
  <div style="font-size:13px;margin-bottom:16px;">Add subjects in Roadmap to unlock islands</div>
  <a href="roadmap.php" class="btn btn-primary">Go to Roadmap →</a>
</div>
<?php endif; ?>

<!-- Legend -->
<div class="card">
  <div class="card-title" style="margin-bottom:12px;">🗺️ Map Legend</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;">
    <?php foreach ([['🔒','Locked Island','Subject not added yet'],['🏝️','Unlocked Island','Subject added and in progress'],['💯','Conquered','100% topics completed']] as $l): ?>
    <div style="display:flex;align-items:center;gap:10px;padding:10px;background:var(--bg2);border-radius:8px;">
      <span style="font-size:20px;"><?= $l[0] ?></span>
      <div><div style="font-size:12px;font-weight:700;"><?= $l[1] ?></div><div style="font-size:10px;color:var(--muted);"><?= $l[2] ?></div></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

</div>
<?php include '../includes/footer.php'; ?>
