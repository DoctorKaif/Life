<?php
require_once '../includes/config.php';
requireLogin();
header('Content-Type: application/json');

$d = json_decode(file_get_contents('php://input'), true) ?? [];
if(!csrf_verify($d[CSRF_TOKEN_NAME]??'')) { http_response_code(403); die(json_encode(['success'=>false])); }

$rating = min(5, max(1, cleanInt($d['rating'] ?? 0)));
$uid = (int)$_SESSION['user_id'];
$today = date('Y-m-d');

$db = getDB();
$stmt = $db->prepare("INSERT INTO daily_ratings (user_id,rating,rating_date) VALUES (?,?,?) ON DUPLICATE KEY UPDATE rating=?");
$stmt->bind_param('isis',$uid,$rating,$today,$rating);
if($stmt->execute()){
    addXP($uid,15,5);
    echo json_encode(['success'=>true]);
} else {
    echo json_encode(['success'=>false]);
}
