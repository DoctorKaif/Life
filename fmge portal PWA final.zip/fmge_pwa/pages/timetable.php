<?php
require_once '../includes/config.php';
requireLogin();
$db = getDB(); $uid = (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $a = $_POST['action'] ?? '';
    if ($a === 'add') {
        $s = clean($_POST['slot_start'] ?? ''); $e = clean($_POST['slot_end'] ?? '');
        $sub = clean($_POST['subject'] ?? ''); $act = clean($_POST['activity'] ?? '');
        $col = clean($_POST['color'] ?? '#38b6cc');
        if ($s && $e && $sub) {
            $stmt = $db->prepare("INSERT INTO timetable (user_id,slot_start,slot_end,subject,activity,color) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param('isssss', $uid, $s, $e, $sub, $act, $col);
            $stmt->execute();
        }
    } elseif ($a === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $db->query("DELETE FROM timetable WHERE id=$id AND user_id=$uid");
    }
    header('Location: timetable.php'); exit;
}

$slots = $db->query("SELECT * FROM timetable WHERE user_id=$uid ORDER BY slot_start ASC");
$slotList = []; if ($slots) while ($r=$slots->fetch_assoc()) $slotList[]=$r;
$now = date('H:i:s');

$pageTitle = 'Timetable'; $activePage = 'timetable';
include '../includes/header.php';
?>
<div class="page-content">
<div style="display:grid;grid-template-columns:1fr 320px;gap:20px;">

  <!-- Timeline View -->
  <div class="card anim-fade-up">
    <div class="card-hdr">
      <div><div class="card-ttl">📅 Today's Schedule</div><div class="card-sub"><?= date('l, d M Y') ?></div></div>
      <button class="card-action" onclick="document.getElementById('addForm').classList.toggle('open-form')">＋ Add Slot</button>
    </div>

    <?php if (!empty($slotList)):
      // Group by subject for legend
      $subjects = array_unique(array_column($slotList, 'subject'));
    ?>
    <!-- Legend chips -->
    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px;">
      <?php foreach($slotList as $s): ?>
      <span style="padding:3px 10px;border-radius:20px;font-size:10px;font-weight:700;background:<?= clean($s['color']) ?>18;color:<?= clean($s['color']) ?>;border:1px solid <?= clean($s['color']) ?>33;"><?= clean($s['subject']) ?></span>
      <?php endforeach; ?>
    </div>

    <!-- Slots -->
    <?php foreach($slotList as $s):
      $isNow  = $s['slot_start'] <= $now && $s['slot_end'] >= $now;
      $isPast = $s['slot_end'] < $now;
    ?>
    <div style="display:flex;align-items:center;gap:12px;padding:11px 14px;border-radius:11px;margin-bottom:6px;background:<?= $isNow?'rgba(56,182,204,.06)':'rgba(255,255,255,.02)' ?>;border:1px solid <?= $isNow?'rgba(56,182,204,.18)':'var(--border)' ?>;opacity:<?= $isPast?.5:1 ?>;transition:all .2s;cursor:<?= $isNow?'pointer':'default' ?>;" <?= $isNow?"onclick=\"startFloatingTimer('".clean($s['subject'])."')\"":''; ?>>
      <div style="width:8px;height:8px;border-radius:50%;background:<?= clean($s['color']) ?>;flex-shrink:0;<?= $isNow?'animation:dotPulse 1.5s infinite;':'' ?>"></div>
      <div style="width:100px;flex-shrink:0;">
        <div style="font-size:11px;font-weight:600;font-family:'JetBrains Mono',monospace;color:<?= $isNow?'var(--primary)':'var(--muted)' ?>;"><?= date('h:i A',strtotime($s['slot_start'])) ?></div>
        <div style="font-size:9px;color:var(--muted2);">→ <?= date('h:i A',strtotime($s['slot_end'])) ?></div>
      </div>
      <div style="flex:1;">
        <div style="font-size:13px;font-weight:<?= $isNow?'700':'500' ?>;color:<?= $isNow?'var(--primary)':'var(--text)' ?>;"><?= clean($s['subject']) ?></div>
        <?php if($s['activity']): ?><div style="font-size:10px;color:var(--muted);"><?= clean($s['activity']) ?></div><?php endif; ?>
      </div>
      <?php if($isNow): ?>
      <span style="font-size:9px;background:var(--primary);color:#000;padding:3px 8px;border-radius:5px;font-weight:800;flex-shrink:0;">▶ NOW</span>
      <?php endif; ?>
      <form method="POST" style="flex-shrink:0;">
        <input type="hidden" name="action" value="delete"/>
        <input type="hidden" name="id" value="<?= $s['id'] ?>"/>
        <button type="submit" style="background:none;border:none;cursor:pointer;font-size:14px;color:var(--muted);opacity:.4;transition:opacity .2s;padding:4px;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=.4">✕</button>
      </form>
    </div>
    <?php endforeach; ?>
    <?php else: ?>
    <div style="text-align:center;padding:40px;color:var(--muted);">
      <div style="font-size:40px;margin-bottom:12px;">📅</div>
      <div style="font-size:14px;font-weight:600;">No schedule yet</div>
      <div style="font-size:12px;margin-top:4px;">Add your first study slot →</div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Add Form -->
  <div>
    <div class="card anim-fade-up" data-delay="1" id="addForm">
      <div class="card-ttl" style="margin-bottom:16px;">➕ Add Study Slot</div>
      <form method="POST">
        <input type="hidden" name="action" value="add"/>
        <div class="form-group">
          <label>Subject *</label>
          <input type="text" name="subject" class="form-control" id="subjInput" placeholder="e.g. Anatomy" required/>
        </div>
        <div class="form-group">
          <label>Details</label>
          <input type="text" name="activity" class="form-control" placeholder="e.g. MCQ Practice"/>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Start *</label><input type="time" name="slot_start" class="form-control" required/></div>
          <div class="form-group"><label>End *</label><input type="time" name="slot_end" class="form-control" required/></div>
        </div>
        <div class="form-group">
          <label>Color</label>
          <input type="color" name="color" class="form-control" id="colInput" value="#38b6cc" style="height:42px;cursor:pointer;"/>
        </div>
        <button type="submit" class="btn btn-primary w-full">💾 Save Slot</button>
      </form>
    </div>

    <!-- Quick subject chips -->
    <div class="card anim-fade-up" data-delay="2" style="margin-top:14px;">
      <div class="card-ttl" style="margin-bottom:12px;">⚡ Quick Add</div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;">
        <?php foreach([
          ['Anatomy','#38b6cc'],['Physiology','#5b3fa0'],['Biochemistry','#c9922a'],
          ['Pathology','#c0384a'],['Pharmacology','#1a9e6e'],['Microbiology','#8b5cf6'],
          ['Surgery','#06b6d4'],['Medicine','#ec4899'],['OBG','#f43f5e'],
          ['PSM','#84cc16'],['MCQ Practice','#f59e0b'],['Revision','#64748b'],['Break','#2a3550']
        ] as [$n,$c]): ?>
        <button onclick="document.getElementById('subjInput').value='<?= $n ?>';document.getElementById('colInput').value='<?= $c ?>'" style="padding:4px 10px;border-radius:8px;border:1px solid <?= $c ?>44;background:<?= $c ?>12;color:<?= $c ?>;font-size:10px;font-weight:700;cursor:pointer;font-family:'Syne',sans-serif;transition:all .2s;" onmouseover="this.style.background='<?= $c ?>25'" onmouseout="this.style.background='<?= $c ?>12'"><?= $n ?></button>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

</div>
</div>
<?php include '../includes/footer.php'; ?>
