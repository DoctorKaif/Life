<?php
require_once '../includes/config.php';
requireLogin();
$db=getDB();$uid=(int)$_SESSION['user_id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
    $a=$_POST['action']??'';
    if($a==='save'){$title=clean($_POST['title']??'');$content=clean($_POST['content']??'');$mood=clean($_POST['mood']??'neutral');$date=clean($_POST['entry_date']??date('Y-m-d'));if($content){$stmt=$db->prepare("INSERT INTO diary_entries(user_id,title,content,mood,entry_date) VALUES(?,?,?,?,?)");$stmt->bind_param('issss',$uid,$title,$content,$mood,$date);$stmt->execute();}}
    elseif($a==='delete'){$id=(int)($_POST['id']??0);$db->query("DELETE FROM diary_entries WHERE id=$id AND user_id=$uid");}
    header('Location: diary.php');exit;
}
$entries=$db->query("SELECT * FROM diary_entries WHERE user_id=$uid ORDER BY entry_date DESC,created_at DESC");
$eList=[];if($entries)while($r=$entries->fetch_assoc())$eList[]=$r;
$moodEmoji=['happy'=>'😊','great'=>'🌟','neutral'=>'😐','tired'=>'😴','stressed'=>'😰','motivated'=>'🔥'];
$pageTitle='My Diary';$activePage='diary';
include '../includes/header.php';
?>
<div class="page-content">
<div style="display:grid;grid-template-columns:1fr 300px;gap:20px;">
<div>
<div class="card" style="margin-bottom:20px;">
<div class="card-title" style="margin-bottom:16px;">📔 New Entry</div>
<form method="POST"><input type="hidden" name="action" value="save"/>
<div class="form-row"><div class="form-group"><label>Title (optional)</label><input type="text" name="title" class="form-control" placeholder="Entry title..."/></div><div class="form-group"><label>Date</label><input type="date" name="entry_date" class="form-control" value="<?=date('Y-m-d')?>"/></div></div>
<div class="form-group"><label>Mood</label>
<select name="mood" class="form-control">
<option value="great">🌟 Great</option><option value="happy">😊 Happy</option><option value="motivated">🔥 Motivated</option><option value="neutral" selected>😐 Neutral</option><option value="tired">😴 Tired</option><option value="stressed">😰 Stressed</option>
</select></div>
<div class="form-group"><label>Your Thoughts *</label><textarea name="content" class="form-control" rows="6" required placeholder="How was your study session today? Any breakthroughs or struggles? Write freely..."></textarea></div>
<button type="submit" class="btn btn-primary">💾 Save Entry</button>
</form>
</div>
<div class="card">
<div class="card-title" style="margin-bottom:14px;">📖 Journal (<?=count($eList)?> entries)</div>
<?php if(!empty($eList)):foreach($eList as $e):$emoji=$moodEmoji[$e['mood']]??'😐';?>
<div style="padding:14px 16px;background:var(--bg2);border-radius:12px;margin-bottom:10px;border:1px solid var(--border);border-left:3px solid var(--primary);transition:all .2s;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderLeftColor='var(--primary)'">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;flex-wrap:wrap;gap:8px;">
<div style="display:flex;align-items:center;gap:8px;"><span style="font-size:20px;"><?=$emoji?></span><?php if($e['title']):?><span style="font-size:13px;font-weight:700;color:var(--text);"><?=clean($e['title'])?></span><?php endif;?></div>
<div style="display:flex;align-items:center;gap:8px;"><span style="font-size:10px;color:var(--muted);"><?=date('d M Y',strtotime($e['entry_date']))?></span><form method="POST"><input type="hidden" name="action" value="delete"/><input type="hidden" name="id" value="<?=$e['id']?>"/><button type="submit" style="background:none;border:none;cursor:pointer;font-size:12px;color:var(--muted);opacity:.5;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=.5">🗑️</button></form></div>
</div>
<p style="font-size:13px;color:var(--text);line-height:1.6;"><?=nl2br(clean($e['content']))?></p>
</div>
<?php endforeach;else:?><div style="text-align:center;padding:32px;color:var(--muted);"><div style="font-size:40px;margin-bottom:10px;">📔</div><div style="font-size:14px;font-weight:600;">No entries yet</div><div style="font-size:12px;margin-top:4px;">Write your first journal entry!</div></div><?php endif;?>
</div>
</div>
<div>
<div class="card" style="margin-bottom:14px;">
<div class="card-title" style="margin-bottom:12px;">😊 Mood Overview</div>
<?php foreach($moodEmoji as $m=>$em):$cnt=count(array_filter($eList,fn($e)=>$e['mood']===$m));if($cnt>0):?>
<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
<span style="font-size:16px;"><?=$em?></span><span style="font-size:12px;font-weight:600;flex:1;color:var(--text);"><?=ucfirst($m)?></span><span style="font-family:'Orbitron',monospace;font-size:12px;font-weight:700;color:var(--primary);"><?=$cnt?>x</span>
</div>
<?php endif;endforeach;if(empty($eList)):?><p style="color:var(--muted);font-size:12px;">Start writing to see mood stats!</p><?php endif;?>
</div>
<div class="card">
<div class="card-title" style="margin-bottom:10px;">🔒 Privacy</div>
<p style="font-size:12px;color:var(--muted);line-height:1.6;">Your diary is completely private. Only you can read your entries. Write freely without any worries.</p>
</div>
</div>
</div>
</div>
<?php include '../includes/footer.php';?>
