<?php
$user = getCurrentUser();
$uid  = (int)($_SESSION['user_id'] ?? 0);
$db   = getDB();
$theme = $user['theme'] ?? 'void';
$themeVars = getThemeVars($theme);
$themeData = getThemeData();
$isDark = ($themeData[$theme][3] ?? 'dark') === 'dark';
$notifCount = (int)($db->query("SELECT COUNT(*) as c FROM notifications WHERE user_id=$uid AND is_read=0")->fetch_assoc()['c'] ?? 0);
$rank = getMilitaryRank($user['level'] ?? 1);
$xpNeeded = xpForLevel($user['level'] ?? 1);
$xpPct = $xpNeeded > 0 ? min(100, round(($user['xp'] ?? 0) / $xpNeeded * 100)) : 0;
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?= $theme ?>">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
<meta name="apple-mobile-web-app-title" content="FMGE"/>
<meta name="mobile-web-app-capable" content="yes"/>
<meta name="theme-color" content="#03030a"/>
<link rel="manifest" href="<?= SITE_URL ?>/manifest.json"/>
<link rel="apple-touch-icon" href="<?= SITE_URL ?>/assets/icons/icon-152.png"/>
<meta name="theme-color" content="#03030a"/>
<title><?= clean($pageTitle ?? 'Dashboard') ?> — FMGE Portal</title>
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/style.css"/>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>:root{<?= $themeVars ?>}</style>
</head>
<body>

<!-- AMBIENT BACKGROUND -->
<div class="ambient" id="ambientBg">
  <?php if ($isDark): ?>
  <div class="amb-orb" style="width:600px;height:600px;background:rgba(<?= $isDark ? '56,10,80' : '200,220,255' ?>,.15);top:-200px;right:-150px;animation-duration:10s;"></div>
  <div class="amb-orb" style="width:500px;height:500px;background:rgba(<?= $isDark ? '10,30,60' : '180,240,200' ?>,.12);bottom:-150px;left:-100px;animation-duration:13s;animation-delay:3s;"></div>
  <div class="amb-orb" style="width:300px;height:300px;background:rgba(<?= $isDark ? '80,40,10' : '255,200,150' ?>,.08);top:40%;left:35%;animation-duration:8s;animation-delay:1.5s;"></div>
  <?php endif; ?>
</div>

<!-- SIDEBAR -->
<nav class="sidebar" id="sidebar">
  <a href="<?= SITE_URL ?>/dashboard.php" class="sidebar-logo">
    <div class="logo-icon">⚕️</div>
    <div class="logo-text">
      <h2>FMGE PORTAL</h2>
      <p>STUDY SMART. SCORE HIGH.</p>
    </div>
  </a>

  <a href="<?= SITE_URL ?>/pages/profile.php" class="sidebar-user">
    <div class="s-user-row">
      <div class="s-avatar">
        <?php if (!empty($user['avatar'])): ?>
        <img src="<?= SITE_URL ?>/uploads/avatars/<?= clean($user['avatar']) ?>" alt=""/>
        <?php else: ?>
        <?= strtoupper(substr($user['full_name'] ?? 'A', 0, 1)) ?>
        <?php endif; ?>
      </div>
      <div class="s-info">
        <h4><?= clean(explode(' ', $user['full_name'] ?? 'User')[0]) ?></h4>
        <p>Lv.<?= $user['level'] ?? 1 ?> · <?= clean($user['target_exam'] ?? 'FMGE') ?></p>
      </div>
      <div class="s-rank"><?= $rank[1] ?></div>
    </div>
    <div class="xp-bar-wrap">
      <div class="xp-labels">
        <span class="text-primary" style="font-size:9px;font-weight:700;"><?= $rank[0] ?></span>
        <span><?= $xpPct ?>%</span>
      </div>
      <div class="xp-track"><div class="xp-fill" style="width:<?= $xpPct ?>%"></div></div>
    </div>
    <div class="s-coins">
      <span style="color:var(--accent);font-weight:700;">🪙 <?= number_format($user['coins'] ?? 0) ?></span>
      <?php if (($user['streak_days'] ?? 0) > 0): ?>
      <span style="color:var(--muted);">·</span>
      <span style="color:#ef4444;font-weight:700;">🔥 <?= $user['streak_days'] ?>d</span>
      <?php endif; ?>
    </div>
  </a>

  <div class="nav-menu">
    <div class="nav-section">Main</div>
    <a href="<?= SITE_URL ?>/dashboard.php" class="nav-item <?= ($activePage??'')==='dashboard'?'active':'' ?>"><span class="nav-icon">⚡</span>Dashboard</a>

    <div class="nav-section">Study</div>
    <a href="<?= SITE_URL ?>/pages/timetable.php" class="nav-item <?= ($activePage??'')==='timetable'?'active':'' ?>"><span class="nav-icon">📅</span>Timetable</a>
    <a href="<?= SITE_URL ?>/pages/roadmap.php" class="nav-item <?= ($activePage??'')==='roadmap'?'active':'' ?>"><span class="nav-icon">🗺️</span>Roadmap</a>
    <a href="<?= SITE_URL ?>/pages/timer.php" class="nav-item <?= ($activePage??'')==='timer'?'active':'' ?>"><span class="nav-icon">🕯️</span>Study Timer</a>

    <div class="nav-section">Performance</div>
    <a href="<?= SITE_URL ?>/pages/performance.php" class="nav-item <?= ($activePage??'')==='performance'?'active':'' ?>"><span class="nav-icon">📊</span>Performance</a>
    <a href="<?= SITE_URL ?>/pages/leaderboard.php" class="nav-item <?= ($activePage??'')==='leaderboard'?'active':'' ?>"><span class="nav-icon">🏆</span>Leaderboard</a>
    <a href="<?= SITE_URL ?>/pages/store.php" class="nav-item <?= ($activePage??'')==='store'?'active':'' ?>"><span class="nav-icon">🛒</span>XP Store</a>

    <div class="nav-section">Community</div>
    <a href="<?= SITE_URL ?>/pages/community.php" class="nav-item <?= ($activePage??'')==='community'?'active':'' ?>"><span class="nav-icon">📸</span>Community</a>
    <a href="<?= SITE_URL ?>/pages/partners.php" class="nav-item <?= ($activePage??'')==='partners'?'active':'' ?>"><span class="nav-icon">🤝</span>Study Partners</a>
    <a href="<?= SITE_URL ?>/pages/clans.php" class="nav-item <?= ($activePage??'')==='clans'?'active':'' ?>"><span class="nav-icon">⚔️</span>Clans</a>
    <a href="<?= SITE_URL ?>/pages/motivation.php" class="nav-item <?= ($activePage??'')==='motivation'?'active':'' ?>"><span class="nav-icon">💬</span>Motivation</a>

    <div class="nav-section">Battle</div>
    <a href="<?= SITE_URL ?>/pages/villain.php" class="nav-item <?= ($activePage??'')==='villain'?'active':'' ?>"><span class="nav-icon">👹</span>Villain Battle</a>
    <a href="<?= SITE_URL ?>/pages/story.php" class="nav-item <?= ($activePage??'')==='story'?'active':'' ?>"><span class="nav-icon">📖</span>Story Mode</a>
    <a href="<?= SITE_URL ?>/pages/worldmap.php" class="nav-item <?= ($activePage??'')==='worldmap'?'active':'' ?>"><span class="nav-icon">🌍</span>World Map</a>

    <div class="nav-section">Account</div>
    <a href="<?= SITE_URL ?>/pages/profile.php" class="nav-item <?= ($activePage??'')==='profile'?'active':'' ?>"><span class="nav-icon">👤</span>Profile</a>
    <a href="<?= SITE_URL ?>/pages/diary.php" class="nav-item <?= ($activePage??'')==='diary'?'active':'' ?>"><span class="nav-icon">📔</span>My Diary</a>
    <a href="<?= SITE_URL ?>/pages/notifications.php" class="nav-item <?= ($activePage??'')==='notifications'?'active':'' ?>">
      <span class="nav-icon">🔔</span>Notifications
      <?php if ($notifCount > 0): ?><span class="nav-badge"><?= $notifCount ?></span><?php endif; ?>
    </a>
    <a href="<?= SITE_URL ?>/pages/settings.php" class="nav-item <?= ($activePage??'')==='settings'?'active':'' ?>"><span class="nav-icon">⚙️</span>Settings</a>
    <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
    <a href="<?= SITE_URL ?>/pages/admin.php" class="nav-item <?= ($activePage??'')==='admin'?'active':'' ?>"><span class="nav-icon">🛡️</span>Admin Panel</a>
    <?php endif; ?>
  </div>

  <div class="sidebar-footer">
    <a href="<?= SITE_URL ?>/logout.php" class="btn-logout">🚪 Sign Out</a>
  </div>
</nav>
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<!-- CANDLE FLOATING TIMER -->
<div class="floating-timer" id="floatingTimer">
  <div class="candle-wrap">
    <div class="candle-flame" id="candleFlame"></div>
    <div class="candle-wick"></div>
    <div class="candle-body" id="candleBody" style="height:100%"></div>
  </div>
  <div class="ft-info" onclick="location.href='<?= SITE_URL ?>/pages/timer.php'">
    <div class="ft-subject" id="ftSubject">STUDYING</div>
    <div class="ft-time" id="ftTime">00:00:00</div>
  </div>
  <button class="ft-stop" onclick="stopFloatingTimer()">■ STOP</button>
</div>

<!-- THEME MODAL -->
<div class="theme-modal" id="themeModal">
  <div class="theme-modal-inner">
    <h3>🎨 SELECT THEME</h3>
    <div class="theme-grid">
      <?php foreach (getThemeData() as $key => [$name, $color, $desc, $type]): ?>
      <div class="theme-opt <?= $theme===$key?'selected':'' ?>" onclick="setTheme('<?= $key ?>')" style="background:<?= $color ?>0d;border-color:<?= $theme===$key?$color:'var(--border)' ?>;">
        <div class="theme-dot" style="background:linear-gradient(135deg,<?= $color ?>,<?= $color ?>66);box-shadow:0 0 8px <?= $color ?>55;"></div>
        <div class="theme-name" style="color:<?= $color ?>"><?= $name ?></div>
        <div class="theme-desc"><?= $desc ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <button onclick="closeThemeModal()" class="btn btn-ghost w-full" style="margin-top:14px;">Close</button>
  </div>
</div>

<!-- MAIN WRAPPER -->
<div class="main page-wrap" id="mainContent">
  <div class="topbar">
    <div class="topbar-left">
      <button class="hamburger" onclick="toggleSidebar()">
        <svg viewBox="0 0 24 24"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
      </button>
      <div class="page-meta">
        <h1><?= clean($pageTitle ?? 'Dashboard') ?></h1>
        <p id="topDate"></p>
      </div>
    </div>
    <div class="topbar-right">
      <div class="top-clock" id="liveClock">12:00:00 AM</div>
      <div class="top-coins">🪙 <?= number_format($user['coins'] ?? 0) ?></div>
      <button class="icon-btn" onclick="location.href='<?= SITE_URL ?>/pages/notifications.php'" title="Notifications">
        🔔<?php if ($notifCount > 0): ?><span class="notif-dot"></span><?php endif; ?>
      </button>
      <button class="sidebar-toggle" onclick="toggleSidebarDesktop()" title="Toggle Sidebar">⊞</button>
      <button class="theme-btn" onclick="openThemeModal()">🎨 Theme</button>
    </div>
  </div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<!-- MOBILE BOTTOM NAV -->
<div class="mobile-nav">
  <div class="mobile-nav-items">
    <a href="<?= SITE_URL ?>/dashboard.php" class="mobile-nav-item <?= ($activePage??'')==='dashboard'?'active':'' ?>"><span>⚡</span><span>Home</span></a>
    <a href="<?= SITE_URL ?>/pages/timer.php" class="mobile-nav-item <?= ($activePage??'')==='timer'?'active':'' ?>"><span>🕯️</span><span>Timer</span></a>
    <a href="<?= SITE_URL ?>/pages/performance.php" class="mobile-nav-item <?= ($activePage??'')==='performance'?'active':'' ?>"><span>📊</span><span>Stats</span></a>
    <a href="<?= SITE_URL ?>/pages/community.php" class="mobile-nav-item <?= ($activePage??'')==='community'?'active':'' ?>"><span>📸</span><span>Feed</span></a>
    <a href="<?= SITE_URL ?>/pages/profile.php" class="mobile-nav-item <?= ($activePage??'')==='profile'?'active':'' ?>"><span>👤</span><span>Profile</span></a>
  </div>
</div>

<script>
// ─── 12-HOUR CLOCK ───
function updateClock(){
  const n=new Date();
  let h=n.getHours(),m=n.getMinutes(),s=n.getSeconds();
  const ap=h>=12?'PM':'AM'; h=h%12||12;
  const el=document.getElementById('liveClock');
  if(el) el.textContent=pad(h)+':'+pad(m)+':'+pad(s)+' '+ap;
  const de=document.getElementById('topDate');
  if(de) de.textContent=n.toLocaleDateString('en-US',{weekday:'short',day:'numeric',month:'short',year:'numeric'});
}
function pad(n){return String(n).padStart(2,'0');}
updateClock(); setInterval(updateClock,1000);

// ── SERVICE WORKER ──
if('serviceWorker' in navigator){
  navigator.serviceWorker.register('<?= SITE_URL ?>/sw.js',{scope:'/'}).catch(()=>{});
}
function toggleSidebar(){
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').classList.toggle('show');
}
function closeSidebar(){
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('show');
}
let sidebarHidden=false;
function toggleSidebarDesktop(){
  sidebarHidden=!sidebarHidden;
  const sb=document.getElementById('sidebar');
  const mc=document.getElementById('mainContent');
  if(sidebarHidden){sb.style.transform='translateX(-100%)';mc.style.marginLeft='0';}
  else{sb.style.transform='';mc.style.marginLeft='';}
}

// ─── THEME ───
function openThemeModal(){ document.getElementById('themeModal').classList.add('open'); }
function closeThemeModal(){ document.getElementById('themeModal').classList.remove('open'); }
function setTheme(t){
  fetch('<?= SITE_URL ?>/api/save_setting.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:'theme',value:t})})
  .then(r=>r.json()).then(d=>{
    if(d.success){ showToast('Theme changed! ✨'); setTimeout(()=>location.reload(),600); }
    else showToast('Failed ⚠️','error');
  }).catch(()=>showToast('Error ⚠️','error'));
}

// ─── TOAST ───
function showToast(msg,type='success'){
  const t=document.getElementById('toast');
  t.textContent=msg;
  t.style.borderColor=type==='error'?'var(--danger)':'var(--primary)';
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),3000);
}

// ─── CANDLE FLOATING TIMER ───
let ftInterval=null,ftSeconds=0,ftRunning=false,ftTotalSeconds=0;

function startFloatingTimer(subject,totalMins){
  if(ftRunning) return;
  ftRunning=true; ftSeconds=0;
  ftTotalSeconds=totalMins?totalMins*60:0;
  document.getElementById('ftSubject').textContent=(subject||'STUDYING').toUpperCase().substring(0,14);
  document.getElementById('floatingTimer').classList.add('active');
  document.getElementById('candleFlame').style.display='block';
  document.getElementById('candleBody').style.height='100%';
  sessionStorage.setItem('ft_running','1');
  sessionStorage.setItem('ft_subject',subject||'Study');
  sessionStorage.setItem('ft_start',Date.now());
  sessionStorage.setItem('ft_total',ftTotalSeconds);
  ftInterval=setInterval(_tickTimer,1000);
}

function _tickTimer(){
  ftSeconds++;
  const h=Math.floor(ftSeconds/3600),m=Math.floor((ftSeconds%3600)/60),s=ftSeconds%60;
  document.getElementById('ftTime').textContent=(h>0?pad(h)+':':'')+pad(m)+':'+pad(s);
  if(ftTotalSeconds>0){
    const pct=Math.max(2,100-Math.round(ftSeconds/ftTotalSeconds*100));
    document.getElementById('candleBody').style.height=pct+'%';
    if(ftSeconds>=ftTotalSeconds){ document.getElementById('candleFlame').style.display='none'; clearInterval(ftInterval); showToast('Session complete! 🕯️'); }
  }
}

function stopFloatingTimer(){
  clearInterval(ftInterval); ftRunning=false;
  const mins=Math.floor(ftSeconds/60);
  const sub=document.getElementById('ftSubject').textContent;
  document.getElementById('floatingTimer').classList.remove('active');
  document.getElementById('candleFlame').style.display='none';
  sessionStorage.removeItem('ft_running'); sessionStorage.removeItem('ft_subject');
  sessionStorage.removeItem('ft_start'); sessionStorage.removeItem('ft_total');
  if(mins>0){
    fetch('<?= SITE_URL ?>/api/save_session.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({subject:sub,duration:mins})})
    .then(r=>r.json()).then(d=>{if(d.success) showToast(pad(Math.floor(mins/60))+':'+pad(mins%60)+' saved! +XP 🕯️');});
  }
  ftSeconds=0;
}

// Restore timer on page load
(function(){
  if(sessionStorage.getItem('ft_running')==='1'){
    const start=parseInt(sessionStorage.getItem('ft_start')||0);
    const elapsed=Math.floor((Date.now()-start)/1000);
    const sub=sessionStorage.getItem('ft_subject')||'Study';
    const total=parseInt(sessionStorage.getItem('ft_total')||0);
    ftRunning=true; ftSeconds=elapsed; ftTotalSeconds=total;
    document.getElementById('ftSubject').textContent=sub.toUpperCase().substring(0,14);
    document.getElementById('floatingTimer').classList.add('active');
    document.getElementById('candleFlame').style.display='block';
    if(total>0){const pct=Math.max(2,100-Math.round(elapsed/total*100));document.getElementById('candleBody').style.height=pct+'%';}
    ftInterval=setInterval(_tickTimer,1000);
  }
})();

// ─── LOAD ANIMATIONS ───
window.addEventListener('load',()=>{
  // Animate progress bars
  document.querySelectorAll('.prog-fill[data-w]').forEach(el=>{
    const w=el.getAttribute('data-w'); el.style.width='0';
    requestAnimationFrame(()=>requestAnimationFrame(()=>el.style.width=w));
  });
  // Count-up numbers
  document.querySelectorAll('[data-count]').forEach(el=>{
    const target=parseInt(el.getAttribute('data-count'));
    let cur=0; const step=Math.max(1,Math.ceil(target/50));
    const tmr=setInterval(()=>{cur=Math.min(cur+step,target);el.textContent=cur.toLocaleString();if(cur>=target)clearInterval(tmr);},30);
  });
  // Staggered fade-up
  document.querySelectorAll('.anim-fade-up').forEach((el,i)=>{
    el.style.animationDelay=(i*0.06)+'s';
  });
});
</script>
