<?php
require_once '../includes/config.php';
requireLogin();
$db = getDB();
$uid = (int)$_SESSION['user_id'];
$user = getCurrentUser();
$msg = '';
$msgType = 'success';

// Store items
$storeItems = [
    ['id'=>'streak_shield',  'name'=>'Streak Shield',    'desc'=>'Miss 1 day without breaking streak!', 'price'=>150, 'icon'=>'🛡️', 'cat'=>'power'],
    ['id'=>'xp_boost',       'name'=>'XP Booster 24h',   'desc'=>'Double XP for 24 hours!',             'price'=>300, 'icon'=>'⚡', 'cat'=>'power'],
    ['id'=>'frame_gold',     'name'=>'Gold Profile Frame','desc'=>'Shiny gold border for your avatar',   'price'=>200, 'icon'=>'🥇', 'cat'=>'cosmetic'],
    ['id'=>'frame_neon',     'name'=>'Neon Frame',        'desc'=>'Electric neon avatar border',         'price'=>250, 'icon'=>'💫', 'cat'=>'cosmetic'],
    ['id'=>'title_slayer',   'name'=>'Title: MCQ Slayer', 'desc'=>'Show your MCQ mastery!',              'price'=>250, 'icon'=>'🎯', 'cat'=>'title'],
    ['id'=>'title_grinder',  'name'=>'Title: The Grinder','desc'=>'For those who never stop!',           'price'=>200, 'icon'=>'💪', 'cat'=>'title'],
    ['id'=>'title_legend',   'name'=>'Title: Legend',     'desc'=>'Reserved for true legends',           'price'=>500, 'icon'=>'👑', 'cat'=>'title'],
    ['id'=>'mystery_box',    'name'=>'Mystery Box',        'desc'=>'Random reward: 50-500 coins + XP!',  'price'=>100, 'icon'=>'🎁', 'cat'=>'special'],
    ['id'=>'double_coins',   'name'=>'Coin Multiplier',   'desc'=>'Earn 2x coins for next 5 sessions',  'price'=>400, 'icon'=>'🪙', 'cat'=>'power'],
    ['id'=>'theme_unlock',   'name'=>'Premium Theme Pack','desc'=>'Unlock all 15 themes forever!',       'price'=>800, 'icon'=>'🎨', 'cat'=>'cosmetic'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemId = clean($_POST['item_id'] ?? '');
    $item = null;
    foreach ($storeItems as $si) { if ($si['id'] === $itemId) { $item = $si; break; } }
    
    if ($item && $user['coins'] >= $item['price']) {
        // Deduct coins
        $db->query("UPDATE users SET coins=coins-{$item['price']} WHERE id=$uid");
        
        // Apply effect
        if ($itemId === 'mystery_box') {
            $reward = rand(50, 500);
            $xpReward = rand(50, 200);
            addXP($uid, $xpReward, $reward);
            $msg = "Mystery Box opened! You got +$reward coins and +$xpReward XP! 🎁";
        } elseif ($itemId === 'xp_boost') {
            addNotification($uid, "⚡ XP Booster active! Double XP for 24 hours!", 'boost');
            $msg = "XP Booster activated! Double XP for 24 hours! ⚡";
        } elseif ($itemId === 'streak_shield') {
            addNotification($uid, "🛡️ Streak Shield active! Your streak is protected!", 'shield');
            $msg = "Streak Shield activated! 🛡️";
        } else {
            $msg = "'{$item['name']}' purchased! 🎉";
        }
        addNotification($uid, "🛒 Purchased: {$item['name']} for {$item['price']} coins", 'store');
        // Refresh user coins
        $user = getCurrentUser();
        $msgType = 'success';
    } elseif ($item) {
        $msg = "Not enough coins! You need {$item['price']} coins but have ".($user['coins'] ?? 0).".";
        $msgType = 'danger';
    }
}

$pageTitle = 'XP Store';
$activePage = 'store';
include '../includes/header.php';
?>
<div class="page-content">

<!-- Header -->
<div style="background:linear-gradient(135deg,rgba(245,158,11,.1),rgba(0,212,255,.05));border:1px solid rgba(245,158,11,.3);border-radius:18px;padding:22px 26px;margin-bottom:24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
  <div>
    <h2 style="font-family:'Orbitron',monospace;font-size:20px;color:var(--accent);margin-bottom:4px;">🛒 XP STORE</h2>
    <p style="font-size:13px;color:var(--muted);">Spend your coins on powerful upgrades!</p>
  </div>
  <div style="text-align:center;background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.3);border-radius:14px;padding:12px 24px;">
    <div style="font-family:'Orbitron',monospace;font-size:28px;font-weight:900;color:var(--accent);"><?= number_format($user['coins'] ?? 0) ?></div>
    <div style="font-size:11px;color:var(--muted);text-transform:uppercase;">Your Coins</div>
  </div>
</div>

<?php if ($msg): ?>
<div style="background:<?= $msgType==='success'?'rgba(16,185,129,.1)':'rgba(244,63,94,.1)' ?>;border:1px solid <?= $msgType==='success'?'rgba(16,185,129,.3)':'rgba(244,63,94,.3)' ?>;border-radius:10px;padding:12px 16px;margin-bottom:20px;font-size:14px;font-weight:600;color:<?= $msgType==='success'?'var(--success)':'var(--danger)' ?>;"><?= $msg ?></div>
<?php endif; ?>

<!-- Category Tabs -->
<div style="display:flex;gap:6px;margin-bottom:20px;flex-wrap:wrap;">
  <?php foreach([['all','⭐ All'],['power','⚡ Power-Ups'],['cosmetic','🎨 Cosmetic'],['title','🏷️ Titles'],['special','🎁 Special']] as [$cat,$label]): ?>
  <button onclick="filterStore('<?= $cat ?>')" id="cat-<?= $cat ?>" style="padding:7px 14px;border-radius:20px;border:1px solid var(--border);background:<?= $cat==='all'?'var(--primary)':'var(--bg2)' ?>;color:<?= $cat==='all'?'#000':'var(--muted)' ?>;font-size:12px;font-weight:700;cursor:pointer;font-family:'Inter',sans-serif;transition:all .2s;"><?= $label ?></button>
  <?php endforeach; ?>
</div>

<!-- Store Grid -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;">
  <?php foreach ($storeItems as $item): ?>
  <div class="store-item card" data-cat="<?= $item['cat'] ?>" style="transition:all .25s;">
    <div style="text-align:center;padding:12px 0 16px;">
      <div style="font-size:40px;margin-bottom:10px;animation:float 3s ease-in-out infinite;"><?= $item['icon'] ?></div>
      <h3 style="font-size:14px;font-weight:700;color:var(--text);margin-bottom:4px;"><?= $item['name'] ?></h3>
      <p style="font-size:12px;color:var(--muted);margin-bottom:14px;line-height:1.4;"><?= $item['desc'] ?></p>
      <div style="font-family:'Orbitron',monospace;font-size:18px;font-weight:900;color:var(--accent);margin-bottom:14px;">🪙 <?= number_format($item['price']) ?></div>
      <form method="POST">
        <input type="hidden" name="item_id" value="<?= $item['id'] ?>"/>
        <button type="submit" class="btn btn-primary btn-sm" style="width:100%;<?= ($user['coins'] ?? 0) < $item['price'] ? 'opacity:.5;cursor:not-allowed;' : '' ?>" <?= ($user['coins'] ?? 0) < $item['price'] ? 'disabled' : '' ?>>
          <?= ($user['coins'] ?? 0) >= $item['price'] ? '🛒 Buy Now' : '🔒 Not Enough' ?>
        </button>
      </form>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- How to Earn Coins -->
<div class="card" style="margin-top:24px;">
  <div class="card-title" style="margin-bottom:14px;">🪙 How to Earn Coins</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;">
    <?php foreach([['⏱️','Study 1 minute','= 1 coin'],['✅','Correct MCQ','= 0.5 coins'],['🔥','Daily Streak','= day × 2 coins'],['📅','Daily Login','= 10 coins'],['⭐','5-Star Rating','= 15 coins'],['📝','Community Post','= 5 coins'],['🎖️','Earn Badge','= 10-300 coins'],['⬆️','Level Up','= 50 coins']] as $e): ?>
    <div style="display:flex;align-items:center;gap:10px;padding:10px;background:var(--bg2);border-radius:10px;">
      <span style="font-size:18px;"><?= $e[0] ?></span>
      <div><div style="font-size:12px;font-weight:700;"><?= $e[1] ?></div><div style="font-size:11px;color:var(--accent);font-weight:700;"><?= $e[2] ?></div></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

</div>
<script>
function filterStore(cat){
  document.querySelectorAll('.store-item').forEach(el=>{
    el.style.display=(cat==='all'||el.dataset.cat===cat)?'block':'none';
  });
  document.querySelectorAll('[id^="cat-"]').forEach(btn=>{
    const isSel=btn.id==='cat-'+cat;
    btn.style.background=isSel?'var(--primary)':'var(--bg2)';
    btn.style.color=isSel?'#000':'var(--muted)';
    btn.style.borderColor=isSel?'var(--primary)':'var(--border)';
  });
}
// Hover effects
document.querySelectorAll('.store-item').forEach(el=>{
  el.addEventListener('mouseover',()=>{el.style.transform='translateY(-4px)';el.style.boxShadow='0 12px 32px rgba(0,0,0,.2)';});
  el.addEventListener('mouseout',()=>{el.style.transform='';el.style.boxShadow='';});
});
</script>
<?php include '../includes/footer.php'; ?>
