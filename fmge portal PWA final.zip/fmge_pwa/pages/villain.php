<?php
require_once '../includes/config.php';
requireLogin();
$db = getDB();
$uid = (int)$_SESSION['user_id'];
$user = getCurrentUser();

$villainHP = getVillainHP($uid);
$dealt = getVillainDealt($uid);
$hpPct = min(100, round($dealt / max(1,$villainHP) * 100));
$remaining = max(0, $villainHP - $dealt);
$isDarkSide = ($user['dark_side_days'] ?? 0) >= 3;

// Villain stages
$villainStages = [
    ['name' => 'Laziness Demon',     'emoji' => '😈', 'color' => '#6b7280', 'min_hp' => 0,    'desc' => 'The weakest form. Defeat it with daily study!'],
    ['name' => 'Procrastination God','emoji' => '👹', 'color' => '#f97316', 'min_hp' => 2000, 'desc' => 'Growing stronger. Keep pushing!'],
    ['name' => 'Forgetting Dragon',  'emoji' => '🐉', 'color' => '#ef4444', 'min_hp' => 5000, 'desc' => 'Revision is your weapon!'],
    ['name' => 'FMGE Dark Lord',     'emoji' => '💀', 'color' => '#8b5cf6', 'min_hp' => 10000,'desc' => 'The final boss. Only legends defeat him!'],
];

$currentStage = $villainStages[0];
foreach ($villainStages as $stage) {
    if ($villainHP >= $stage['min_hp']) $currentStage = $stage;
}

// Today's damage
$today = date('Y-m-d');
$todayStudy = (int)($db->query("SELECT SUM(duration_minutes) as t FROM study_sessions WHERE user_id=$uid AND session_date='$today'")->fetch_assoc()['t'] ?? 0);
$todayMcq = (int)($db->query("SELECT SUM(correct) as t FROM mcq_records WHERE user_id=$uid AND record_date='$today'")->fetch_assoc()['t'] ?? 0);
$todayDamage = $todayStudy * 2 + $todayMcq * 5;

// Battle log (last 7 days)
$battleLog = $db->query("SELECT session_date, SUM(duration_minutes) as mins FROM study_sessions WHERE user_id=$uid AND session_date>=DATE_SUB('$today',INTERVAL 7 DAY) GROUP BY session_date ORDER BY session_date DESC");

$pageTitle = 'Villain Battle';
$activePage = 'villain';
include '../includes/header.php';
?>
<div class="page-content">

<!-- Dark Side Warning -->
<?php if ($isDarkSide): ?>
<div style="background:linear-gradient(135deg,rgba(139,0,0,.3),rgba(80,0,80,.3));border:1px solid rgba(255,0,0,.4);border-radius:16px;padding:16px 20px;margin-bottom:20px;text-align:center;animation:pulse 1.5s infinite;">
  <div style="font-size:24px;margin-bottom:6px;">⚠️ DARK SIDE ACTIVATED ⚠️</div>
  <div style="font-size:14px;color:#f43f5e;font-weight:700;">You missed <?= $user['dark_side_days'] ?> days of study! The villain grows stronger!</div>
  <div style="font-size:12px;color:var(--muted);margin-top:4px;">Study today to return to the Light Side!</div>
</div>
<?php endif; ?>

<!-- Villain Display -->
<div style="background:linear-gradient(135deg,<?= $currentStage['color'] ?>15,rgba(0,0,0,.5));border:1px solid <?= $currentStage['color'] ?>44;border-radius:20px;padding:32px;text-align:center;margin-bottom:24px;position:relative;overflow:hidden;">
  <div style="position:absolute;inset:0;background:radial-gradient(circle at 50% 50%,<?= $currentStage['color'] ?>08,transparent);pointer-events:none;"></div>

  <div style="font-size:80px;margin-bottom:10px;animation:float 3s ease-in-out infinite;filter:drop-shadow(0 0 20px <?= $currentStage['color'] ?>);"><?= $currentStage['emoji'] ?></div>
  <h2 style="font-family:'Orbitron',monospace;font-size:22px;color:<?= $currentStage['color'] ?>;margin-bottom:6px;"><?= $currentStage['name'] ?></h2>
  <p style="font-size:13px;color:var(--muted);margin-bottom:20px;"><?= $currentStage['desc'] ?></p>

  <!-- Villain HP Bar -->
  <div style="max-width:500px;margin:0 auto 16px;">
    <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:6px;">
      <span style="color:<?= $currentStage['color'] ?>;font-weight:700;">VILLAIN HP</span>
      <span style="color:var(--muted);"><?= number_format($remaining) ?> / <?= number_format($villainHP) ?></span>
    </div>
    <div style="height:16px;background:rgba(0,0,0,.4);border-radius:8px;overflow:hidden;border:1px solid <?= $currentStage['color'] ?>44;">
      <div style="height:100%;width:<?= max(0,100-$hpPct) ?>%;background:linear-gradient(90deg,<?= $currentStage['color'] ?>,<?= $currentStage['color'] ?>88);border-radius:8px;transition:width 1.5s ease;box-shadow:0 0 10px <?= $currentStage['color'] ?>;"></div>
    </div>
  </div>

  <!-- Your Power -->
  <div style="display:inline-block;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:12px;padding:10px 24px;">
    <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;">Your Total Damage Dealt</div>
    <div style="font-family:'Orbitron',monospace;font-size:24px;font-weight:900;color:var(--success);"><?= number_format($dealt) ?> DMG</div>
  </div>
</div>

<!-- Today's Battle -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">
  <div class="card" style="text-align:center;border-color:rgba(0,212,255,.2);">
    <div style="font-size:28px;margin-bottom:8px;">⚔️</div>
    <div style="font-family:'Orbitron',monospace;font-size:24px;font-weight:900;color:var(--primary);"><?= number_format($todayDamage) ?></div>
    <div style="font-size:11px;color:var(--muted);text-transform:uppercase;">Today's Damage</div>
    <div style="font-size:10px;color:var(--muted);margin-top:4px;">Study: <?= $todayStudy ?>min × 2 + MCQ: <?= $todayMcq ?> × 5</div>
  </div>
  <div class="card" style="text-align:center;border-color:rgba(245,158,11,.2);">
    <div style="font-size:28px;margin-bottom:8px;">🛡️</div>
    <div style="font-family:'Orbitron',monospace;font-size:24px;font-weight:900;color:var(--accent);"><?= $hpPct ?>%</div>
    <div style="font-size:11px;color:var(--muted);text-transform:uppercase;">Villain Defeated</div>
    <div style="font-size:10px;color:var(--muted);margin-top:4px;"><?= $hpPct >= 100 ? '🏆 VICTORY!' : 'Keep fighting!' ?></div>
  </div>
</div>

<!-- How to Deal Damage -->
<div class="card" style="margin-bottom:20px;">
  <div class="card-title" style="margin-bottom:14px;">⚔️ How to Deal Damage</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;">
    <?php foreach ([
      ['⏱️','Study 1 minute','= 2 damage','#00d4ff'],
      ['✅','1 Correct MCQ','= 5 damage','#10b981'],
      ['📚','Complete Subject','= 500 damage','#f59e0b'],
      ['🔥','Daily Streak','= 50 damage/day','#ef4444'],
    ] as $d): ?>
    <div style="padding:14px;background:var(--bg2);border-radius:10px;border:1px solid <?= $d[3] ?>22;text-align:center;">
      <div style="font-size:24px;margin-bottom:6px;"><?= $d[0] ?></div>
      <div style="font-size:13px;font-weight:700;margin-bottom:2px;"><?= $d[1] ?></div>
      <div style="font-size:11px;color:<?= $d[3] ?>;font-weight:700;"><?= $d[2] ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Battle Log -->
<div class="card">
  <div class="card-title" style="margin-bottom:14px;">📜 Battle Log (Last 7 Days)</div>
  <?php if ($battleLog && $battleLog->num_rows > 0): while ($b=$battleLog->fetch_assoc()):
    $dmg = (int)$b['mins'] * 2;
  ?>
  <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);">
    <span style="font-size:18px;">⚔️</span>
    <div style="flex:1;"><div style="font-size:13px;font-weight:600;"><?= date('d M Y', strtotime($b['session_date'])) ?></div></div>
    <div style="font-size:13px;font-weight:700;color:var(--success);">+<?= number_format($dmg) ?> DMG</div>
    <div style="font-size:11px;color:var(--muted);"><?= $b['mins'] ?> min study</div>
  </div>
  <?php endwhile; else: ?>
  <p style="color:var(--muted);font-size:13px;">Start studying to log battle entries!</p>
  <?php endif; ?>
</div>

</div>
<?php include '../includes/footer.php'; ?>
