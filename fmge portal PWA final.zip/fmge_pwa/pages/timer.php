<?php
require_once '../includes/config.php';
requireLogin();
$db = getDB(); $uid = (int)$_SESSION['user_id'];
$today = date('Y-m-d');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    header('Content-Type: application/json');
    $sub = clean($_POST['subject'] ?? 'General');
    $mins = (int)($_POST['duration'] ?? 0);
    if ($mins > 0) {
        $start = date('Y-m-d H:i:s', strtotime("-{$mins} minutes"));
        $end   = date('Y-m-d H:i:s');
        $stmt  = $db->prepare("INSERT INTO study_sessions (user_id,subject,start_time,end_time,duration_minutes,session_date) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('isssis', $uid, $sub, $start, $end, $mins, $today);
        $stmt->execute();
        $db->query("UPDATE users SET total_study_minutes=total_study_minutes+$mins WHERE id=$uid");
        addXP($uid, $mins * 2, $mins);
        updateStreak($uid);
        checkBadges($uid);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

$todayMins = (int)($db->query("SELECT SUM(duration_minutes) as t FROM study_sessions WHERE user_id=$uid AND session_date='$today'")->fetch_assoc()['t'] ?? 0);
$weekMins  = (int)($db->query("SELECT SUM(duration_minutes) as t FROM study_sessions WHERE user_id=$uid AND session_date>=DATE_SUB('$today',INTERVAL 7 DAY)")->fetch_assoc()['t'] ?? 0);
$totalSess = (int)($db->query("SELECT COUNT(*) as c FROM study_sessions WHERE user_id=$uid AND session_date='$today'")->fetch_assoc()['c'] ?? 0);
$sessions  = $db->query("SELECT * FROM study_sessions WHERE user_id=$uid AND session_date='$today' ORDER BY start_time DESC LIMIT 10");

// 14-day chart
$chartH = [];
for ($i = 13; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $m = (int)($db->query("SELECT SUM(duration_minutes) as t FROM study_sessions WHERE user_id=$uid AND session_date='$d'")->fetch_assoc()['t'] ?? 0);
    $chartH[] = round($m / 60, 1);
}

$slots = $db->query("SELECT * FROM timetable WHERE user_id=$uid ORDER BY slot_start ASC");
$pageTitle = 'Study Timer'; $activePage = 'timer';
include '../includes/header.php';
?>
<div class="page-content">
<div style="display:grid;grid-template-columns:360px 1fr;gap:20px;">

  <!-- LEFT: Timer -->
  <div>
    <!-- Subject + intention -->
    <div class="card anim-fade-up" style="margin-bottom:14px;">
      <div style="font-size:12px;font-weight:700;color:var(--muted);margin-bottom:8px;text-transform:uppercase;letter-spacing:1px;">What's your focus?</div>
      <select id="subjectSelect" class="form-control" style="margin-bottom:10px;">
        <option value="General Study">📚 General Study</option>
        <?php if($slots) while($s=$slots->fetch_assoc()): ?>
        <option value="<?= clean($s['subject']) ?>"><?= clean($s['subject']) ?> (<?= date('h:i A',strtotime($s['slot_start'])) ?>)</option>
        <?php endwhile; ?>
        <?php foreach(['Anatomy','Physiology','Biochemistry','Pathology','Pharmacology','Microbiology','Surgery','Medicine','Revision','MCQ Practice'] as $s): ?>
        <option><?= $s ?></option>
        <?php endforeach; ?>
      </select>
      <input type="text" id="intentionInput" class="form-control" placeholder="Intention — What will you study today?" style="font-size:12px;"/>
    </div>

    <!-- Duration presets -->
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px;">
      <?php foreach([25,45,60,90,120,180] as $m): ?>
      <button onclick="setDuration(<?= $m ?>,this)" style="padding:6px 14px;border-radius:20px;background:rgba(255,255,255,.04);border:1px solid var(--border2);font-size:11px;color:var(--muted);font-weight:600;cursor:pointer;font-family:'Syne',sans-serif;transition:all .2s;" <?= $m===60?'class="dur-active"':'' ?>><?= $m>=60?($m/60).'hr':$m.'min' ?></button>
      <?php endforeach; ?>
    </div>

    <!-- Clock Canvas -->
    <div style="position:relative;width:220px;height:220px;margin:0 auto 20px;">
      <canvas id="clockCanvas" width="220" height="220" style="position:absolute;top:0;left:0;"></canvas>
      <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;pointer-events:none;">
        <div id="timerDisplay" style="font-family:'JetBrains Mono',monospace;font-size:40px;font-weight:600;color:var(--text);letter-spacing:1px;">60:00</div>
        <div style="font-size:12px;color:var(--muted);margin-top:4px;font-family:'JetBrains Mono',monospace;">
          <span id="startTime">--:--</span> → <span id="endTime">--:--</span>
        </div>
      </div>
    </div>

    <!-- Mode tabs -->
    <div style="display:flex;gap:6px;justify-content:center;margin-bottom:14px;">
      <button onclick="setMode('countdown',this)" id="modeCountdown" style="padding:7px 16px;border-radius:20px;background:var(--primary);color:#000;font-size:11px;font-weight:700;border:none;cursor:pointer;font-family:'Syne',sans-serif;transition:all .2s;">⬇️ Countdown</button>
      <button onclick="setMode('stopwatch',this)" id="modeStopwatch" style="padding:7px 16px;border-radius:20px;background:rgba(255,255,255,.06);color:var(--muted);font-size:11px;font-weight:700;border:1px solid var(--border2);cursor:pointer;font-family:'Syne',sans-serif;transition:all .2s;">⏱️ Stopwatch</button>
    </div>

    <!-- Mini stats -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px;">
      <?php foreach([['⏱️',floor($todayMins/60).'h '.($todayMins%60).'m','Today'],[$totalSess,'Sessions','Today'],['🔥',$_SESSION['streak_days']??0,'Day Streak'],[round($todayMins/max(1,$totalSess)).'m','Avg Session','Today']] as $s): ?>
      <div style="background:rgba(255,255,255,.03);border:1px solid var(--border2);border-radius:12px;padding:10px;text-align:center;">
        <div style="font-family:'JetBrains Mono',monospace;font-size:15px;font-weight:700;color:var(--primary);"><?= is_array($s)?$s[0]:$s ?></div>
        <div style="font-size:9px;color:var(--muted);margin-top:2px;"><?= is_array($s)?$s[2]:'' ?></div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Controls -->
    <button id="startBtn" onclick="toggleTimer()" class="btn btn-primary w-full" style="margin-bottom:8px;padding:14px;font-size:14px;letter-spacing:.5px;">▶ START SESSION</button>
    <button onclick="resetTimer()" class="btn btn-ghost w-full" style="font-size:13px;">↺ Reset</button>
  </div>

  <!-- RIGHT: Timeline + Chart -->
  <div>
    <!-- Study trend -->
    <div class="card anim-fade-up mb-20" data-delay="1">
      <div class="card-hdr">
        <div><div class="card-ttl">📈 14-Day Study Trend</div><div class="card-sub">Hours per day</div></div>
      </div>
      <div style="height:130px;"><canvas id="trendChart"></canvas></div>
    </div>

    <!-- Today's sessions -->
    <div class="card anim-fade-up" data-delay="2">
      <div class="card-hdr">
        <div><div class="card-ttl">📋 Today's Sessions</div></div>
        <div style="font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:700;color:var(--primary);"><?= floor($todayMins/60) ?>h <?= $todayMins%60 ?>m</div>
      </div>
      <?php if($sessions && $sessions->num_rows > 0): while($s=$sessions->fetch_assoc()): ?>
      <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);">
        <div style="width:8px;height:8px;border-radius:50%;background:var(--primary);flex-shrink:0;"></div>
        <div style="flex:1;">
          <div style="font-size:13px;font-weight:600;"><?= clean($s['subject']) ?></div>
          <div style="font-size:10px;color:var(--muted);"><?= date('h:i A',strtotime($s['start_time'])) ?></div>
        </div>
        <div style="font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:700;color:var(--primary);"><?= floor($s['duration_minutes']/60) ?>h <?= $s['duration_minutes']%60 ?>m</div>
      </div>
      <?php endwhile; else: ?>
      <p style="color:var(--muted);font-size:13px;padding:16px 0;text-align:center;">No sessions today. Start timer! 🕯️</p>
      <?php endif; ?>
    </div>
  </div>

</div>
</div>

<style>
.dur-active{background:rgba(56,182,204,.12)!important;border-color:rgba(56,182,204,.3)!important;color:var(--primary)!important;}
</style>

<script>
const canvas = document.getElementById('clockCanvas');
const ctx = canvas.getContext('2d');
let mode = 'countdown';
let timerDur = 60*60, timerRem = 60*60;
let running = false, paused = false;
let timerInterval = null;

const subjects = ['Anatomy','Physiology','Biochemistry','Pathology','General Study'];
const subColors = ['#38b6cc','#5b3fa0','#c9922a','#c0384a','#1a9e6e'];

function getSubjectColor(){
  const sub = document.getElementById('subjectSelect').value;
  const idx = subjects.indexOf(sub);
  return idx>=0?subColors[idx]:subColors[0];
}

function drawClock(){
  const W=220,H=220,cx=110,cy=110,r=90;
  ctx.clearRect(0,0,W,H);
  const color = getSubjectColor();
  // Track
  ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);
  ctx.strokeStyle='rgba(255,255,255,.06)';ctx.lineWidth=8;ctx.stroke();
  // Ticks
  for(let i=0;i<60;i++){
    const a=(i/60)*Math.PI*2-Math.PI/2;
    const major=i%5===0;
    ctx.beginPath();
    ctx.moveTo(cx+Math.cos(a)*(r+2),cy+Math.sin(a)*(r+2));
    ctx.lineTo(cx+Math.cos(a)*(r-(major?14:8)),cy+Math.sin(a)*(r-(major?14:8)));
    ctx.strokeStyle=major?'rgba(255,255,255,.2)':'rgba(255,255,255,.07)';
    ctx.lineWidth=major?1.5:1;ctx.stroke();
  }
  // Progress arc
  const pct = mode==='countdown'?timerRem/timerDur:Math.min(1,(Date.now()-(window._swStart||Date.now()))/3600000);
  const endA = -Math.PI/2+(1-pct)*Math.PI*2;
  ctx.save();
  ctx.shadowBlur=16;ctx.shadowColor=color;
  ctx.beginPath();ctx.arc(cx,cy,r,-Math.PI/2,endA);
  ctx.strokeStyle=color;ctx.lineWidth=8;ctx.lineCap='round';ctx.stroke();
  ctx.restore();
  // Dot
  const dotA=-Math.PI/2+(1-pct)*Math.PI*2;
  const dx=cx+Math.cos(dotA)*r,dy=cy+Math.sin(dotA)*r;
  ctx.beginPath();ctx.arc(dx,dy,6,0,Math.PI*2);
  ctx.fillStyle='#fff';ctx.shadowBlur=12;ctx.shadowColor=color;ctx.fill();
  ctx.shadowBlur=0;
}
drawClock();

function setDuration(mins,el){
  if(running) return;
  timerDur=mins*60;timerRem=mins*60;
  document.querySelectorAll('[onclick^="setDuration"]').forEach(b=>b.classList.remove('dur-active'));
  el.classList.add('dur-active');
  updateDisplay();updateTimeRange();drawClock();
}

function setMode(m,btn){
  mode=m;
  document.getElementById('modeCountdown').style.background=m==='countdown'?'var(--primary)':'rgba(255,255,255,.06)';
  document.getElementById('modeCountdown').style.color=m==='countdown'?'#000':'var(--muted)';
  document.getElementById('modeStopwatch').style.background=m==='stopwatch'?'var(--primary)':'rgba(255,255,255,.06)';
  document.getElementById('modeStopwatch').style.color=m==='stopwatch'?'#000':'var(--muted)';
  resetTimer();
}

function toggleTimer(){
  if(!running&&!paused) startTimer();
  else if(running) pauseTimer();
  else resumeTimer();
}

let elapsed=0;
function startTimer(){
  running=true;paused=false;elapsed=0;
  const sub=document.getElementById('subjectSelect').value;
  document.getElementById('startBtn').textContent='⏸ PAUSE SESSION';
  document.getElementById('startBtn').style.background='linear-gradient(135deg,#636366,#48484a)';
  startFloatingTimer(sub,mode==='countdown'?timerDur/60:null);
  timerInterval=setInterval(()=>{
    elapsed++;
    if(mode==='countdown'){timerRem--;if(timerRem<=0){completeTimer();return;}}
    updateDisplay();drawClock();
  },1000);
  updateTimeRange();
}
function pauseTimer(){running=false;clearInterval(timerInterval);document.getElementById('startBtn').textContent='▶ RESUME SESSION';document.getElementById('startBtn').style.background='';}
function resumeTimer(){running=true;document.getElementById('startBtn').textContent='⏸ PAUSE SESSION';document.getElementById('startBtn').style.background='linear-gradient(135deg,#636366,#48484a)';timerInterval=setInterval(()=>{elapsed++;if(mode==='countdown'){timerRem--;if(timerRem<=0){completeTimer();return;}}updateDisplay();drawClock();},1000);}
function completeTimer(){
  clearInterval(timerInterval);running=false;
  document.getElementById('startBtn').textContent='▶ START SESSION';
  document.getElementById('startBtn').style.background='';
  stopFloatingTimer();
  saveSession(Math.floor(elapsed/60));
}
function resetTimer(){
  clearInterval(timerInterval);running=false;paused=false;elapsed=0;
  timerRem=timerDur;
  document.getElementById('startBtn').textContent='▶ START SESSION';
  document.getElementById('startBtn').style.background='';
  document.getElementById('timerDisplay').textContent=formatTime(timerDur);
  drawClock();
}

function updateDisplay(){
  if(mode==='countdown'){
    const t=Math.max(0,timerRem);
    document.getElementById('timerDisplay').textContent=formatTime(t);
  } else {
    document.getElementById('timerDisplay').textContent=formatTime(elapsed);
  }
}
function formatTime(s){const h=Math.floor(s/3600),m=Math.floor((s%3600)/60),sec=s%60;return h>0?pad(h)+':'+pad(m)+':'+pad(sec):pad(m)+':'+pad(sec);}
function pad(n){return String(n).padStart(2,'0');}
function updateTimeRange(){
  const now=new Date();const end=new Date(now.getTime()+timerDur*1000);
  const fmt=d=>pad(d.getHours())+':'+pad(d.getMinutes());
  document.getElementById('startTime').textContent=fmt(now);
  document.getElementById('endTime').textContent=fmt(end);
}

function saveSession(mins){
  if(mins<1) return;
  const sub=document.getElementById('subjectSelect').value;
  fetch('timer.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:`ajax=1&subject=${encodeURIComponent(sub)}&duration=${mins}`})
  .then(r=>r.json()).then(d=>{if(d.success){showToast(pad(Math.floor(mins/60))+':'+pad(mins%60)+' saved! +XP 🕯️');setTimeout(()=>location.reload(),1500);}});
}

updateTimeRange();

// Trend chart
const chartData = <?= json_encode($chartH) ?>;
const primary = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim() || '#38b6cc';
new Chart(document.getElementById('trendChart').getContext('2d'),{
  type:'bar',
  data:{labels:Array.from({length:14},(_,i)=>{const d=new Date();d.setDate(d.getDate()-(13-i));return d.toLocaleDateString('en',{weekday:'short'});}).map((d,i,a)=>a[i]),
        datasets:[{data:chartData,backgroundColor:chartData.map((_,i)=>i===13?primary:primary+'44'),borderRadius:5,borderSkipped:false}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{min:0,ticks:{callback:v=>v+'h',color:'var(--muted)',font:{size:9}},grid:{color:'rgba(255,255,255,.04)'}},x:{ticks:{color:'var(--muted)',font:{size:9}},grid:{display:false}}}}
});
</script>
<?php include '../includes/footer.php'; ?>
