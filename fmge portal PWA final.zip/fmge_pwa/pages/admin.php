<?php
require_once '../includes/config.php';
requireAdmin();
$db=getDB();$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $a=$_POST['action']??'';
    if($a==='add_user'){$un=clean($_POST['username']??'');$fn=clean($_POST['full_name']??'');$em=clean($_POST['email']??'');$pw=$_POST['password']??'';$role=clean($_POST['role']??'student');$te=clean($_POST['target_exam']??'FMGE');if($un&&$fn&&$pw){$hash=password_hash($pw,PASSWORD_DEFAULT);$stmt=$db->prepare("INSERT INTO users(username,password,full_name,email,role,target_exam) VALUES(?,?,?,?,?,?)");$stmt->bind_param('ssssss',$un,$hash,$fn,$em,$role,$te);if($stmt->execute()){$nid=$db->insert_id;$db->query("INSERT INTO user_settings(user_id) VALUES($nid)");$msg="User '$un' added!";}else $msg="Error: Username exists!";}}
    elseif($a==='ban'){$id=(int)($_POST['id']??0);$ban=(int)($_POST['ban']??1);if($id!=(int)$_SESSION['user_id']){$db->query("UPDATE users SET is_banned=$ban WHERE id=$id");$msg=$ban?'User banned!':'User unbanned!';}}
    elseif($a==='delete'){$id=(int)($_POST['id']??0);if($id!=(int)$_SESSION['user_id']){$db->query("DELETE FROM users WHERE id=$id");$msg='User deleted!';}}
    elseif($a==='change_pass'){$id=(int)($_POST['id']??0);$pw=$_POST['new_pass']??'';if($id&&$pw){$hash=password_hash($pw,PASSWORD_DEFAULT);$db->query("UPDATE users SET password='$hash' WHERE id=$id");$msg='Password changed!';}}
    elseif($a==='add_exam_type'){$et=clean($_POST['exam_type_name']??'');if($et){$db->query("INSERT IGNORE INTO exam_types(name) VALUES('$et')");$msg='Exam type added!';}}
    elseif($a==='delete_exam_type'){$id=(int)($_POST['et_id']??0);$db->query("DELETE FROM exam_types WHERE id=$id");$msg='Exam type deleted!';}
    elseif($a==='notify_all'){$nm=clean($_POST['notif_msg']??'');if($nm){$us=$db->query("SELECT id FROM users");while($u=$us->fetch_assoc())addNotification($u['id'],$nm,'info');$msg='Notification sent to all!';}}
    elseif($a==='give_xp'){$id=(int)($_POST['xp_uid']??0);$xp=(int)($_POST['xp_amt']??0);$coins=(int)($_POST['coins_amt']??0);if($id&&($xp>0||$coins>0)){addXP($id,$xp,$coins);$msg='XP/Coins given!';}}
}
$users=$db->query("SELECT * FROM users ORDER BY created_at DESC");
$examTypes=$db->query("SELECT * FROM exam_types ORDER BY name");
$stats=$db->query("SELECT COUNT(*) as total,SUM(is_banned) as banned,SUM(CASE WHEN role='admin' THEN 1 ELSE 0 END) as admins,SUM(total_study_minutes) as total_mins FROM users")->fetch_assoc();
$pageTitle='Admin Panel';$activePage='admin';
include '../includes/header.php';
?>
<div class="page-content">
<?php if($msg):?><div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);border-radius:10px;padding:12px 16px;margin-bottom:20px;font-size:13px;font-weight:600;color:var(--success);">✅ <?=$msg?></div><?php endif;?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:12px;margin-bottom:20px;">
<?php foreach([['👥','Total Users',$stats['total'],'var(--primary)'],['🚫','Banned',$stats['banned'],'var(--danger)'],['🛡️','Admins',$stats['admins'],'var(--accent)'],['⏱️','Total Study Hrs',floor(($stats['total_mins']??0)/60).'h','var(--success)']] as $s):?>
<div class="card" style="text-align:center;padding:14px;"><div style="font-size:18px;margin-bottom:4px;"><?=$s[0]?></div><div style="font-family:'Orbitron',monospace;font-size:20px;font-weight:800;color:<?=$s[3]?>"><?=$s[2]?></div><div style="font-size:10px;color:var(--muted);text-transform:uppercase;"><?=$s[1]?></div></div>
<?php endforeach;?>
</div>
<div style="display:flex;gap:4px;background:var(--bg2);border-radius:12px;padding:4px;margin-bottom:20px;border:1px solid var(--border);flex-wrap:wrap;">
<?php foreach([['users','👥 Users'],['add','➕ Add'],['exams','📋 Exams'],['notify','🔔 Notify'],['xp','⚡ XP']] as $t):?>
<button onclick="showTab('<?=$t[0]?>')" id="atab-<?=$t[0]?>" style="flex:1;min-width:70px;padding:8px 6px;border:none;border-radius:9px;font-family:'Inter',sans-serif;font-size:11px;font-weight:700;cursor:pointer;transition:all .2s;background:transparent;color:var(--muted);text-transform:uppercase;"><?=$t[1]?></button>
<?php endforeach;?>
</div>

<div id="apanel-users">
<?php if($users)while($u=$users->fetch_assoc()):$ri=getRank($u['level']??1);?>
<div class="card" style="margin-bottom:8px;padding:12px 16px;">
<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
<div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--secondary));display:flex;align-items:center;justify-content:center;font-size:14px;color:#fff;font-weight:700;flex-shrink:0;"><?=strtoupper(substr($u['full_name'],0,1))?></div>
<div style="flex:1;min-width:100px;">
<div style="font-size:13px;font-weight:700;"><?=clean($u['full_name'])?> <span style="font-size:9px;font-family:'Orbitron',monospace;color:<?=$ri[1]?>;border:1px solid <?=$ri[1]?>44;padding:1px 4px;border-radius:4px;"><?=$ri[0]?></span><?php if($u['role']==='admin'):?><span style="font-size:9px;background:rgba(245,158,11,.15);color:var(--accent);border:1px solid rgba(245,158,11,.3);border-radius:4px;padding:1px 5px;margin-left:3px;">ADMIN</span><?php endif;?><?php if($u['is_banned']):?><span style="font-size:9px;background:rgba(244,63,94,.15);color:var(--danger);border-radius:4px;padding:1px 5px;margin-left:3px;">BANNED</span><?php endif;?></div>
<div style="font-size:10px;color:var(--muted);">@<?=clean($u['username'])?> • <?=clean($u['target_exam'])?> • Lv.<?=$u['level']?> • ⏱️<?=floor($u['total_study_minutes']/60)?>h • 🔥<?=$u['streak_days']?>d • 🪙<?=number_format($u['coins']??0)?></div>
</div>
<div style="display:flex;gap:5px;flex-wrap:wrap;">
<form method="POST" style="display:flex;gap:3px;"><input type="hidden" name="action" value="change_pass"/><input type="hidden" name="id" value="<?=$u['id']?>"/><input type="text" name="new_pass" placeholder="New pass" style="width:80px;padding:4px 8px;border:1px solid var(--border);border-radius:6px;font-size:11px;background:var(--bg2);color:var(--text);"/><button type="submit" class="btn btn-sm btn-primary">🔑</button></form>
<?php if($u['id']!=(int)$_SESSION['user_id']):?>
<form method="POST"><input type="hidden" name="action" value="ban"/><input type="hidden" name="id" value="<?=$u['id']?>"/><input type="hidden" name="ban" value="<?=$u['is_banned']?0:1?>"/><button type="submit" class="btn btn-sm <?=$u['is_banned']?'btn-success':'btn-outline'?>"><?=$u['is_banned']?'✅ Unban':'🚫 Ban'?></button></form>
<a href="profile.php?id=<?=$u['id']?>" class="btn btn-sm btn-outline">👤</a>
<form method="POST" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete"/><input type="hidden" name="id" value="<?=$u['id']?>"/><button type="submit" class="btn btn-sm btn-danger">🗑️</button></form>
<?php endif;?>
</div>
</div>
</div>
<?php endwhile;?>
</div>

<div id="apanel-add" style="display:none;">
<div class="card"><div class="card-title" style="margin-bottom:14px;">➕ Add New Student</div>
<form method="POST"><input type="hidden" name="action" value="add_user"/>
<div class="form-row"><div class="form-group"><label>Username *</label><input type="text" name="username" class="form-control" required/></div><div class="form-group"><label>Full Name *</label><input type="text" name="full_name" class="form-control" required/></div></div>
<div class="form-row"><div class="form-group"><label>Password *</label><input type="text" name="password" class="form-control" required/></div><div class="form-group"><label>Email</label><input type="email" name="email" class="form-control"/></div></div>
<div class="form-row"><div class="form-group"><label>Target Exam</label><input type="text" name="target_exam" class="form-control" value="FMGE"/></div><div class="form-group"><label>Role</label><select name="role" class="form-control"><option value="student">Student</option><option value="admin">Admin</option></select></div></div>
<button type="submit" class="btn btn-primary">💾 Add Student</button>
</form></div>
</div>

<div id="apanel-exams" style="display:none;">
<div class="card"><div class="card-title" style="margin-bottom:14px;">📋 Custom Exam Types</div>
<form method="POST" style="display:flex;gap:8px;margin-bottom:16px;"><input type="hidden" name="action" value="add_exam_type"/><input type="text" name="exam_type_name" class="form-control" placeholder="e.g. AMC, ERPM, PMDC..." required/><button type="submit" class="btn btn-primary">+ Add</button></form>
<div style="display:flex;flex-wrap:wrap;gap:8px;">
<?php if($examTypes)while($et=$examTypes->fetch_assoc()):?>
<div style="display:flex;align-items:center;gap:6px;padding:5px 12px;background:rgba(0,212,255,.08);border:1px solid rgba(0,212,255,.2);border-radius:8px;">
<span style="font-size:12px;font-weight:700;color:var(--primary);"><?=clean($et['name'])?></span>
<form method="POST" style="display:inline;"><input type="hidden" name="action" value="delete_exam_type"/><input type="hidden" name="et_id" value="<?=$et['id']?>"/><button type="submit" style="background:none;border:none;cursor:pointer;font-size:11px;color:var(--danger);">✕</button></form>
</div>
<?php endwhile;?>
</div></div>
</div>

<div id="apanel-notify" style="display:none;">
<div class="card"><div class="card-title" style="margin-bottom:14px;">🔔 Send Notification</div>
<form method="POST"><input type="hidden" name="action" value="notify_all"/>
<div class="form-group"><label>Message (sends to ALL students)</label><textarea name="notif_msg" class="form-control" rows="3" required placeholder="Notification message..."></textarea></div>
<button type="submit" class="btn btn-primary">🚀 Send to All</button>
</form></div>
</div>

<div id="apanel-xp" style="display:none;">
<div class="card"><div class="card-title" style="margin-bottom:14px;">⚡ Give XP & Coins to Student</div>
<form method="POST"><input type="hidden" name="action" value="give_xp"/>
<div class="form-group"><label>Select Student</label><select name="xp_uid" class="form-control"><?php $us2=$db->query("SELECT id,full_name FROM users ORDER BY full_name");if($us2)while($u=$us2->fetch_assoc()):?><option value="<?=$u['id']?>"><?=clean($u['full_name'])?></option><?php endwhile;?></select></div>
<div class="form-row"><div class="form-group"><label>XP Amount</label><input type="number" name="xp_amt" class="form-control" value="100" min="0"/></div><div class="form-group"><label>Coins Amount</label><input type="number" name="coins_amt" class="form-control" value="50" min="0"/></div></div>
<button type="submit" class="btn btn-primary">⚡ Give XP & Coins</button>
</form></div>
</div>
</div>
<script>function showTab(t){['users','add','exams','notify','xp'].forEach(id=>{document.getElementById('apanel-'+id).style.display=id===t?'block':'none';const btn=document.getElementById('atab-'+id);btn.style.background=id===t?'var(--card)':'transparent';btn.style.color=id===t?'var(--primary)':'var(--muted)';btn.style.boxShadow=id===t?'0 2px 8px rgba(0,0,0,.2)':'none';});} showTab('users');</script>
<?php include '../includes/footer.php';?>
